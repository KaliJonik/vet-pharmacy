import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("nodataimage.jpg");

export { _imports_0 as _ };
//# sourceMappingURL=nodataimage-39aadd60.mjs.map
