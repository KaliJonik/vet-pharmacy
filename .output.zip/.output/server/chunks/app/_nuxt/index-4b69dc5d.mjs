import { _ as __nuxt_component_0 } from './nuxt-link-691e5b50.mjs';
import { u as useHead } from './index-6a088328.mjs';
import { shallowRef, computed, toRef, createVNode, mergeProps, ref, watch, nextTick, onScopeDispose, withAsyncContext, unref, isRef, withCtx, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, withModifiers, withDirectives, vModelText, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0 } from './nodataimage-39aadd60.mjs';
import { p as propsFactory, I as IconValue, m as makeComponentProps, e as makeThemeProps, g as genericComponent, f as useProxiedModel, R as useLocale, s as useRtl, F as provideTheme, a6 as useDisplay, j as provideDefaults, N as useResizeObserver, a8 as createRange, k as useRender, q as omit, a2 as refElement, a9 as keyValues, t as productStore, u as useRouter } from '../server.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import { V as VMenu, a as VList, b as VListItem, c as VListItemTitle } from './VMenu-6cf816e1.mjs';
import { e as makeBorderProps, m as makeDensityProps, f as makeElevationProps, g as makeRoundedProps, h as makeSizeProps, a as makeTagProps, i as makeVariantProps, d as VBtn, j as makeLocationProps, k as makePositionProps, l as useLocation, n as usePosition, o as useVariant, p as useRounded, q as genOverlays, r as VProgressLinear, s as VDefaultsProvider, V as VIcon } from './VBtn-55c932b0.mjs';
import { m as makeVOverlayProps, u as useScopeId, c as VOverlay, f as forwardRefs, d as VSheet, a as VCard } from './VSheet-f502d2db.mjs';
import { V as VDialog } from './VDialog-13e4da20.mjs';
import { V as VCardText } from './ssrBoot-66bca22f.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import '@unhead/shared';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import 'vue-router';
import 'is-https';

const animation = () => {
  let scroll = window.requestAnimationFrame || function(callback) {
    window.setTimeout(callback, 1e3 / 60);
  };
  let elToShow = document.querySelectorAll(".play-on-scroll");
  let isElInViewPort = (el) => {
    let rect = el.getBoundingClientRect();
    return rect.top <= 0 && rect.bottom >= 0 || rect.bottom >= (window.innerHeight || document.documentElement.clientHeight) && rect.top <= (window.innerHeight || document.documentElement.clientHeight) || rect.top >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight);
  };
  let loop = () => {
    elToShow.forEach((item, index2) => {
      if (isElInViewPort(item)) {
        item.classList.add("start");
      } else {
        item.classList.remove("start");
      }
    });
    scroll(loop);
  };
  loop();
};
const addToCart = (productId) => {
  const store = productStore();
  const router = useRouter();
  const alreadyInCart = store.cards.some((item) => item.id === productId);
  if (!alreadyInCart) {
    const selectedProduct = store.products.find((item) => item.id === productId);
    if (selectedProduct) {
      store.addCards(selectedProduct);
    }
  } else {
    router.push("/basket");
  }
};
function useRefs() {
  const refs = ref([]);
  function updateRef(e, i) {
    refs.value[i] = e;
  }
  return {
    refs,
    updateRef
  };
}
const makeVPaginationProps = propsFactory({
  activeColor: String,
  start: {
    type: [Number, String],
    default: 1
  },
  modelValue: {
    type: Number,
    default: (props) => props.start
  },
  disabled: Boolean,
  length: {
    type: [Number, String],
    default: 1,
    validator: (val) => val % 1 === 0
  },
  totalVisible: [Number, String],
  firstIcon: {
    type: IconValue,
    default: "$first"
  },
  prevIcon: {
    type: IconValue,
    default: "$prev"
  },
  nextIcon: {
    type: IconValue,
    default: "$next"
  },
  lastIcon: {
    type: IconValue,
    default: "$last"
  },
  ariaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.root"
  },
  pageAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.page"
  },
  currentPageAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.currentPage"
  },
  firstAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.first"
  },
  previousAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.previous"
  },
  nextAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.next"
  },
  lastAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.last"
  },
  ellipsis: {
    type: String,
    default: "..."
  },
  showFirstLastPage: Boolean,
  ...makeBorderProps(),
  ...makeComponentProps(),
  ...makeDensityProps(),
  ...makeElevationProps(),
  ...makeRoundedProps(),
  ...makeSizeProps(),
  ...makeTagProps({
    tag: "nav"
  }),
  ...makeThemeProps(),
  ...makeVariantProps({
    variant: "text"
  })
}, "VPagination");
const VPagination = genericComponent()({
  name: "VPagination",
  props: makeVPaginationProps(),
  emits: {
    "update:modelValue": (value) => true,
    first: (value) => true,
    prev: (value) => true,
    next: (value) => true,
    last: (value) => true
  },
  setup(props, _ref) {
    let {
      slots,
      emit
    } = _ref;
    const page = useProxiedModel(props, "modelValue");
    const {
      t,
      n
    } = useLocale();
    const {
      isRtl
    } = useRtl();
    const {
      themeClasses
    } = provideTheme(props);
    const {
      width
    } = useDisplay();
    const maxButtons = shallowRef(-1);
    provideDefaults(void 0, {
      scoped: true
    });
    const {
      resizeRef
    } = useResizeObserver();
    const length = computed(() => parseInt(props.length, 10));
    const start = computed(() => parseInt(props.start, 10));
    const totalVisible = computed(() => {
      if (props.totalVisible)
        return parseInt(props.totalVisible, 10);
      else if (maxButtons.value >= 0)
        return maxButtons.value;
      return getMax(width.value, 58);
    });
    function getMax(totalWidth, itemWidth) {
      const minButtons = props.showFirstLastPage ? 5 : 3;
      return Math.max(0, Math.floor(
        // Round to two decimal places to avoid floating point errors
        +((totalWidth - itemWidth * minButtons) / itemWidth).toFixed(2)
      ));
    }
    const range = computed(() => {
      if (length.value <= 0 || isNaN(length.value) || length.value > Number.MAX_SAFE_INTEGER)
        return [];
      if (totalVisible.value <= 1)
        return [page.value];
      if (length.value <= totalVisible.value) {
        return createRange(length.value, start.value);
      }
      const even = totalVisible.value % 2 === 0;
      const middle = even ? totalVisible.value / 2 : Math.floor(totalVisible.value / 2);
      const left = even ? middle : middle + 1;
      const right = length.value - middle;
      if (left - page.value >= 0) {
        return [...createRange(Math.max(1, totalVisible.value - 1), start.value), props.ellipsis, length.value];
      } else if (page.value - right >= (even ? 1 : 0)) {
        const rangeLength = totalVisible.value - 1;
        const rangeStart = length.value - rangeLength + start.value;
        return [start.value, props.ellipsis, ...createRange(rangeLength, rangeStart)];
      } else {
        const rangeLength = Math.max(1, totalVisible.value - 3);
        const rangeStart = rangeLength === 1 ? page.value : page.value - Math.ceil(rangeLength / 2) + start.value;
        return [start.value, props.ellipsis, ...createRange(rangeLength, rangeStart), props.ellipsis, length.value];
      }
    });
    function setValue(e, value, event) {
      e.preventDefault();
      page.value = value;
      event && emit(event, value);
    }
    const {
      refs,
      updateRef
    } = useRefs();
    provideDefaults({
      VPaginationBtn: {
        color: toRef(props, "color"),
        border: toRef(props, "border"),
        density: toRef(props, "density"),
        size: toRef(props, "size"),
        variant: toRef(props, "variant"),
        rounded: toRef(props, "rounded"),
        elevation: toRef(props, "elevation")
      }
    });
    const items = computed(() => {
      return range.value.map((item, index2) => {
        const ref2 = (e) => updateRef(e, index2);
        if (typeof item === "string") {
          return {
            isActive: false,
            key: `ellipsis-${index2}`,
            page: item,
            props: {
              ref: ref2,
              ellipsis: true,
              icon: true,
              disabled: true
            }
          };
        } else {
          const isActive = item === page.value;
          return {
            isActive,
            key: item,
            page: n(item),
            props: {
              ref: ref2,
              ellipsis: false,
              icon: true,
              disabled: !!props.disabled || +props.length < 2,
              color: isActive ? props.activeColor : props.color,
              ariaCurrent: isActive,
              ariaLabel: t(isActive ? props.currentPageAriaLabel : props.pageAriaLabel, item),
              onClick: (e) => setValue(e, item)
            }
          };
        }
      });
    });
    const controls = computed(() => {
      const prevDisabled = !!props.disabled || page.value <= start.value;
      const nextDisabled = !!props.disabled || page.value >= start.value + length.value - 1;
      return {
        first: props.showFirstLastPage ? {
          icon: isRtl.value ? props.lastIcon : props.firstIcon,
          onClick: (e) => setValue(e, start.value, "first"),
          disabled: prevDisabled,
          ariaLabel: t(props.firstAriaLabel),
          ariaDisabled: prevDisabled
        } : void 0,
        prev: {
          icon: isRtl.value ? props.nextIcon : props.prevIcon,
          onClick: (e) => setValue(e, page.value - 1, "prev"),
          disabled: prevDisabled,
          ariaLabel: t(props.previousAriaLabel),
          ariaDisabled: prevDisabled
        },
        next: {
          icon: isRtl.value ? props.prevIcon : props.nextIcon,
          onClick: (e) => setValue(e, page.value + 1, "next"),
          disabled: nextDisabled,
          ariaLabel: t(props.nextAriaLabel),
          ariaDisabled: nextDisabled
        },
        last: props.showFirstLastPage ? {
          icon: isRtl.value ? props.firstIcon : props.lastIcon,
          onClick: (e) => setValue(e, start.value + length.value - 1, "last"),
          disabled: nextDisabled,
          ariaLabel: t(props.lastAriaLabel),
          ariaDisabled: nextDisabled
        } : void 0
      };
    });
    function updateFocus() {
      var _a;
      const currentIndex = page.value - start.value;
      (_a = refs.value[currentIndex]) == null ? void 0 : _a.$el.focus();
    }
    function onKeydown(e) {
      if (e.key === keyValues.left && !props.disabled && page.value > +props.start) {
        page.value = page.value - 1;
        nextTick(updateFocus);
      } else if (e.key === keyValues.right && !props.disabled && page.value < start.value + length.value - 1) {
        page.value = page.value + 1;
        nextTick(updateFocus);
      }
    }
    useRender(() => createVNode(props.tag, {
      "ref": resizeRef,
      "class": ["v-pagination", themeClasses.value, props.class],
      "style": props.style,
      "role": "navigation",
      "aria-label": t(props.ariaLabel),
      "onKeydown": onKeydown,
      "data-test": "v-pagination-root"
    }, {
      default: () => [createVNode("ul", {
        "class": "v-pagination__list"
      }, [props.showFirstLastPage && createVNode("li", {
        "key": "first",
        "class": "v-pagination__first",
        "data-test": "v-pagination-first"
      }, [slots.first ? slots.first(controls.value.first) : createVNode(VBtn, mergeProps({
        "_as": "VPaginationBtn"
      }, controls.value.first), null)]), createVNode("li", {
        "key": "prev",
        "class": "v-pagination__prev",
        "data-test": "v-pagination-prev"
      }, [slots.prev ? slots.prev(controls.value.prev) : createVNode(VBtn, mergeProps({
        "_as": "VPaginationBtn"
      }, controls.value.prev), null)]), items.value.map((item, index2) => createVNode("li", {
        "key": item.key,
        "class": ["v-pagination__item", {
          "v-pagination__item--is-active": item.isActive
        }],
        "data-test": "v-pagination-item"
      }, [slots.item ? slots.item(item) : createVNode(VBtn, mergeProps({
        "_as": "VPaginationBtn"
      }, item.props), {
        default: () => [item.page]
      })])), createVNode("li", {
        "key": "next",
        "class": "v-pagination__next",
        "data-test": "v-pagination-next"
      }, [slots.next ? slots.next(controls.value.next) : createVNode(VBtn, mergeProps({
        "_as": "VPaginationBtn"
      }, controls.value.next), null)]), props.showFirstLastPage && createVNode("li", {
        "key": "last",
        "class": "v-pagination__last",
        "data-test": "v-pagination-last"
      }, [slots.last ? slots.last(controls.value.last) : createVNode(VBtn, mergeProps({
        "_as": "VPaginationBtn"
      }, controls.value.last), null)])])]
    }));
    return {};
  }
});
function useCountdown(milliseconds) {
  const time = shallowRef(milliseconds);
  let timer = -1;
  function clear() {
    clearInterval(timer);
  }
  function reset() {
    clear();
    nextTick(() => time.value = milliseconds);
  }
  function start(el) {
    const style = el ? getComputedStyle(el) : {
      transitionDuration: 0.2
    };
    const interval = parseFloat(style.transitionDuration) * 1e3 || 200;
    clear();
    if (time.value <= 0)
      return;
    const startTime = performance.now();
    timer = window.setInterval(() => {
      const elapsed = performance.now() - startTime + interval;
      time.value = Math.max(milliseconds - elapsed, 0);
      if (time.value <= 0)
        clear();
    }, interval);
  }
  onScopeDispose(clear);
  return {
    clear,
    time,
    start,
    reset
  };
}
const makeVSnackbarProps = propsFactory({
  multiLine: Boolean,
  text: String,
  timer: [Boolean, String],
  timeout: {
    type: [Number, String],
    default: 5e3
  },
  vertical: Boolean,
  ...makeLocationProps({
    location: "bottom"
  }),
  ...makePositionProps(),
  ...makeRoundedProps(),
  ...makeVariantProps(),
  ...makeThemeProps(),
  ...omit(makeVOverlayProps({
    transition: "v-snackbar-transition"
  }), ["persistent", "noClickAnimation", "scrim", "scrollStrategy"])
}, "VSnackbar");
const VSnackbar = genericComponent()({
  name: "VSnackbar",
  props: makeVSnackbarProps(),
  emits: {
    "update:modelValue": (v) => true
  },
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const isActive = useProxiedModel(props, "modelValue");
    const {
      locationStyles
    } = useLocation(props);
    const {
      positionClasses
    } = usePosition(props);
    const {
      scopeId
    } = useScopeId();
    const {
      themeClasses
    } = provideTheme(props);
    const {
      colorClasses,
      colorStyles,
      variantClasses
    } = useVariant(props);
    const {
      roundedClasses
    } = useRounded(props);
    const countdown = useCountdown(Number(props.timeout));
    const overlay = ref();
    const timerRef = ref();
    const isHovering = shallowRef(false);
    watch(isActive, startTimeout);
    watch(() => props.timeout, startTimeout);
    let activeTimeout = -1;
    function startTimeout() {
      countdown.reset();
      window.clearTimeout(activeTimeout);
      const timeout = Number(props.timeout);
      if (!isActive.value || timeout === -1)
        return;
      const element = refElement(timerRef.value);
      countdown.start(element);
      activeTimeout = window.setTimeout(() => {
        isActive.value = false;
      }, timeout);
    }
    function clearTimeout() {
      countdown.reset();
      window.clearTimeout(activeTimeout);
    }
    function onPointerenter() {
      isHovering.value = true;
      clearTimeout();
    }
    function onPointerleave() {
      isHovering.value = false;
      startTimeout();
    }
    useRender(() => {
      const overlayProps = VOverlay.filterProps(props);
      const hasContent = !!(slots.default || slots.text || props.text);
      return createVNode(VOverlay, mergeProps({
        "ref": overlay,
        "class": ["v-snackbar", {
          "v-snackbar--active": isActive.value,
          "v-snackbar--multi-line": props.multiLine && !props.vertical,
          "v-snackbar--timer": !!props.timer,
          "v-snackbar--vertical": props.vertical
        }, positionClasses.value, props.class],
        "style": props.style
      }, overlayProps, {
        "modelValue": isActive.value,
        "onUpdate:modelValue": ($event) => isActive.value = $event,
        "contentProps": mergeProps({
          class: ["v-snackbar__wrapper", themeClasses.value, colorClasses.value, roundedClasses.value, variantClasses.value],
          style: [locationStyles.value, colorStyles.value],
          onPointerenter,
          onPointerleave
        }, overlayProps.contentProps),
        "persistent": true,
        "noClickAnimation": true,
        "scrim": false,
        "scrollStrategy": "none",
        "_disableGlobalStack": true
      }, scopeId), {
        default: () => {
          var _a2;
          var _a, _b;
          return [genOverlays(false, "v-snackbar"), props.timer && createVNode("div", {
            "key": "timer",
            "class": "v-snackbar__timer"
          }, [createVNode(VProgressLinear, {
            "ref": timerRef,
            "active": !isHovering.value,
            "color": typeof props.timer === "string" ? props.timer : "info",
            "max": props.timeout,
            "model-value": countdown.time.value
          }, null)]), hasContent && createVNode("div", {
            "key": "content",
            "class": "v-snackbar__content",
            "role": "status",
            "aria-live": "polite"
          }, [(_a2 = (_a = slots.text) == null ? void 0 : _a.call(slots)) != null ? _a2 : props.text, (_b = slots.default) == null ? void 0 : _b.call(slots)]), slots.actions && createVNode(VDefaultsProvider, {
            "defaults": {
              VBtn: {
                variant: "text",
                ripple: false,
                slim: true
              }
            }
          }, {
            default: () => [createVNode("div", {
              "class": "v-snackbar__actions"
            }, [slots.actions()])]
          })];
        },
        activator: slots.activator
      });
    });
    return forwardRefs({}, overlay);
  }
});
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: "\u041F\u0440\u043E\u0434\u0443\u043A\u0442\u044B \u0412\u0435\u0442-\u0430\u043F\u0442\u0435\u043A\u0438",
      meta: [
        { name: "VetApteka", content: "\u0414\u043E\u0431\u0440\u043E \u043F\u043E\u0436\u0430\u043B\u043E\u0432\u0430\u0442\u044C \u0432 \u043D\u0430\u0448\u0443 \u0412\u0435\u0442\u0435\u0440\u0438\u043D\u0430\u0440\u043D\u0443\u044E \u0410\u043F\u0442\u0435\u043A\u0443 - SAMVETSERVIS! \u041E\u0441\u043D\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0432 2004 \u0433\u043E\u0434\u0443, \u043D\u0430\u0448 \u0426\u0435\u043D\u0442\u0440 \u041F\u0442\u0438\u0446\u0435\u0432\u043E\u0434\u0441\u0442\u0432\u0430 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u043D\u0430\u0434\u0435\u0436\u043D\u044B\u043C \u0438 \u043E\u043F\u044B\u0442\u043D\u044B\u043C \u043F\u0430\u0440\u0442\u043D\u0435\u0440\u043E\u043C \u0432 \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0435\u043D\u0438\u0438 \u0437\u0430\u0431\u043E\u0442\u044B \u0438 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0438 \u0432\u0430\u0448\u0435\u0433\u043E \u043F\u0442\u0438\u0446\u0435\u0432\u043E\u0434\u0441\u0442\u0432\u0430." }
      ]
    });
    const isMenuOpen = ref(false);
    const isMenustock = ref(false);
    const isMenuManufacture = ref(false);
    const store = productStore();
    const activFilter = ref({
      content: {
        ru: { title: "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438" },
        uz: { title: "Kategoriyalar" }
      }
    });
    const defaultManufactue = ref({
      content: {
        ru: { title: "\u041F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E" },
        uz: { title: "Mahsulotlar" }
      }
    });
    const activStock = ref({
      content: {
        ru: { title: "\u0421\u043A\u0438\u0434\u043A\u0438" },
        uz: { title: "Chegirmalar" }
      }
    });
    const handlePaginationClick = async () => {
      try {
        await store.fetchProduct(activFilter.value.categoryId, defaultManufactue.value.manufacturerId);
        animation();
        window.scrollTo({
          top: 0,
          behavior: "smooth"
        });
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    const changeLocale = async (selectedId) => {
      activFilter.value.categoryId = selectedId === "" ? "" : store.category.find((cat) => cat.id === selectedId).id;
      isMenuOpen.value = false;
      try {
        store.pageAPI = 1;
        await store.fetchProduct(activFilter.value.categoryId, defaultManufactue.value.manufacturerId);
        animation();
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    const changeManufacturer = async (selectedId) => {
      defaultManufactue.value.manufacturerId = selectedId === "" ? "" : store.manufacturer.find((man) => man.id === selectedId).id;
      isMenuManufacture.value = false;
      try {
        store.pageAPI = 1;
        await store.fetchProduct(activFilter.value.categoryId, defaultManufactue.value.manufacturerId);
        animation();
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    const selectOption = async (isSale) => {
      store.sale = isSale;
      await store.fetchProduct(activFilter.value.categoryId, defaultManufactue.value.manufacturerId);
      animation();
    };
    const truncateString = (text, maxLength) => {
      if (text && text.length > maxLength) {
        return text.substring(0, maxLength) + "...";
      }
      return text;
    };
    const onClick = async () => {
      try {
        store.pageAPI = 1;
        await store.fetchProduct(activFilter.value.categoryId, defaultManufactue.value.manufacturerId);
        animation();
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };
    [__temp, __restore] = withAsyncContext(() => store.fetchProduct()), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => store.fethCategory()), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => store.fethManufacture()), await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: "align-items-center bg-img bg-img-fixed",
        id: "food-menu-section",
        style: { "background-image": "url(/broilers.jpg)" }
      }, _attrs))} data-v-a20c6082><div class="container" data-v-a20c6082><div class="food-menu" data-v-a20c6082><h1 class="font-weight-bold text-h4 m-0 p-0 mb-5" data-v-a20c6082>${ssrInterpolate(_ctx.$t("products"))}</h1><div class="mt-md-10 mt-xs-10 mt-sm-0" data-v-a20c6082><div class="d-flex ga-md-3 ga-xs-0 justify-center align-center p-10" data-v-a20c6082>`);
      _push(ssrRenderComponent(VMenu, {
        modelValue: unref(isMenuOpen),
        "onUpdate:modelValue": ($event) => isRef(isMenuOpen) ? isMenuOpen.value = $event : null
      }, {
        activator: withCtx(({ props }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VBtn, mergeProps({
              color: "#0F9D58",
              class: "button-menu d-md-flex d-none align-items-center py-5"
            }, props), {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(activFilter).content[_ctx.$i18n.locale].title)} `);
                  _push3(ssrRenderComponent(VIcon, {
                    small: "",
                    right: ""
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`mdi-menu-down`);
                      } else {
                        return [
                          createTextVNode("mdi-menu-down")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(activFilter).content[_ctx.$i18n.locale].title) + " ", 1),
                    createVNode(VIcon, {
                      small: "",
                      right: ""
                    }, {
                      default: withCtx(() => [
                        createTextVNode("mdi-menu-down")
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VBtn, mergeProps({
                color: "#0F9D58",
                class: "button-menu d-md-flex d-none align-items-center py-5"
              }, props), {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(activFilter).content[_ctx.$i18n.locale].title) + " ", 1),
                  createVNode(VIcon, {
                    small: "",
                    right: ""
                  }, {
                    default: withCtx(() => [
                      createTextVNode("mdi-menu-down")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, 1040)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VList, { class: "d-md-flex flex-column d-xs-flex d-none" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(store).category, ({ id, content }) => {
                    _push3(ssrRenderComponent(VListItem, {
                      key: id,
                      onClick: ($event) => changeLocale(id)
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(VListItemTitle, null, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(`${ssrInterpolate(content[_ctx.$i18n.locale].title)}`);
                              } else {
                                return [
                                  createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(VListItemTitle, null, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                              ]),
                              _: 2
                            }, 1024)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(store).category, ({ id, content }) => {
                      return openBlock(), createBlock(VListItem, {
                        key: id,
                        onClick: ($event) => changeLocale(id)
                      }, {
                        default: withCtx(() => [
                          createVNode(VListItemTitle, null, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VList, { class: "d-md-flex flex-column d-xs-flex d-none" }, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(store).category, ({ id, content }) => {
                    return openBlock(), createBlock(VListItem, {
                      key: id,
                      onClick: ($event) => changeLocale(id)
                    }, {
                      default: withCtx(() => [
                        createVNode(VListItemTitle, null, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1032, ["onClick"]);
                  }), 128))
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(VMenu, {
        modelValue: unref(isMenuManufacture),
        "onUpdate:modelValue": ($event) => isRef(isMenuManufacture) ? isMenuManufacture.value = $event : null
      }, {
        activator: withCtx(({ props }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VBtn, mergeProps({
              color: "#0F9D58",
              class: "button-menu d-md-flex d-none align-center py-5"
            }, props), {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(defaultManufactue).content[_ctx.$i18n.locale].title)} `);
                  _push3(ssrRenderComponent(VIcon, {
                    small: "",
                    right: ""
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`mdi-menu-down`);
                      } else {
                        return [
                          createTextVNode("mdi-menu-down")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(defaultManufactue).content[_ctx.$i18n.locale].title) + " ", 1),
                    createVNode(VIcon, {
                      small: "",
                      right: ""
                    }, {
                      default: withCtx(() => [
                        createTextVNode("mdi-menu-down")
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VBtn, mergeProps({
                color: "#0F9D58",
                class: "button-menu d-md-flex d-none align-center py-5"
              }, props), {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(defaultManufactue).content[_ctx.$i18n.locale].title) + " ", 1),
                  createVNode(VIcon, {
                    small: "",
                    right: ""
                  }, {
                    default: withCtx(() => [
                      createTextVNode("mdi-menu-down")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, 1040)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VList, { class: "d-md-flex flex-column d-xs-flex d-none" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(store).manufacturer, ({ id, content }) => {
                    _push3(ssrRenderComponent(VListItem, {
                      key: id,
                      onClick: ($event) => changeManufacturer(id)
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(VListItemTitle, null, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(`${ssrInterpolate(content[_ctx.$i18n.locale].title)}`);
                              } else {
                                return [
                                  createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(VListItemTitle, null, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                              ]),
                              _: 2
                            }, 1024)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufacturer, ({ id, content }) => {
                      return openBlock(), createBlock(VListItem, {
                        key: id,
                        onClick: ($event) => changeManufacturer(id)
                      }, {
                        default: withCtx(() => [
                          createVNode(VListItemTitle, null, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VList, { class: "d-md-flex flex-column d-xs-flex d-none" }, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufacturer, ({ id, content }) => {
                    return openBlock(), createBlock(VListItem, {
                      key: id,
                      onClick: ($event) => changeManufacturer(id)
                    }, {
                      default: withCtx(() => [
                        createVNode(VListItemTitle, null, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1032, ["onClick"]);
                  }), 128))
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(VMenu, {
        modelValue: unref(isMenustock),
        "onUpdate:modelValue": ($event) => isRef(isMenustock) ? isMenustock.value = $event : null
      }, {
        activator: withCtx(({ props }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VBtn, mergeProps({
              color: "#0F9D58",
              class: "button-menu d-md-flex d-none align-center py-5"
            }, props), {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(activStock).content[_ctx.$i18n.locale].title)} `);
                  _push3(ssrRenderComponent(VIcon, {
                    small: "",
                    right: ""
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`mdi-menu-down`);
                      } else {
                        return [
                          createTextVNode("mdi-menu-down")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(activStock).content[_ctx.$i18n.locale].title) + " ", 1),
                    createVNode(VIcon, {
                      small: "",
                      right: ""
                    }, {
                      default: withCtx(() => [
                        createTextVNode("mdi-menu-down")
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VBtn, mergeProps({
                color: "#0F9D58",
                class: "button-menu d-md-flex d-none align-center py-5"
              }, props), {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(activStock).content[_ctx.$i18n.locale].title) + " ", 1),
                  createVNode(VIcon, {
                    small: "",
                    right: ""
                  }, {
                    default: withCtx(() => [
                      createTextVNode("mdi-menu-down")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, 1040)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VList, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VListItem, {
                    onClick: ($event) => selectOption(true)
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VListItemTitle, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`${ssrInterpolate(_ctx.$t("yes"))}`);
                            } else {
                              return [
                                createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VListItemTitle, null, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(VListItem, {
                    onClick: ($event) => selectOption(false)
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VListItemTitle, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`${ssrInterpolate(_ctx.$t("no"))}`);
                            } else {
                              return [
                                createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VListItemTitle, null, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(VListItem, {
                    onClick: ($event) => selectOption("")
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VListItemTitle, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`${ssrInterpolate(_ctx.$t("other"))}`);
                            } else {
                              return [
                                createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VListItemTitle, null, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VListItem, {
                      onClick: ($event) => selectOption(true)
                    }, {
                      default: withCtx(() => [
                        createVNode(VListItemTitle, null, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["onClick"]),
                    createVNode(VListItem, {
                      onClick: ($event) => selectOption(false)
                    }, {
                      default: withCtx(() => [
                        createVNode(VListItemTitle, null, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["onClick"]),
                    createVNode(VListItem, {
                      onClick: ($event) => selectOption("")
                    }, {
                      default: withCtx(() => [
                        createVNode(VListItemTitle, null, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VList, null, {
                default: withCtx(() => [
                  createVNode(VListItem, {
                    onClick: ($event) => selectOption(true)
                  }, {
                    default: withCtx(() => [
                      createVNode(VListItemTitle, null, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["onClick"]),
                  createVNode(VListItem, {
                    onClick: ($event) => selectOption(false)
                  }, {
                    default: withCtx(() => [
                      createVNode(VListItemTitle, null, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["onClick"]),
                  createVNode(VListItem, {
                    onClick: ($event) => selectOption("")
                  }, {
                    default: withCtx(() => [
                      createVNode(VListItemTitle, null, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(VSheet, { class: "ml-auto my-search" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form data-v-a20c6082${_scopeId}><div class="d-flex my-search" data-v-a20c6082${_scopeId}><input class="input-inset" type="text"${ssrRenderAttr("value", unref(store).search)}${ssrRenderAttr("placeholder", _ctx.$t("search"))} data-v-a20c6082${_scopeId}>`);
            _push2(ssrRenderComponent(VBtn, {
              icon: "mdi-magnify",
              class: "button-menu mx-1",
              color: "#0F9D58",
              width: "48",
              type: "submit",
              height: "48"
            }, null, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                onSubmit: withModifiers(onClick, ["prevent"])
              }, [
                createVNode("div", { class: "d-flex my-search" }, [
                  withDirectives(createVNode("input", {
                    class: "input-inset",
                    type: "text",
                    "onUpdate:modelValue": ($event) => unref(store).search = $event,
                    placeholder: _ctx.$t("search")
                  }, null, 8, ["onUpdate:modelValue", "placeholder"]), [
                    [vModelText, unref(store).search]
                  ]),
                  createVNode(VBtn, {
                    icon: "mdi-magnify",
                    class: "button-menu mx-1",
                    color: "#0F9D58",
                    width: "48",
                    type: "submit",
                    height: "48"
                  })
                ])
              ], 32)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(VDialog, { width: "500" }, {
        activator: withCtx(({ props }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VBtn, mergeProps({ icon: "mdi-filter" }, props, {
              class: "d-flex d-md-none align-center justify-center button-menu mt-md-0 mr-5 mx-0",
              color: "#0F9D58"
            }), null, _parent2, _scopeId));
          } else {
            return [
              createVNode(VBtn, mergeProps({ icon: "mdi-filter" }, props, {
                class: "d-flex d-md-none align-center justify-center button-menu mt-md-0 mr-5 mx-0",
                color: "#0F9D58"
              }), null, 16)
            ];
          }
        }),
        default: withCtx(({ isActive }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VCard, {
              title: "\u0424\u0438\u043B\u044C\u0442\u0440\u0430\u0446\u0438\u044F",
              class: "d-flex justify-center align-center py-10 ga-5",
              style: { "border-radius": "30px" }
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VCardText, null, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VMenu, {
                          modelValue: unref(isMenuOpen),
                          "onUpdate:modelValue": ($event) => isRef(isMenuOpen) ? isMenuOpen.value = $event : null
                        }, {
                          activator: withCtx(({ props }, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VBtn, mergeProps({
                                color: "#0F9D58",
                                width: "100%",
                                class: "button-menu d-flex align-items-center my-5"
                              }, props), {
                                default: withCtx((_3, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`${ssrInterpolate(unref(activFilter).content[_ctx.$i18n.locale].title)} `);
                                    _push6(ssrRenderComponent(VIcon, {
                                      small: "",
                                      right: ""
                                    }, {
                                      default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`mdi-menu-down`);
                                        } else {
                                          return [
                                            createTextVNode("mdi-menu-down")
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createTextVNode(toDisplayString(unref(activFilter).content[_ctx.$i18n.locale].title) + " ", 1),
                                      createVNode(VIcon, {
                                        small: "",
                                        right: ""
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("mdi-menu-down")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VBtn, mergeProps({
                                  color: "#0F9D58",
                                  width: "100%",
                                  class: "button-menu d-flex align-items-center my-5"
                                }, props), {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(unref(activFilter).content[_ctx.$i18n.locale].title) + " ", 1),
                                    createVNode(VIcon, {
                                      small: "",
                                      right: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("mdi-menu-down")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 2
                                }, 1040)
                              ];
                            }
                          }),
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VList, null, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<!--[-->`);
                                    ssrRenderList(unref(store).category, ({ id, content }) => {
                                      _push6(ssrRenderComponent(VListItem, {
                                        key: id,
                                        onClick: ($event) => changeLocale(id)
                                      }, {
                                        default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(ssrRenderComponent(VListItemTitle, null, {
                                              default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(`${ssrInterpolate(content[_ctx.$i18n.locale].title)}`);
                                                } else {
                                                  return [
                                                    createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                          } else {
                                            return [
                                              createVNode(VListItemTitle, null, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                                ]),
                                                _: 2
                                              }, 1024)
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                    });
                                    _push6(`<!--]-->`);
                                  } else {
                                    return [
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(store).category, ({ id, content }) => {
                                        return openBlock(), createBlock(VListItem, {
                                          key: id,
                                          onClick: ($event) => changeLocale(id)
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(VListItemTitle, null, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                              ]),
                                              _: 2
                                            }, 1024)
                                          ]),
                                          _: 2
                                        }, 1032, ["onClick"]);
                                      }), 128))
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VList, null, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(store).category, ({ id, content }) => {
                                      return openBlock(), createBlock(VListItem, {
                                        key: id,
                                        onClick: ($event) => changeLocale(id)
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(VListItemTitle, null, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                            ]),
                                            _: 2
                                          }, 1024)
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"]);
                                    }), 128))
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(VMenu, {
                          modelValue: unref(isMenuManufacture),
                          "onUpdate:modelValue": ($event) => isRef(isMenuManufacture) ? isMenuManufacture.value = $event : null
                        }, {
                          activator: withCtx(({ props }, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VBtn, mergeProps({
                                color: "#0F9D58",
                                width: "100%",
                                class: "button-menu d-flex align-center my-5"
                              }, props), {
                                default: withCtx((_3, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`${ssrInterpolate(unref(defaultManufactue).content[_ctx.$i18n.locale].title)} `);
                                    _push6(ssrRenderComponent(VIcon, {
                                      small: "",
                                      right: ""
                                    }, {
                                      default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`mdi-menu-down`);
                                        } else {
                                          return [
                                            createTextVNode("mdi-menu-down")
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createTextVNode(toDisplayString(unref(defaultManufactue).content[_ctx.$i18n.locale].title) + " ", 1),
                                      createVNode(VIcon, {
                                        small: "",
                                        right: ""
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("mdi-menu-down")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VBtn, mergeProps({
                                  color: "#0F9D58",
                                  width: "100%",
                                  class: "button-menu d-flex align-center my-5"
                                }, props), {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(unref(defaultManufactue).content[_ctx.$i18n.locale].title) + " ", 1),
                                    createVNode(VIcon, {
                                      small: "",
                                      right: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("mdi-menu-down")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 2
                                }, 1040)
                              ];
                            }
                          }),
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VList, null, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<!--[-->`);
                                    ssrRenderList(unref(store).manufacturer, ({ id, content }) => {
                                      _push6(ssrRenderComponent(VListItem, {
                                        key: id,
                                        onClick: ($event) => changeManufacturer(id)
                                      }, {
                                        default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(ssrRenderComponent(VListItemTitle, null, {
                                              default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(`${ssrInterpolate(content[_ctx.$i18n.locale].title)}`);
                                                } else {
                                                  return [
                                                    createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                          } else {
                                            return [
                                              createVNode(VListItemTitle, null, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                                ]),
                                                _: 2
                                              }, 1024)
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                    });
                                    _push6(`<!--]-->`);
                                  } else {
                                    return [
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufacturer, ({ id, content }) => {
                                        return openBlock(), createBlock(VListItem, {
                                          key: id,
                                          onClick: ($event) => changeManufacturer(id)
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(VListItemTitle, null, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                              ]),
                                              _: 2
                                            }, 1024)
                                          ]),
                                          _: 2
                                        }, 1032, ["onClick"]);
                                      }), 128))
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VList, null, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufacturer, ({ id, content }) => {
                                      return openBlock(), createBlock(VListItem, {
                                        key: id,
                                        onClick: ($event) => changeManufacturer(id)
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(VListItemTitle, null, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                            ]),
                                            _: 2
                                          }, 1024)
                                        ]),
                                        _: 2
                                      }, 1032, ["onClick"]);
                                    }), 128))
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(VMenu, {
                          modelValue: unref(isMenustock),
                          "onUpdate:modelValue": ($event) => isRef(isMenustock) ? isMenustock.value = $event : null
                        }, {
                          activator: withCtx(({ props }, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VBtn, mergeProps({
                                color: "#0F9D58",
                                width: "100%",
                                class: "button-menu d-flex align-center my-5"
                              }, props), {
                                default: withCtx((_3, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`${ssrInterpolate(unref(activStock).content[_ctx.$i18n.locale].title)} `);
                                    _push6(ssrRenderComponent(VIcon, {
                                      small: "",
                                      right: ""
                                    }, {
                                      default: withCtx((_4, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`mdi-menu-down`);
                                        } else {
                                          return [
                                            createTextVNode("mdi-menu-down")
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createTextVNode(toDisplayString(unref(activStock).content[_ctx.$i18n.locale].title) + " ", 1),
                                      createVNode(VIcon, {
                                        small: "",
                                        right: ""
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("mdi-menu-down")
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VBtn, mergeProps({
                                  color: "#0F9D58",
                                  width: "100%",
                                  class: "button-menu d-flex align-center my-5"
                                }, props), {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(unref(activStock).content[_ctx.$i18n.locale].title) + " ", 1),
                                    createVNode(VIcon, {
                                      small: "",
                                      right: ""
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("mdi-menu-down")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 2
                                }, 1040)
                              ];
                            }
                          }),
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VList, null, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(VListItem, {
                                      onClick: ($event) => selectOption(true)
                                    }, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(VListItemTitle, null, {
                                            default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(`${ssrInterpolate(_ctx.$t("yes"))}`);
                                              } else {
                                                return [
                                                  createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(VListItemTitle, null, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                                              ]),
                                              _: 1
                                            })
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(VListItem, {
                                      onClick: ($event) => selectOption(false)
                                    }, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(VListItemTitle, null, {
                                            default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(`${ssrInterpolate(_ctx.$t("no"))}`);
                                              } else {
                                                return [
                                                  createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(VListItemTitle, null, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                                              ]),
                                              _: 1
                                            })
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(VListItem, {
                                      onClick: ($event) => selectOption("")
                                    }, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(VListItemTitle, null, {
                                            default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(`${ssrInterpolate(_ctx.$t("other"))}`);
                                              } else {
                                                return [
                                                  createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(VListItemTitle, null, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                                              ]),
                                              _: 1
                                            })
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(VListItem, {
                                        onClick: ($event) => selectOption(true)
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(VListItemTitle, null, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"]),
                                      createVNode(VListItem, {
                                        onClick: ($event) => selectOption(false)
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(VListItemTitle, null, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"]),
                                      createVNode(VListItem, {
                                        onClick: ($event) => selectOption("")
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(VListItemTitle, null, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VList, null, {
                                  default: withCtx(() => [
                                    createVNode(VListItem, {
                                      onClick: ($event) => selectOption(true)
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(VListItemTitle, null, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"]),
                                    createVNode(VListItem, {
                                      onClick: ($event) => selectOption(false)
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(VListItemTitle, null, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"]),
                                    createVNode(VListItem, {
                                      onClick: ($event) => selectOption("")
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(VListItemTitle, null, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"])
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VMenu, {
                            modelValue: unref(isMenuOpen),
                            "onUpdate:modelValue": ($event) => isRef(isMenuOpen) ? isMenuOpen.value = $event : null
                          }, {
                            activator: withCtx(({ props }) => [
                              createVNode(VBtn, mergeProps({
                                color: "#0F9D58",
                                width: "100%",
                                class: "button-menu d-flex align-items-center my-5"
                              }, props), {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(unref(activFilter).content[_ctx.$i18n.locale].title) + " ", 1),
                                  createVNode(VIcon, {
                                    small: "",
                                    right: ""
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("mdi-menu-down")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 2
                              }, 1040)
                            ]),
                            default: withCtx(() => [
                              createVNode(VList, null, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList(unref(store).category, ({ id, content }) => {
                                    return openBlock(), createBlock(VListItem, {
                                      key: id,
                                      onClick: ($event) => changeLocale(id)
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(VListItemTitle, null, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                          ]),
                                          _: 2
                                        }, 1024)
                                      ]),
                                      _: 2
                                    }, 1032, ["onClick"]);
                                  }), 128))
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(VMenu, {
                            modelValue: unref(isMenuManufacture),
                            "onUpdate:modelValue": ($event) => isRef(isMenuManufacture) ? isMenuManufacture.value = $event : null
                          }, {
                            activator: withCtx(({ props }) => [
                              createVNode(VBtn, mergeProps({
                                color: "#0F9D58",
                                width: "100%",
                                class: "button-menu d-flex align-center my-5"
                              }, props), {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(unref(defaultManufactue).content[_ctx.$i18n.locale].title) + " ", 1),
                                  createVNode(VIcon, {
                                    small: "",
                                    right: ""
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("mdi-menu-down")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 2
                              }, 1040)
                            ]),
                            default: withCtx(() => [
                              createVNode(VList, null, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufacturer, ({ id, content }) => {
                                    return openBlock(), createBlock(VListItem, {
                                      key: id,
                                      onClick: ($event) => changeManufacturer(id)
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(VListItemTitle, null, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                          ]),
                                          _: 2
                                        }, 1024)
                                      ]),
                                      _: 2
                                    }, 1032, ["onClick"]);
                                  }), 128))
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(VMenu, {
                            modelValue: unref(isMenustock),
                            "onUpdate:modelValue": ($event) => isRef(isMenustock) ? isMenustock.value = $event : null
                          }, {
                            activator: withCtx(({ props }) => [
                              createVNode(VBtn, mergeProps({
                                color: "#0F9D58",
                                width: "100%",
                                class: "button-menu d-flex align-center my-5"
                              }, props), {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(unref(activStock).content[_ctx.$i18n.locale].title) + " ", 1),
                                  createVNode(VIcon, {
                                    small: "",
                                    right: ""
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode("mdi-menu-down")
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 2
                              }, 1040)
                            ]),
                            default: withCtx(() => [
                              createVNode(VList, null, {
                                default: withCtx(() => [
                                  createVNode(VListItem, {
                                    onClick: ($event) => selectOption(true)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(VListItemTitle, null, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"]),
                                  createVNode(VListItem, {
                                    onClick: ($event) => selectOption(false)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(VListItemTitle, null, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"]),
                                  createVNode(VListItem, {
                                    onClick: ($event) => selectOption("")
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(VListItemTitle, null, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VCardText, null, {
                      default: withCtx(() => [
                        createVNode(VMenu, {
                          modelValue: unref(isMenuOpen),
                          "onUpdate:modelValue": ($event) => isRef(isMenuOpen) ? isMenuOpen.value = $event : null
                        }, {
                          activator: withCtx(({ props }) => [
                            createVNode(VBtn, mergeProps({
                              color: "#0F9D58",
                              width: "100%",
                              class: "button-menu d-flex align-items-center my-5"
                            }, props), {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(unref(activFilter).content[_ctx.$i18n.locale].title) + " ", 1),
                                createVNode(VIcon, {
                                  small: "",
                                  right: ""
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("mdi-menu-down")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 2
                            }, 1040)
                          ]),
                          default: withCtx(() => [
                            createVNode(VList, null, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList(unref(store).category, ({ id, content }) => {
                                  return openBlock(), createBlock(VListItem, {
                                    key: id,
                                    onClick: ($event) => changeLocale(id)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(VListItemTitle, null, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                        ]),
                                        _: 2
                                      }, 1024)
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"]);
                                }), 128))
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(VMenu, {
                          modelValue: unref(isMenuManufacture),
                          "onUpdate:modelValue": ($event) => isRef(isMenuManufacture) ? isMenuManufacture.value = $event : null
                        }, {
                          activator: withCtx(({ props }) => [
                            createVNode(VBtn, mergeProps({
                              color: "#0F9D58",
                              width: "100%",
                              class: "button-menu d-flex align-center my-5"
                            }, props), {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(unref(defaultManufactue).content[_ctx.$i18n.locale].title) + " ", 1),
                                createVNode(VIcon, {
                                  small: "",
                                  right: ""
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("mdi-menu-down")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 2
                            }, 1040)
                          ]),
                          default: withCtx(() => [
                            createVNode(VList, null, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufacturer, ({ id, content }) => {
                                  return openBlock(), createBlock(VListItem, {
                                    key: id,
                                    onClick: ($event) => changeManufacturer(id)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(VListItemTitle, null, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                        ]),
                                        _: 2
                                      }, 1024)
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"]);
                                }), 128))
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(VMenu, {
                          modelValue: unref(isMenustock),
                          "onUpdate:modelValue": ($event) => isRef(isMenustock) ? isMenustock.value = $event : null
                        }, {
                          activator: withCtx(({ props }) => [
                            createVNode(VBtn, mergeProps({
                              color: "#0F9D58",
                              width: "100%",
                              class: "button-menu d-flex align-center my-5"
                            }, props), {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(unref(activStock).content[_ctx.$i18n.locale].title) + " ", 1),
                                createVNode(VIcon, {
                                  small: "",
                                  right: ""
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("mdi-menu-down")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 2
                            }, 1040)
                          ]),
                          default: withCtx(() => [
                            createVNode(VList, null, {
                              default: withCtx(() => [
                                createVNode(VListItem, {
                                  onClick: ($event) => selectOption(true)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(VListItemTitle, null, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["onClick"]),
                                createVNode(VListItem, {
                                  onClick: ($event) => selectOption(false)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(VListItemTitle, null, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["onClick"]),
                                createVNode(VListItem, {
                                  onClick: ($event) => selectOption("")
                                }, {
                                  default: withCtx(() => [
                                    createVNode(VListItemTitle, null, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["onClick"])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VCard, {
                title: "\u0424\u0438\u043B\u044C\u0442\u0440\u0430\u0446\u0438\u044F",
                class: "d-flex justify-center align-center py-10 ga-5",
                style: { "border-radius": "30px" }
              }, {
                default: withCtx(() => [
                  createVNode(VCardText, null, {
                    default: withCtx(() => [
                      createVNode(VMenu, {
                        modelValue: unref(isMenuOpen),
                        "onUpdate:modelValue": ($event) => isRef(isMenuOpen) ? isMenuOpen.value = $event : null
                      }, {
                        activator: withCtx(({ props }) => [
                          createVNode(VBtn, mergeProps({
                            color: "#0F9D58",
                            width: "100%",
                            class: "button-menu d-flex align-items-center my-5"
                          }, props), {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(unref(activFilter).content[_ctx.$i18n.locale].title) + " ", 1),
                              createVNode(VIcon, {
                                small: "",
                                right: ""
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("mdi-menu-down")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1040)
                        ]),
                        default: withCtx(() => [
                          createVNode(VList, null, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(store).category, ({ id, content }) => {
                                return openBlock(), createBlock(VListItem, {
                                  key: id,
                                  onClick: ($event) => changeLocale(id)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(VListItemTitle, null, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                      ]),
                                      _: 2
                                    }, 1024)
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"]);
                              }), 128))
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(VMenu, {
                        modelValue: unref(isMenuManufacture),
                        "onUpdate:modelValue": ($event) => isRef(isMenuManufacture) ? isMenuManufacture.value = $event : null
                      }, {
                        activator: withCtx(({ props }) => [
                          createVNode(VBtn, mergeProps({
                            color: "#0F9D58",
                            width: "100%",
                            class: "button-menu d-flex align-center my-5"
                          }, props), {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(unref(defaultManufactue).content[_ctx.$i18n.locale].title) + " ", 1),
                              createVNode(VIcon, {
                                small: "",
                                right: ""
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("mdi-menu-down")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1040)
                        ]),
                        default: withCtx(() => [
                          createVNode(VList, null, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufacturer, ({ id, content }) => {
                                return openBlock(), createBlock(VListItem, {
                                  key: id,
                                  onClick: ($event) => changeManufacturer(id)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(VListItemTitle, null, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(content[_ctx.$i18n.locale].title), 1)
                                      ]),
                                      _: 2
                                    }, 1024)
                                  ]),
                                  _: 2
                                }, 1032, ["onClick"]);
                              }), 128))
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(VMenu, {
                        modelValue: unref(isMenustock),
                        "onUpdate:modelValue": ($event) => isRef(isMenustock) ? isMenustock.value = $event : null
                      }, {
                        activator: withCtx(({ props }) => [
                          createVNode(VBtn, mergeProps({
                            color: "#0F9D58",
                            width: "100%",
                            class: "button-menu d-flex align-center my-5"
                          }, props), {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(unref(activStock).content[_ctx.$i18n.locale].title) + " ", 1),
                              createVNode(VIcon, {
                                small: "",
                                right: ""
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("mdi-menu-down")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 2
                          }, 1040)
                        ]),
                        default: withCtx(() => [
                          createVNode(VList, null, {
                            default: withCtx(() => [
                              createVNode(VListItem, {
                                onClick: ($event) => selectOption(true)
                              }, {
                                default: withCtx(() => [
                                  createVNode(VListItemTitle, null, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(_ctx.$t("yes")), 1)
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["onClick"]),
                              createVNode(VListItem, {
                                onClick: ($event) => selectOption(false)
                              }, {
                                default: withCtx(() => [
                                  createVNode(VListItemTitle, null, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(_ctx.$t("no")), 1)
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["onClick"]),
                              createVNode(VListItem, {
                                onClick: ($event) => selectOption("")
                              }, {
                                default: withCtx(() => [
                                  createVNode(VListItemTitle, null, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(_ctx.$t("other")), 1)
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["onClick"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="food-item-wrap all" data-v-a20c6082>`);
      if (unref(store).products.length > 0) {
        _push(`<!--[-->`);
        ssrRenderList(unref(store).products, ({ id, content, price, old_price, sale, image, active }) => {
          _push(`<div class="food-item" data-v-a20c6082><div class="item-wrap play-on-scroll" data-v-a20c6082><div class="item-img" data-v-a20c6082>`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: "/products/" + id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<img class="img-holder bg-img"${ssrRenderAttr("src", image != null ? image : "/noimage.png")} alt="" data-v-a20c6082${_scopeId}>`);
              } else {
                return [
                  createVNode("img", {
                    class: "img-holder bg-img",
                    src: image != null ? image : "/noimage.png",
                    alt: ""
                  }, null, 8, ["src"])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div><div class="item-info" data-v-a20c6082><h3 data-v-a20c6082>${ssrInterpolate(truncateString(content[_ctx.$i18n.locale].title, 14))}</h3><div class="item-info-body" data-v-a20c6082><h4 data-v-a20c6082>${ssrInterpolate(price)} ${ssrInterpolate(_ctx.$t("price"))} `);
          if (sale === true) {
            _push(`<s class="my-style" data-v-a20c6082>${ssrInterpolate(old_price)} ${ssrInterpolate(_ctx.$t("price"))}</s>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</h4>`);
          _push(ssrRenderComponent(VSnackbar, {
            color: "#0F9D58",
            location: "top",
            timeout: 2e3
          }, {
            activator: withCtx(({ props }, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(VBtn, mergeProps({
                  disabled: !active
                }, props, {
                  class: "cart-btn",
                  icon: active ? "mdi-cart" : "mdi-cart-off",
                  color: active ? "#0F9D58" : "#FF0000",
                  onClick: ($event) => unref(addToCart)(id)
                }), null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(VBtn, mergeProps({
                    disabled: !active
                  }, props, {
                    class: "cart-btn",
                    icon: active ? "mdi-cart" : "mdi-cart-off",
                    color: active ? "#0F9D58" : "#FF0000",
                    onClick: ($event) => unref(addToCart)(id)
                  }), null, 16, ["disabled", "icon", "color", "onClick"])
                ];
              }
            }),
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="d-flex ga-3 align-center justify-center" data-v-a20c6082${_scopeId}><h4 data-v-a20c6082${_scopeId}>\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u043E \u0432 \u041A\u043E\u0440\u0437\u0438\u043D\u0443</h4>`);
                _push2(ssrRenderComponent(VBtn, {
                  "prepend-icon": "mdi-cart",
                  color: "#FFF",
                  class: "btn-add-snack"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_nuxt_link, { to: "/basket" }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`\u041F\u0435\u0440\u0435\u0439\u0442\u0438`);
                          } else {
                            return [
                              createTextVNode("\u041F\u0435\u0440\u0435\u0439\u0442\u0438")
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(_component_nuxt_link, { to: "/basket" }, {
                          default: withCtx(() => [
                            createTextVNode("\u041F\u0435\u0440\u0435\u0439\u0442\u0438")
                          ]),
                          _: 1
                        })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                return [
                  createVNode("div", { class: "d-flex ga-3 align-center justify-center" }, [
                    createVNode("h4", null, "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u043E \u0432 \u041A\u043E\u0440\u0437\u0438\u043D\u0443"),
                    createVNode(VBtn, {
                      "prepend-icon": "mdi-cart",
                      color: "#FFF",
                      class: "btn-add-snack"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_nuxt_link, { to: "/basket" }, {
                          default: withCtx(() => [
                            createTextVNode("\u041F\u0435\u0440\u0435\u0439\u0442\u0438")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div></div></div></div>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<div class="centered-container" data-v-a20c6082><img${ssrRenderAttr("src", _imports_0)} alt="No Products Available" class="centered-image" data-v-a20c6082></div>`);
      }
      _push(`</div><div data-v-a20c6082>`);
      _push(ssrRenderComponent(VPagination, {
        modelValue: unref(store).pageAPI,
        "onUpdate:modelValue": ($event) => unref(store).pageAPI = $event,
        length: unref(store).pageCount,
        "total-visible": 5,
        onClick: handlePaginationClick
      }, null, _parent));
      _push(`</div></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/products/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a20c6082"]]);

export { index as default };
//# sourceMappingURL=index-4b69dc5d.mjs.map
