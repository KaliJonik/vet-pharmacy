import { _ as __nuxt_component_0 } from './nuxt-link-691e5b50.mjs';
import { computed, provide, onScopeDispose, toRef, createVNode, shallowRef, ref, mergeProps, withDirectives, Fragment, resolveDirective, inject, nextTick, withCtx, toDisplayString, unref, createTextVNode, isRef, withModifiers, useSSRContext } from 'vue';
import { p as propsFactory, I as IconValue, d as deepEqual, m as makeComponentProps, e as makeThemeProps, g as genericComponent, f as useProxiedModel, h as getUid, j as provideDefaults, k as useRender, l as filterInputAttrs, q as omit, s as useRtl, w as wrapInArray, o as matchesSelector, t as productStore, v as useAuthToken, x as useAuth } from '../server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_0 } from './nodataimage-39aadd60.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import { m as makeDensityProps, R as Ripple, V as VIcon, a as makeTagProps, u as useDensity, b as useTextColor, c as useBackgroundColor, d as VBtn } from './VBtn-55c932b0.mjs';
import { V as VLabel, m as makeVInputProps, u as useFocus, a as VInput, b as VRow, c as VStepper, d as VStepperHeader, e as VStepperItem, f as VStepperWindow, g as VStepperWindowItem, h as VCol, i as VForm, j as VTextField } from './VTextField-17db1185.mjs';
import { V as VDialog } from './VDialog-13e4da20.mjs';
import { V as VDivider, a as VCard, b as VCardActions } from './VSheet-f502d2db.mjs';
import { V as VTabs, a as VWindow, b as VWindowItem } from './VTabs-f421e6b8.mjs';
import { c as createSimpleFunctional, V as VCardText } from './ssrBoot-66bca22f.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const VSelectionControlGroupSymbol = Symbol.for("vuetify:selection-control-group");
const makeSelectionControlGroupProps = propsFactory({
  color: String,
  disabled: {
    type: Boolean,
    default: null
  },
  defaultsTarget: String,
  error: Boolean,
  id: String,
  inline: Boolean,
  falseIcon: IconValue,
  trueIcon: IconValue,
  ripple: {
    type: Boolean,
    default: true
  },
  multiple: {
    type: Boolean,
    default: null
  },
  name: String,
  readonly: Boolean,
  modelValue: null,
  type: String,
  valueComparator: {
    type: Function,
    default: deepEqual
  },
  ...makeComponentProps(),
  ...makeDensityProps(),
  ...makeThemeProps()
}, "SelectionControlGroup");
const makeVSelectionControlGroupProps = propsFactory({
  ...makeSelectionControlGroupProps({
    defaultsTarget: "VSelectionControl"
  })
}, "VSelectionControlGroup");
genericComponent()({
  name: "VSelectionControlGroup",
  props: makeVSelectionControlGroupProps(),
  emits: {
    "update:modelValue": (val) => true
  },
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const modelValue = useProxiedModel(props, "modelValue");
    const uid = getUid();
    const id = computed(() => props.id || `v-selection-control-group-${uid}`);
    const name = computed(() => props.name || id.value);
    const updateHandlers = /* @__PURE__ */ new Set();
    provide(VSelectionControlGroupSymbol, {
      modelValue,
      forceUpdate: () => {
        updateHandlers.forEach((fn) => fn());
      },
      onForceUpdate: (cb) => {
        updateHandlers.add(cb);
        onScopeDispose(() => {
          updateHandlers.delete(cb);
        });
      }
    });
    provideDefaults({
      [props.defaultsTarget]: {
        color: toRef(props, "color"),
        disabled: toRef(props, "disabled"),
        density: toRef(props, "density"),
        error: toRef(props, "error"),
        inline: toRef(props, "inline"),
        modelValue,
        multiple: computed(() => !!props.multiple || props.multiple == null && Array.isArray(modelValue.value)),
        name,
        falseIcon: toRef(props, "falseIcon"),
        trueIcon: toRef(props, "trueIcon"),
        readonly: toRef(props, "readonly"),
        ripple: toRef(props, "ripple"),
        type: toRef(props, "type"),
        valueComparator: toRef(props, "valueComparator")
      }
    });
    useRender(() => {
      var _a;
      return createVNode("div", {
        "class": ["v-selection-control-group", {
          "v-selection-control-group--inline": props.inline
        }, props.class],
        "style": props.style,
        "role": props.type === "radio" ? "radiogroup" : void 0
      }, [(_a = slots.default) == null ? void 0 : _a.call(slots)]);
    });
    return {};
  }
});
const makeVSelectionControlProps = propsFactory({
  label: String,
  baseColor: String,
  trueValue: null,
  falseValue: null,
  value: null,
  ...makeComponentProps(),
  ...makeSelectionControlGroupProps()
}, "VSelectionControl");
function useSelectionControl(props) {
  const group = inject(VSelectionControlGroupSymbol, void 0);
  const {
    densityClasses
  } = useDensity(props);
  const modelValue = useProxiedModel(props, "modelValue");
  const trueValue = computed(() => props.trueValue !== void 0 ? props.trueValue : props.value !== void 0 ? props.value : true);
  const falseValue = computed(() => props.falseValue !== void 0 ? props.falseValue : false);
  const isMultiple = computed(() => !!props.multiple || props.multiple == null && Array.isArray(modelValue.value));
  const model = computed({
    get() {
      const val = group ? group.modelValue.value : modelValue.value;
      return isMultiple.value ? val.some((v) => props.valueComparator(v, trueValue.value)) : props.valueComparator(val, trueValue.value);
    },
    set(val) {
      if (props.readonly)
        return;
      const currentValue = val ? trueValue.value : falseValue.value;
      let newVal = currentValue;
      if (isMultiple.value) {
        newVal = val ? [...wrapInArray(modelValue.value), currentValue] : wrapInArray(modelValue.value).filter((item) => !props.valueComparator(item, trueValue.value));
      }
      if (group) {
        group.modelValue.value = newVal;
      } else {
        modelValue.value = newVal;
      }
    }
  });
  const {
    textColorClasses,
    textColorStyles
  } = useTextColor(computed(() => {
    if (props.error || props.disabled)
      return void 0;
    return model.value ? props.color : props.baseColor;
  }));
  const {
    backgroundColorClasses,
    backgroundColorStyles
  } = useBackgroundColor(computed(() => {
    return model.value && !props.error && !props.disabled ? props.color : void 0;
  }));
  const icon = computed(() => model.value ? props.trueIcon : props.falseIcon);
  return {
    group,
    densityClasses,
    trueValue,
    falseValue,
    model,
    textColorClasses,
    textColorStyles,
    backgroundColorClasses,
    backgroundColorStyles,
    icon
  };
}
const VSelectionControl = genericComponent()({
  name: "VSelectionControl",
  directives: {
    Ripple
  },
  inheritAttrs: false,
  props: makeVSelectionControlProps(),
  emits: {
    "update:modelValue": (val) => true
  },
  setup(props, _ref) {
    let {
      attrs,
      slots
    } = _ref;
    const {
      group,
      densityClasses,
      icon,
      model,
      textColorClasses,
      textColorStyles,
      backgroundColorClasses,
      backgroundColorStyles,
      trueValue
    } = useSelectionControl(props);
    const uid = getUid();
    const id = computed(() => props.id || `input-${uid}`);
    const isFocused = shallowRef(false);
    const isFocusVisible = shallowRef(false);
    const input = ref();
    group == null ? void 0 : group.onForceUpdate(() => {
      if (input.value) {
        input.value.checked = model.value;
      }
    });
    function onFocus(e) {
      isFocused.value = true;
      if (matchesSelector(e.target) !== false) {
        isFocusVisible.value = true;
      }
    }
    function onBlur() {
      isFocused.value = false;
      isFocusVisible.value = false;
    }
    function onInput(e) {
      if (props.readonly && group) {
        nextTick(() => group.forceUpdate());
      }
      model.value = e.target.checked;
    }
    useRender(() => {
      var _a2;
      var _a, _b;
      const label = slots.label ? slots.label({
        label: props.label,
        props: {
          for: id.value
        }
      }) : props.label;
      const [rootAttrs, inputAttrs] = filterInputAttrs(attrs);
      const inputNode = createVNode("input", mergeProps({
        "ref": input,
        "checked": model.value,
        "disabled": !!(props.readonly || props.disabled),
        "id": id.value,
        "onBlur": onBlur,
        "onFocus": onFocus,
        "onInput": onInput,
        "aria-disabled": !!(props.readonly || props.disabled),
        "type": props.type,
        "value": trueValue.value,
        "name": props.name,
        "aria-checked": props.type === "checkbox" ? model.value : void 0
      }, inputAttrs), null);
      return createVNode("div", mergeProps({
        "class": ["v-selection-control", {
          "v-selection-control--dirty": model.value,
          "v-selection-control--disabled": props.disabled,
          "v-selection-control--error": props.error,
          "v-selection-control--focused": isFocused.value,
          "v-selection-control--focus-visible": isFocusVisible.value,
          "v-selection-control--inline": props.inline
        }, densityClasses.value, props.class]
      }, rootAttrs, {
        "style": props.style
      }), [createVNode("div", {
        "class": ["v-selection-control__wrapper", textColorClasses.value],
        "style": textColorStyles.value
      }, [(_a = slots.default) == null ? void 0 : _a.call(slots, {
        backgroundColorClasses,
        backgroundColorStyles
      }), withDirectives(createVNode("div", {
        "class": ["v-selection-control__input"]
      }, [(_a2 = (_b = slots.input) == null ? void 0 : _b.call(slots, {
        model,
        textColorClasses,
        textColorStyles,
        backgroundColorClasses,
        backgroundColorStyles,
        inputNode,
        icon: icon.value,
        props: {
          onFocus,
          onBlur,
          id: id.value
        }
      })) != null ? _a2 : createVNode(Fragment, null, [icon.value && createVNode(VIcon, {
        "key": "icon",
        "icon": icon.value
      }, null), inputNode])]), [[resolveDirective("ripple"), props.ripple && [!props.disabled && !props.readonly, null, ["center", "circle"]]]])]), label && createVNode(VLabel, {
        "for": id.value,
        "clickable": true,
        "onClick": (e) => e.stopPropagation()
      }, {
        default: () => [label]
      })]);
    });
    return {
      isFocused,
      input
    };
  }
});
const makeVCheckboxBtnProps = propsFactory({
  indeterminate: Boolean,
  indeterminateIcon: {
    type: IconValue,
    default: "$checkboxIndeterminate"
  },
  ...makeVSelectionControlProps({
    falseIcon: "$checkboxOff",
    trueIcon: "$checkboxOn"
  })
}, "VCheckboxBtn");
const VCheckboxBtn = genericComponent()({
  name: "VCheckboxBtn",
  props: makeVCheckboxBtnProps(),
  emits: {
    "update:modelValue": (value) => true,
    "update:indeterminate": (val) => true
  },
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const indeterminate = useProxiedModel(props, "indeterminate");
    const model = useProxiedModel(props, "modelValue");
    function onChange(v) {
      if (indeterminate.value) {
        indeterminate.value = false;
      }
    }
    const falseIcon = computed(() => {
      return indeterminate.value ? props.indeterminateIcon : props.falseIcon;
    });
    const trueIcon = computed(() => {
      return indeterminate.value ? props.indeterminateIcon : props.trueIcon;
    });
    useRender(() => {
      const controlProps = omit(VSelectionControl.filterProps(props), ["modelValue"]);
      return createVNode(VSelectionControl, mergeProps(controlProps, {
        "modelValue": model.value,
        "onUpdate:modelValue": [($event) => model.value = $event, onChange],
        "class": ["v-checkbox-btn", props.class],
        "style": props.style,
        "type": "checkbox",
        "falseIcon": falseIcon.value,
        "trueIcon": trueIcon.value,
        "aria-checked": indeterminate.value ? "mixed" : void 0
      }), slots);
    });
    return {};
  }
});
const makeVCheckboxProps = propsFactory({
  ...makeVInputProps(),
  ...omit(makeVCheckboxBtnProps(), ["inline"])
}, "VCheckbox");
const VCheckbox = genericComponent()({
  name: "VCheckbox",
  inheritAttrs: false,
  props: makeVCheckboxProps(),
  emits: {
    "update:modelValue": (value) => true,
    "update:focused": (focused) => true
  },
  setup(props, _ref) {
    let {
      attrs,
      slots
    } = _ref;
    const model = useProxiedModel(props, "modelValue");
    const {
      isFocused,
      focus,
      blur
    } = useFocus(props);
    const uid = getUid();
    const id = computed(() => props.id || `checkbox-${uid}`);
    useRender(() => {
      const [rootAttrs, controlAttrs] = filterInputAttrs(attrs);
      const inputProps = VInput.filterProps(props);
      const checkboxProps = VCheckboxBtn.filterProps(props);
      return createVNode(VInput, mergeProps({
        "class": ["v-checkbox", props.class]
      }, rootAttrs, inputProps, {
        "modelValue": model.value,
        "onUpdate:modelValue": ($event) => model.value = $event,
        "id": id.value,
        "focused": isFocused.value,
        "style": props.style
      }), {
        ...slots,
        default: (_ref2) => {
          let {
            id: id2,
            messagesId,
            isDisabled,
            isReadonly
          } = _ref2;
          return createVNode(VCheckboxBtn, mergeProps(checkboxProps, {
            "id": id2.value,
            "aria-describedby": messagesId.value,
            "disabled": isDisabled.value,
            "readonly": isReadonly.value
          }, controlAttrs, {
            "modelValue": model.value,
            "onUpdate:modelValue": ($event) => model.value = $event,
            "onFocus": focus,
            "onBlur": blur
          }), slots);
        }
      });
    });
    return {};
  }
});
const makeVContainerProps = propsFactory({
  fluid: {
    type: Boolean,
    default: false
  },
  ...makeComponentProps(),
  ...makeTagProps()
}, "VContainer");
const VContainer = genericComponent()({
  name: "VContainer",
  props: makeVContainerProps(),
  setup(props, _ref) {
    let {
      slots
    } = _ref;
    const {
      rtlClasses
    } = useRtl();
    useRender(() => createVNode(props.tag, {
      "class": ["v-container", {
        "v-container--fluid": props.fluid
      }, rtlClasses.value, props.class],
      "style": props.style
    }, slots));
    return {};
  }
});
const VSpacer = createSimpleFunctional("v-spacer", "div", "VSpacer");
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const store = productStore();
    const dialog = ref(false);
    const visible = ref(false);
    const e1 = ref(1);
    const token = useAuthToken();
    const addSpacesToNumber = (number) => {
      return String(number).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    };
    const user = ref({
      phonenumber: "",
      password: ""
    });
    const createUser = ref({
      phone: "",
      password1: "",
      password2: ""
    });
    const order = ref({
      full_name: "",
      phone: "",
      address: null,
      is_delivery: false
    });
    const calcTotal = computed(() => {
      let total = 0;
      store.cards.forEach((item) => {
        total += item.price * item.quantity;
      });
      return total;
    });
    const { login, registrations, my_order } = useAuth();
    if (token.value) {
      e1.value++;
    }
    let tab = ref(0);
    const handleTabClick = (index2) => {
      tab.value = index2;
    };
    const valid = ref(false);
    const errorMessage = ref("");
    const errorStatus = ref("");
    const rules = {
      phonenumber: (value) => {
        const pattern = /^\+?\d{12}$/;
        return pattern.test(value) || "Your phone number should look like +998993332211";
      },
      phoneRequired: (value) => !!value || "You must enter your phone",
      passwordRequired: (value) => !!value || "Your password is required",
      passwordMatch: (value) => value === createUser.value.password1 || "Your passwords don't match",
      min: (v) => v.length >= 6 || "Your password must be at least 8 characters",
      fullName: (value) => {
        const pattern = /^[a-zA-Zа-яА-ЯёЁ\s]+$/;
        return pattern.test(value) || "Please enter a valid full name";
      },
      addres: (value) => {
        const pattern = /^[a-zA-Zа-яА-ЯёЁ\s,0-9]+$/;
        return pattern.test(value) || "Please enter a valid full name";
      }
    };
    const getAddressRules = computed(() => {
      return order.value.is_delivery ? [rules.addres] : [];
    });
    async function onLogin() {
      if (valid.value) {
        try {
          await login(user.value.phonenumber, user.value.password);
          await store.getUser();
          e1.value++;
        } catch (error) {
          console.error(error);
          errorMessage.value = "\u041D\u0435 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0439 \u043B\u043E\u0433\u0438\u043D \u0438\u043B\u0438 \u043F\u0430\u0440\u043E\u043B\u044C!!";
        }
      }
    }
    async function onRegistrations() {
      try {
        if (valid.value) {
          const { user: user2, status } = await registrations(createUser.value.phone, createUser.value.password1, createUser.value.password2);
          if (user2.value !== null && status !== "error") {
            await login(createUser.value.phone, createUser.value.password1);
            await store.getUser();
            e1.value++;
          } else {
            errorStatus.value = "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442";
          }
        }
      } catch (error) {
        console.error("Unexpected error during registration:", error);
      }
    }
    async function onMyorders() {
      try {
        if (valid.value) {
          if (order.value.is_delivery && !order.value.address) {
            console.log("Address is required for delivery but not provided.");
            return;
          }
          await my_order(order.value.full_name, order.value.phone, order.value.address, order.value.is_delivery);
          order.value.full_name = "";
          order.value.phone = "";
          order.value.address = "";
          order.value.is_delivery = "";
          localStorage.removeItem("cards");
          setTimeout(() => {
            window.location.reload();
          }, 2e3);
        }
      } catch (error) {
        console.error(error);
      }
    }
    const truncateString = (text, maxLength) => {
      if (text && text.length > maxLength) {
        return text.substring(0, maxLength) + "...";
      }
      return text;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: "bg-img bg-img-fixed",
        id: "food-menu-section",
        style: { "background-image": "url(/chicken.jpg)" }
      }, _attrs))} data-v-4d6f8a3a><div class="container" data-v-4d6f8a3a><div class="basket-list" data-v-4d6f8a3a><div class="container" data-v-4d6f8a3a><div class="title" data-v-4d6f8a3a><h1 class="title-basket order-hist mx-2" data-v-4d6f8a3a>${ssrInterpolate(_ctx.$t("basket"))}</h1>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/order-history",
        class: "my-orders"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h3 data-v-4d6f8a3a${_scopeId}>${ssrInterpolate(_ctx.$t("order_history"))}</h3>`);
          } else {
            return [
              createVNode("h3", null, toDisplayString(_ctx.$t("order_history")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (unref(store).cards.length > 0) {
        _push(`<div class="cart" data-v-4d6f8a3a><div class="products" data-v-4d6f8a3a><!--[-->`);
        ssrRenderList(unref(store).cards, (item, index2) => {
          _push(`<div class="product" data-v-4d6f8a3a>`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: "/products/" + item.id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<img class="img-produtc"${ssrRenderAttr("src", item && item.image || item && item.photos && item.photos[0] && item.photos[0].image || "/noimage.png")} data-v-4d6f8a3a${_scopeId}>`);
              } else {
                return [
                  createVNode("img", {
                    class: "img-produtc",
                    src: item && item.image || item && item.photos && item.photos[0] && item.photos[0].image || "/noimage.png"
                  }, null, 8, ["src"])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<div class="product-info" data-v-4d6f8a3a><h2 class="product-name" data-v-4d6f8a3a>${ssrInterpolate(truncateString(item.content[_ctx.$i18n.locale].title, 18))}</h2><h3 class="product-price" data-v-4d6f8a3a>${ssrInterpolate(addSpacesToNumber(item.price))} ${ssrInterpolate(_ctx.$t("price"))}</h3><div class="product-quantity" data-v-4d6f8a3a><button class="btn btn--minus" type="button" name="button" data-v-4d6f8a3a> - </button><input${ssrRenderAttr("value", item.quantity)} type="text" style="${ssrRenderStyle({ "background-color": "#fff" })}" data-v-4d6f8a3a><button class="btn btn--plus" type="button" name="button" data-v-4d6f8a3a> + </button><span class="mx-2" data-v-4d6f8a3a>${ssrInterpolate(item.content[_ctx.$i18n.locale].unit)}</span></div><div class="product-cost" data-v-4d6f8a3a><button class="btn btn--minus" type="button" name="button" data-v-4d6f8a3a> - </button><input${ssrRenderAttr("value", item.cost)} type="text" style="${ssrRenderStyle({ "background-color": "#fff" })}" data-v-4d6f8a3a><button class="btn btn--plus" type="button" name="button" data-v-4d6f8a3a> + </button></div><p class="product-remove" data-v-4d6f8a3a>`);
          _push(ssrRenderComponent(VIcon, {
            onClick: ($event) => unref(store).deleteCards(item.id)
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`mdi-delete`);
              } else {
                return [
                  createTextVNode("mdi-delete")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</p></div></div>`);
        });
        _push(`<!--]--></div><div class="cart-total" data-v-4d6f8a3a><p data-v-4d6f8a3a><span data-v-4d6f8a3a>${ssrInterpolate(_ctx.$t("total"))}: </span><span data-v-4d6f8a3a>${ssrInterpolate(addSpacesToNumber(unref(calcTotal)))} ${ssrInterpolate(_ctx.$t("price"))}</span></p><p data-v-4d6f8a3a><span data-v-4d6f8a3a>${ssrInterpolate(_ctx.$t("qty"))}: </span><span data-v-4d6f8a3a>${ssrInterpolate(unref(store).cards.length)}</span></p><div class="my-flex" data-v-4d6f8a3a></div>`);
        _push(ssrRenderComponent(VRow, { justify: "end" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(VDialog, {
                modelValue: unref(dialog),
                "onUpdate:modelValue": ($event) => isRef(dialog) ? dialog.value = $event : null,
                width: "1024"
              }, {
                activator: withCtx(({ props }, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(VBtn, mergeProps({
                      color: "#0F9D58",
                      class: "mr-3 elevation-0"
                    }, props, { style: { "border-radius": "7px" } }), {
                      default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`${ssrInterpolate(_ctx.$t("buy"))}`);
                        } else {
                          return [
                            createTextVNode(toDisplayString(_ctx.$t("buy")), 1)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(VBtn, mergeProps({
                        color: "#0F9D58",
                        class: "mr-3 elevation-0"
                      }, props, { style: { "border-radius": "7px" } }), {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.$t("buy")), 1)
                        ]),
                        _: 2
                      }, 1040)
                    ];
                  }
                }),
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(VStepper, {
                      modelValue: unref(e1),
                      "onUpdate:modelValue": ($event) => isRef(e1) ? e1.value = $event : null,
                      "hide-actions": ""
                    }, {
                      default: withCtx(({ props }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(VStepperHeader, null, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(VDivider, null, null, _parent5, _scopeId4));
                                _push5(ssrRenderComponent(VStepperItem, {
                                  complete: unref(e1) > 1,
                                  title: _ctx.$t("login"),
                                  value: 1,
                                  editable: "",
                                  disabled: !!unref(token),
                                  color: "#0F9D58"
                                }, null, _parent5, _scopeId4));
                                _push5(ssrRenderComponent(VDivider, null, null, _parent5, _scopeId4));
                                _push5(ssrRenderComponent(VDivider, null, null, _parent5, _scopeId4));
                                _push5(ssrRenderComponent(VStepperItem, {
                                  complete: unref(e1) > 2,
                                  title: _ctx.$t("order_item"),
                                  value: 2,
                                  editable: "",
                                  disabled: !unref(token),
                                  color: "#0F9D58"
                                }, null, _parent5, _scopeId4));
                                _push5(ssrRenderComponent(VDivider, null, null, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(VDivider),
                                  createVNode(VStepperItem, {
                                    complete: unref(e1) > 1,
                                    title: _ctx.$t("login"),
                                    value: 1,
                                    editable: "",
                                    disabled: !!unref(token),
                                    color: "#0F9D58"
                                  }, null, 8, ["complete", "title", "disabled"]),
                                  createVNode(VDivider),
                                  createVNode(VDivider),
                                  createVNode(VStepperItem, {
                                    complete: unref(e1) > 2,
                                    title: _ctx.$t("order_item"),
                                    value: 2,
                                    editable: "",
                                    disabled: !unref(token),
                                    color: "#0F9D58"
                                  }, null, 8, ["complete", "title", "disabled"]),
                                  createVNode(VDivider)
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(VStepperWindow, null, {
                            default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(VStepperWindowItem, {
                                  value: !unref(token) ? 1 : null
                                }, {
                                  default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(`<div class="grey lighten-4 py-12" data-v-4d6f8a3a${_scopeId5}>`);
                                      _push6(ssrRenderComponent(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                        default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(ssrRenderComponent(VCol, {
                                              cols: "12",
                                              lg: "6",
                                              md: "8",
                                              sm: "12"
                                            }, {
                                              default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(ssrRenderComponent(VCard, {
                                                    flat: "",
                                                    outlined: "",
                                                    width: "auto",
                                                    class: "mx-auto"
                                                  }, {
                                                    default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                      if (_push9) {
                                                        _push9(ssrRenderComponent(VTabs, {
                                                          modelValue: unref(tab),
                                                          "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                          "active-class": "white",
                                                          height: "40",
                                                          "fixed-tabs": "",
                                                          "hide-slider": ""
                                                        }, {
                                                          default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                            if (_push10) {
                                                              _push10(ssrRenderComponent(VBtn, {
                                                                color: "#0F9D58",
                                                                "min-width": "140px",
                                                                class: "button-menu",
                                                                onClick: ($event) => handleTabClick(0),
                                                                flat: ""
                                                              }, {
                                                                default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                  if (_push11) {
                                                                    _push11(`${ssrInterpolate(_ctx.$t("login"))}`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 2
                                                              }, _parent10, _scopeId9));
                                                              _push10(ssrRenderComponent(VBtn, {
                                                                color: "#0F9D58",
                                                                class: "button-menu",
                                                                onClick: ($event) => handleTabClick(1),
                                                                flat: ""
                                                              }, {
                                                                default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                  if (_push11) {
                                                                    _push11(`${ssrInterpolate(_ctx.$t("reg"))}`);
                                                                  } else {
                                                                    return [
                                                                      createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 2
                                                              }, _parent10, _scopeId9));
                                                            } else {
                                                              return [
                                                                createVNode(VBtn, {
                                                                  color: "#0F9D58",
                                                                  "min-width": "140px",
                                                                  class: "button-menu",
                                                                  onClick: ($event) => handleTabClick(0),
                                                                  flat: ""
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["onClick"]),
                                                                createVNode(VBtn, {
                                                                  color: "#0F9D58",
                                                                  class: "button-menu",
                                                                  onClick: ($event) => handleTabClick(1),
                                                                  flat: ""
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["onClick"])
                                                              ];
                                                            }
                                                          }),
                                                          _: 2
                                                        }, _parent9, _scopeId8));
                                                        _push9(ssrRenderComponent(VWindow, {
                                                          modelValue: unref(tab),
                                                          "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                                        }, {
                                                          default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                            if (_push10) {
                                                              _push10(ssrRenderComponent(VWindowItem, { value: 0 }, {
                                                                default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                  if (_push11) {
                                                                    _push11(`<h1 class="mt-4" data-v-4d6f8a3a${_scopeId10}>${ssrInterpolate(_ctx.$t("login"))}</h1>`);
                                                                    _push11(ssrRenderComponent(VCardText, { class: "p-0 my-7" }, {
                                                                      default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                        if (_push12) {
                                                                          _push12(ssrRenderComponent(VForm, {
                                                                            modelValue: unref(valid),
                                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                            onSubmit: onLogin,
                                                                            ref: "form",
                                                                            "lazy-validation": ""
                                                                          }, {
                                                                            default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                              if (_push13) {
                                                                                _push13(ssrRenderComponent(VTextField, {
                                                                                  modelValue: unref(user).phonenumber,
                                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                  "prepend-inner-icon": "mdi-phone",
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("phone"),
                                                                                  variant: "outlined",
                                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                                  type: "tel"
                                                                                }, null, _parent13, _scopeId12));
                                                                                _push13(ssrRenderComponent(VTextField, {
                                                                                  modelValue: unref(user).password,
                                                                                  "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                  type: unref(visible) ? "text" : "password",
                                                                                  rules: [rules.passwordRequired, rules.min],
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("password"),
                                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                                  variant: "outlined",
                                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                }, null, _parent13, _scopeId12));
                                                                                _push13(`<div class="text-center" data-v-4d6f8a3a${_scopeId12}>`);
                                                                                _push13(ssrRenderComponent(VBtn, {
                                                                                  type: "submit",
                                                                                  color: "#0F9D58",
                                                                                  class: "mb-4 button-menu",
                                                                                  "min-width": "200px"
                                                                                }, {
                                                                                  default: withCtx((_12, _push14, _parent14, _scopeId13) => {
                                                                                    if (_push14) {
                                                                                      _push14(`${ssrInterpolate(_ctx.$t("login"))}`);
                                                                                    } else {
                                                                                      return [
                                                                                        createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                                      ];
                                                                                    }
                                                                                  }),
                                                                                  _: 2
                                                                                }, _parent13, _scopeId12));
                                                                                _push13(`</div><div class="text-body-2 font-weight-regular" style="${ssrRenderStyle({ "cursor": "pointer" })}" data-v-4d6f8a3a${_scopeId12}>${ssrInterpolate(_ctx.$t("reset_pass"))}</div><div class="text-red" data-v-4d6f8a3a${_scopeId12}>${ssrInterpolate(unref(errorMessage))}</div>`);
                                                                              } else {
                                                                                return [
                                                                                  createVNode(VTextField, {
                                                                                    modelValue: unref(user).phonenumber,
                                                                                    "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                    "prepend-inner-icon": "mdi-phone",
                                                                                    density: "compact",
                                                                                    placeholder: _ctx.$t("phone"),
                                                                                    variant: "outlined",
                                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                                    type: "tel"
                                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                  createVNode(VTextField, {
                                                                                    modelValue: unref(user).password,
                                                                                    "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                    type: unref(visible) ? "text" : "password",
                                                                                    rules: [rules.passwordRequired, rules.min],
                                                                                    density: "compact",
                                                                                    placeholder: _ctx.$t("password"),
                                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                                    variant: "outlined",
                                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                                  createVNode("div", { class: "text-center" }, [
                                                                                    createVNode(VBtn, {
                                                                                      type: "submit",
                                                                                      color: "#0F9D58",
                                                                                      class: "mb-4 button-menu",
                                                                                      "min-width": "200px"
                                                                                    }, {
                                                                                      default: withCtx(() => [
                                                                                        createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                                      ]),
                                                                                      _: 1
                                                                                    })
                                                                                  ]),
                                                                                  createVNode("div", {
                                                                                    onClick: ($event) => handleTabClick(2),
                                                                                    class: "text-body-2 font-weight-regular",
                                                                                    style: { "cursor": "pointer" }
                                                                                  }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                                ];
                                                                              }
                                                                            }),
                                                                            _: 2
                                                                          }, _parent12, _scopeId11));
                                                                        } else {
                                                                          return [
                                                                            createVNode(VForm, {
                                                                              modelValue: unref(valid),
                                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                              onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                              ref: "form",
                                                                              "lazy-validation": ""
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(user).phonenumber,
                                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                  "prepend-inner-icon": "mdi-phone",
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("phone"),
                                                                                  variant: "outlined",
                                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                                  type: "tel"
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(user).password,
                                                                                  "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                  type: unref(visible) ? "text" : "password",
                                                                                  rules: [rules.passwordRequired, rules.min],
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("password"),
                                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                                  variant: "outlined",
                                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                                createVNode("div", { class: "text-center" }, [
                                                                                  createVNode(VBtn, {
                                                                                    type: "submit",
                                                                                    color: "#0F9D58",
                                                                                    class: "mb-4 button-menu",
                                                                                    "min-width": "200px"
                                                                                  }, {
                                                                                    default: withCtx(() => [
                                                                                      createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                                    ]),
                                                                                    _: 1
                                                                                  })
                                                                                ]),
                                                                                createVNode("div", {
                                                                                  onClick: ($event) => handleTabClick(2),
                                                                                  class: "text-body-2 font-weight-regular",
                                                                                  style: { "cursor": "pointer" }
                                                                                }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                              ]),
                                                                              _: 1
                                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 2
                                                                    }, _parent11, _scopeId10));
                                                                  } else {
                                                                    return [
                                                                      createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                                      createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VForm, {
                                                                            modelValue: unref(valid),
                                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                            onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                            ref: "form",
                                                                            "lazy-validation": ""
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(user).phonenumber,
                                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                "prepend-inner-icon": "mdi-phone",
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("phone"),
                                                                                variant: "outlined",
                                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                                type: "tel"
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(user).password,
                                                                                "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                              createVNode("div", { class: "text-center" }, [
                                                                                createVNode(VBtn, {
                                                                                  type: "submit",
                                                                                  color: "#0F9D58",
                                                                                  class: "mb-4 button-menu",
                                                                                  "min-width": "200px"
                                                                                }, {
                                                                                  default: withCtx(() => [
                                                                                    createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                                  ]),
                                                                                  _: 1
                                                                                })
                                                                              ]),
                                                                              createVNode("div", {
                                                                                onClick: ($event) => handleTabClick(2),
                                                                                class: "text-body-2 font-weight-regular",
                                                                                style: { "cursor": "pointer" }
                                                                              }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                            ]),
                                                                            _: 1
                                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 2
                                                              }, _parent10, _scopeId9));
                                                              _push10(ssrRenderComponent(VWindowItem, { value: 1 }, {
                                                                default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                  if (_push11) {
                                                                    _push11(`<h1 class="mt-4" data-v-4d6f8a3a${_scopeId10}>${ssrInterpolate(_ctx.$t("reg"))}</h1>`);
                                                                    _push11(ssrRenderComponent(VCardText, { class: "p-0 my-7" }, {
                                                                      default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                        if (_push12) {
                                                                          _push12(ssrRenderComponent(VForm, {
                                                                            modelValue: unref(valid),
                                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                            onSubmit: onRegistrations,
                                                                            ref: "form",
                                                                            "lazy-validation": ""
                                                                          }, {
                                                                            default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                              if (_push13) {
                                                                                _push13(ssrRenderComponent(VCol, { cols: "auto" }, {
                                                                                  default: withCtx((_12, _push14, _parent14, _scopeId13) => {
                                                                                    if (_push14) {
                                                                                      _push14(ssrRenderComponent(VTextField, {
                                                                                        modelValue: unref(createUser).phone,
                                                                                        "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                        "prepend-inner-icon": "mdi-phone",
                                                                                        density: "compact",
                                                                                        placeholder: _ctx.$t("phone"),
                                                                                        variant: "outlined",
                                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                                        type: "tel"
                                                                                      }, null, _parent14, _scopeId13));
                                                                                      _push14(ssrRenderComponent(VTextField, {
                                                                                        modelValue: unref(createUser).password1,
                                                                                        "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                        type: unref(visible) ? "text" : "password",
                                                                                        rules: [rules.passwordRequired, rules.min],
                                                                                        density: "compact",
                                                                                        placeholder: _ctx.$t("password"),
                                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                                        variant: "outlined",
                                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                      }, null, _parent14, _scopeId13));
                                                                                      _push14(ssrRenderComponent(VTextField, {
                                                                                        modelValue: unref(createUser).password2,
                                                                                        "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                        type: unref(visible) ? "text" : "password",
                                                                                        rules: [rules.passwordRequired, rules.min],
                                                                                        density: "compact",
                                                                                        placeholder: _ctx.$t("password"),
                                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                                        variant: "outlined",
                                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                      }, null, _parent14, _scopeId13));
                                                                                    } else {
                                                                                      return [
                                                                                        createVNode(VTextField, {
                                                                                          modelValue: unref(createUser).phone,
                                                                                          "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                          "prepend-inner-icon": "mdi-phone",
                                                                                          density: "compact",
                                                                                          placeholder: _ctx.$t("phone"),
                                                                                          variant: "outlined",
                                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                                          type: "tel"
                                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                        createVNode(VTextField, {
                                                                                          modelValue: unref(createUser).password1,
                                                                                          "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                          type: unref(visible) ? "text" : "password",
                                                                                          rules: [rules.passwordRequired, rules.min],
                                                                                          density: "compact",
                                                                                          placeholder: _ctx.$t("password"),
                                                                                          "prepend-inner-icon": "mdi-lock-outline",
                                                                                          variant: "outlined",
                                                                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                                        createVNode(VTextField, {
                                                                                          modelValue: unref(createUser).password2,
                                                                                          "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                          type: unref(visible) ? "text" : "password",
                                                                                          rules: [rules.passwordRequired, rules.min],
                                                                                          density: "compact",
                                                                                          placeholder: _ctx.$t("password"),
                                                                                          "prepend-inner-icon": "mdi-lock-outline",
                                                                                          variant: "outlined",
                                                                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                                      ];
                                                                                    }
                                                                                  }),
                                                                                  _: 2
                                                                                }, _parent13, _scopeId12));
                                                                                _push13(`<div class="text-center" data-v-4d6f8a3a${_scopeId12}>`);
                                                                                _push13(ssrRenderComponent(VBtn, {
                                                                                  type: "submit",
                                                                                  color: "#0F9D58",
                                                                                  class: "mb-4 button-menu",
                                                                                  "min-width": "300px"
                                                                                }, {
                                                                                  default: withCtx((_12, _push14, _parent14, _scopeId13) => {
                                                                                    if (_push14) {
                                                                                      _push14(`${ssrInterpolate(_ctx.$t("reg"))}`);
                                                                                    } else {
                                                                                      return [
                                                                                        createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                                      ];
                                                                                    }
                                                                                  }),
                                                                                  _: 2
                                                                                }, _parent13, _scopeId12));
                                                                                _push13(`<div class="text-red" data-v-4d6f8a3a${_scopeId12}>${ssrInterpolate(unref(errorStatus))}</div></div>`);
                                                                              } else {
                                                                                return [
                                                                                  createVNode(VCol, { cols: "auto" }, {
                                                                                    default: withCtx(() => [
                                                                                      createVNode(VTextField, {
                                                                                        modelValue: unref(createUser).phone,
                                                                                        "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                        "prepend-inner-icon": "mdi-phone",
                                                                                        density: "compact",
                                                                                        placeholder: _ctx.$t("phone"),
                                                                                        variant: "outlined",
                                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                                        type: "tel"
                                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                      createVNode(VTextField, {
                                                                                        modelValue: unref(createUser).password1,
                                                                                        "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                        type: unref(visible) ? "text" : "password",
                                                                                        rules: [rules.passwordRequired, rules.min],
                                                                                        density: "compact",
                                                                                        placeholder: _ctx.$t("password"),
                                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                                        variant: "outlined",
                                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                                      createVNode(VTextField, {
                                                                                        modelValue: unref(createUser).password2,
                                                                                        "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                        type: unref(visible) ? "text" : "password",
                                                                                        rules: [rules.passwordRequired, rules.min],
                                                                                        density: "compact",
                                                                                        placeholder: _ctx.$t("password"),
                                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                                        variant: "outlined",
                                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                                    ]),
                                                                                    _: 1
                                                                                  }),
                                                                                  createVNode("div", { class: "text-center" }, [
                                                                                    createVNode(VBtn, {
                                                                                      type: "submit",
                                                                                      color: "#0F9D58",
                                                                                      class: "mb-4 button-menu",
                                                                                      "min-width": "300px"
                                                                                    }, {
                                                                                      default: withCtx(() => [
                                                                                        createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                                      ]),
                                                                                      _: 1
                                                                                    }),
                                                                                    createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                                  ])
                                                                                ];
                                                                              }
                                                                            }),
                                                                            _: 2
                                                                          }, _parent12, _scopeId11));
                                                                        } else {
                                                                          return [
                                                                            createVNode(VForm, {
                                                                              modelValue: unref(valid),
                                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                              onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                              ref: "form",
                                                                              "lazy-validation": ""
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createVNode(VCol, { cols: "auto" }, {
                                                                                  default: withCtx(() => [
                                                                                    createVNode(VTextField, {
                                                                                      modelValue: unref(createUser).phone,
                                                                                      "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                      "prepend-inner-icon": "mdi-phone",
                                                                                      density: "compact",
                                                                                      placeholder: _ctx.$t("phone"),
                                                                                      variant: "outlined",
                                                                                      rules: [rules.phoneRequired, rules.phonenumber],
                                                                                      type: "tel"
                                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                    createVNode(VTextField, {
                                                                                      modelValue: unref(createUser).password1,
                                                                                      "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                      "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                      type: unref(visible) ? "text" : "password",
                                                                                      rules: [rules.passwordRequired, rules.min],
                                                                                      density: "compact",
                                                                                      placeholder: _ctx.$t("password"),
                                                                                      "prepend-inner-icon": "mdi-lock-outline",
                                                                                      variant: "outlined",
                                                                                      "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                                    createVNode(VTextField, {
                                                                                      modelValue: unref(createUser).password2,
                                                                                      "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                      "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                      type: unref(visible) ? "text" : "password",
                                                                                      rules: [rules.passwordRequired, rules.min],
                                                                                      density: "compact",
                                                                                      placeholder: _ctx.$t("password"),
                                                                                      "prepend-inner-icon": "mdi-lock-outline",
                                                                                      variant: "outlined",
                                                                                      "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                                  ]),
                                                                                  _: 1
                                                                                }),
                                                                                createVNode("div", { class: "text-center" }, [
                                                                                  createVNode(VBtn, {
                                                                                    type: "submit",
                                                                                    color: "#0F9D58",
                                                                                    class: "mb-4 button-menu",
                                                                                    "min-width": "300px"
                                                                                  }, {
                                                                                    default: withCtx(() => [
                                                                                      createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                                    ]),
                                                                                    _: 1
                                                                                  }),
                                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                                ])
                                                                              ]),
                                                                              _: 1
                                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 2
                                                                    }, _parent11, _scopeId10));
                                                                  } else {
                                                                    return [
                                                                      createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                                      createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VForm, {
                                                                            modelValue: unref(valid),
                                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                            onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                            ref: "form",
                                                                            "lazy-validation": ""
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createVNode(VCol, { cols: "auto" }, {
                                                                                default: withCtx(() => [
                                                                                  createVNode(VTextField, {
                                                                                    modelValue: unref(createUser).phone,
                                                                                    "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                    "prepend-inner-icon": "mdi-phone",
                                                                                    density: "compact",
                                                                                    placeholder: _ctx.$t("phone"),
                                                                                    variant: "outlined",
                                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                                    type: "tel"
                                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                  createVNode(VTextField, {
                                                                                    modelValue: unref(createUser).password1,
                                                                                    "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                    type: unref(visible) ? "text" : "password",
                                                                                    rules: [rules.passwordRequired, rules.min],
                                                                                    density: "compact",
                                                                                    placeholder: _ctx.$t("password"),
                                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                                    variant: "outlined",
                                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                                  createVNode(VTextField, {
                                                                                    modelValue: unref(createUser).password2,
                                                                                    "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                    type: unref(visible) ? "text" : "password",
                                                                                    rules: [rules.passwordRequired, rules.min],
                                                                                    density: "compact",
                                                                                    placeholder: _ctx.$t("password"),
                                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                                    variant: "outlined",
                                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                                ]),
                                                                                _: 1
                                                                              }),
                                                                              createVNode("div", { class: "text-center" }, [
                                                                                createVNode(VBtn, {
                                                                                  type: "submit",
                                                                                  color: "#0F9D58",
                                                                                  class: "mb-4 button-menu",
                                                                                  "min-width": "300px"
                                                                                }, {
                                                                                  default: withCtx(() => [
                                                                                    createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                                  ]),
                                                                                  _: 1
                                                                                }),
                                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                              ])
                                                                            ]),
                                                                            _: 1
                                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 2
                                                              }, _parent10, _scopeId9));
                                                              _push10(ssrRenderComponent(VWindowItem, { value: 2 }, {
                                                                default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                  if (_push11) {
                                                                    _push11(`<h1 class="mt-4" data-v-4d6f8a3a${_scopeId10}>${ssrInterpolate(_ctx.$t("restore"))}</h1>`);
                                                                    _push11(ssrRenderComponent(VCardText, { class: "p-0 my-7" }, {
                                                                      default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                        if (_push12) {
                                                                          _push12(ssrRenderComponent(VForm, {
                                                                            modelValue: unref(valid),
                                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                            onSubmit: onLogin,
                                                                            ref: "form",
                                                                            "lazy-validation": ""
                                                                          }, {
                                                                            default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                              if (_push13) {
                                                                                _push13(ssrRenderComponent(VTextField, {
                                                                                  modelValue: unref(user).phonenumber,
                                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                  "prepend-inner-icon": "mdi-phone",
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("phone"),
                                                                                  variant: "outlined",
                                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                                  type: "tel"
                                                                                }, null, _parent13, _scopeId12));
                                                                                _push13(`<div class="text-center" data-v-4d6f8a3a${_scopeId12}>`);
                                                                                _push13(ssrRenderComponent(VBtn, {
                                                                                  type: "submit",
                                                                                  color: "#0F9D58",
                                                                                  class: "mb-4 button-menu",
                                                                                  "min-width": "200px"
                                                                                }, {
                                                                                  default: withCtx((_12, _push14, _parent14, _scopeId13) => {
                                                                                    if (_push14) {
                                                                                      _push14(`${ssrInterpolate(_ctx.$t("send"))}`);
                                                                                    } else {
                                                                                      return [
                                                                                        createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                                      ];
                                                                                    }
                                                                                  }),
                                                                                  _: 2
                                                                                }, _parent13, _scopeId12));
                                                                                _push13(`</div><div class="text-red" data-v-4d6f8a3a${_scopeId12}>${ssrInterpolate(unref(errorMessage))}</div>`);
                                                                              } else {
                                                                                return [
                                                                                  createVNode(VTextField, {
                                                                                    modelValue: unref(user).phonenumber,
                                                                                    "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                    "prepend-inner-icon": "mdi-phone",
                                                                                    density: "compact",
                                                                                    placeholder: _ctx.$t("phone"),
                                                                                    variant: "outlined",
                                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                                    type: "tel"
                                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                  createVNode("div", { class: "text-center" }, [
                                                                                    createVNode(VBtn, {
                                                                                      type: "submit",
                                                                                      color: "#0F9D58",
                                                                                      class: "mb-4 button-menu",
                                                                                      "min-width": "200px"
                                                                                    }, {
                                                                                      default: withCtx(() => [
                                                                                        createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                                      ]),
                                                                                      _: 1
                                                                                    })
                                                                                  ]),
                                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                                ];
                                                                              }
                                                                            }),
                                                                            _: 2
                                                                          }, _parent12, _scopeId11));
                                                                        } else {
                                                                          return [
                                                                            createVNode(VForm, {
                                                                              modelValue: unref(valid),
                                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                              onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                              ref: "form",
                                                                              "lazy-validation": ""
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(user).phonenumber,
                                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                  "prepend-inner-icon": "mdi-phone",
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("phone"),
                                                                                  variant: "outlined",
                                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                                  type: "tel"
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                createVNode("div", { class: "text-center" }, [
                                                                                  createVNode(VBtn, {
                                                                                    type: "submit",
                                                                                    color: "#0F9D58",
                                                                                    class: "mb-4 button-menu",
                                                                                    "min-width": "200px"
                                                                                  }, {
                                                                                    default: withCtx(() => [
                                                                                      createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                                    ]),
                                                                                    _: 1
                                                                                  })
                                                                                ]),
                                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                              ]),
                                                                              _: 1
                                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 2
                                                                    }, _parent11, _scopeId10));
                                                                  } else {
                                                                    return [
                                                                      createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                                      createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VForm, {
                                                                            modelValue: unref(valid),
                                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                            onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                            ref: "form",
                                                                            "lazy-validation": ""
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(user).phonenumber,
                                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                "prepend-inner-icon": "mdi-phone",
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("phone"),
                                                                                variant: "outlined",
                                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                                type: "tel"
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                              createVNode("div", { class: "text-center" }, [
                                                                                createVNode(VBtn, {
                                                                                  type: "submit",
                                                                                  color: "#0F9D58",
                                                                                  class: "mb-4 button-menu",
                                                                                  "min-width": "200px"
                                                                                }, {
                                                                                  default: withCtx(() => [
                                                                                    createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                                  ]),
                                                                                  _: 1
                                                                                })
                                                                              ]),
                                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                            ]),
                                                                            _: 1
                                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 2
                                                              }, _parent10, _scopeId9));
                                                            } else {
                                                              return [
                                                                createVNode(VWindowItem, { value: 0 }, {
                                                                  default: withCtx(() => [
                                                                    createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                                    createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VForm, {
                                                                          modelValue: unref(valid),
                                                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                          onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                          ref: "form",
                                                                          "lazy-validation": ""
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(user).phonenumber,
                                                                              "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                              "prepend-inner-icon": "mdi-phone",
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("phone"),
                                                                              variant: "outlined",
                                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                                              type: "tel"
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(user).password,
                                                                              "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                              type: unref(visible) ? "text" : "password",
                                                                              rules: [rules.passwordRequired, rules.min],
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("password"),
                                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                                              variant: "outlined",
                                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                            createVNode("div", { class: "text-center" }, [
                                                                              createVNode(VBtn, {
                                                                                type: "submit",
                                                                                color: "#0F9D58",
                                                                                class: "mb-4 button-menu",
                                                                                "min-width": "200px"
                                                                              }, {
                                                                                default: withCtx(() => [
                                                                                  createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                                ]),
                                                                                _: 1
                                                                              })
                                                                            ]),
                                                                            createVNode("div", {
                                                                              onClick: ($event) => handleTabClick(2),
                                                                              class: "text-body-2 font-weight-regular",
                                                                              style: { "cursor": "pointer" }
                                                                            }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                            createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                          ]),
                                                                          _: 1
                                                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(VWindowItem, { value: 1 }, {
                                                                  default: withCtx(() => [
                                                                    createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                                    createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VForm, {
                                                                          modelValue: unref(valid),
                                                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                          onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                          ref: "form",
                                                                          "lazy-validation": ""
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createVNode(VCol, { cols: "auto" }, {
                                                                              default: withCtx(() => [
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(createUser).phone,
                                                                                  "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                  "prepend-inner-icon": "mdi-phone",
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("phone"),
                                                                                  variant: "outlined",
                                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                                  type: "tel"
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(createUser).password1,
                                                                                  "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                  type: unref(visible) ? "text" : "password",
                                                                                  rules: [rules.passwordRequired, rules.min],
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("password"),
                                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                                  variant: "outlined",
                                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(createUser).password2,
                                                                                  "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                  type: unref(visible) ? "text" : "password",
                                                                                  rules: [rules.passwordRequired, rules.min],
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("password"),
                                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                                  variant: "outlined",
                                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                              ]),
                                                                              _: 1
                                                                            }),
                                                                            createVNode("div", { class: "text-center" }, [
                                                                              createVNode(VBtn, {
                                                                                type: "submit",
                                                                                color: "#0F9D58",
                                                                                class: "mb-4 button-menu",
                                                                                "min-width": "300px"
                                                                              }, {
                                                                                default: withCtx(() => [
                                                                                  createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                                ]),
                                                                                _: 1
                                                                              }),
                                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                            ])
                                                                          ]),
                                                                          _: 1
                                                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(VWindowItem, { value: 2 }, {
                                                                  default: withCtx(() => [
                                                                    createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                                    createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VForm, {
                                                                          modelValue: unref(valid),
                                                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                          onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                          ref: "form",
                                                                          "lazy-validation": ""
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(user).phonenumber,
                                                                              "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                              "prepend-inner-icon": "mdi-phone",
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("phone"),
                                                                              variant: "outlined",
                                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                                              type: "tel"
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                            createVNode("div", { class: "text-center" }, [
                                                                              createVNode(VBtn, {
                                                                                type: "submit",
                                                                                color: "#0F9D58",
                                                                                class: "mb-4 button-menu",
                                                                                "min-width": "200px"
                                                                              }, {
                                                                                default: withCtx(() => [
                                                                                  createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                                ]),
                                                                                _: 1
                                                                              })
                                                                            ]),
                                                                            createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                          ]),
                                                                          _: 1
                                                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 2
                                                        }, _parent9, _scopeId8));
                                                      } else {
                                                        return [
                                                          createVNode(VTabs, {
                                                            modelValue: unref(tab),
                                                            "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                            "active-class": "white",
                                                            height: "40",
                                                            "fixed-tabs": "",
                                                            "hide-slider": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VBtn, {
                                                                color: "#0F9D58",
                                                                "min-width": "140px",
                                                                class: "button-menu",
                                                                onClick: ($event) => handleTabClick(0),
                                                                flat: ""
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                ]),
                                                                _: 1
                                                              }, 8, ["onClick"]),
                                                              createVNode(VBtn, {
                                                                color: "#0F9D58",
                                                                class: "button-menu",
                                                                onClick: ($event) => handleTabClick(1),
                                                                flat: ""
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                ]),
                                                                _: 1
                                                              }, 8, ["onClick"])
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                          createVNode(VWindow, {
                                                            modelValue: unref(tab),
                                                            "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VWindowItem, { value: 0 }, {
                                                                default: withCtx(() => [
                                                                  createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                                  createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VForm, {
                                                                        modelValue: unref(valid),
                                                                        "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                        onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                        ref: "form",
                                                                        "lazy-validation": ""
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(user).phonenumber,
                                                                            "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                            "prepend-inner-icon": "mdi-phone",
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("phone"),
                                                                            variant: "outlined",
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            type: "tel"
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(user).password,
                                                                            "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                            type: unref(visible) ? "text" : "password",
                                                                            rules: [rules.passwordRequired, rules.min],
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("password"),
                                                                            "prepend-inner-icon": "mdi-lock-outline",
                                                                            variant: "outlined",
                                                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                          createVNode("div", { class: "text-center" }, [
                                                                            createVNode(VBtn, {
                                                                              type: "submit",
                                                                              color: "#0F9D58",
                                                                              class: "mb-4 button-menu",
                                                                              "min-width": "200px"
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                              ]),
                                                                              _: 1
                                                                            })
                                                                          ]),
                                                                          createVNode("div", {
                                                                            onClick: ($event) => handleTabClick(2),
                                                                            class: "text-body-2 font-weight-regular",
                                                                            style: { "cursor": "pointer" }
                                                                          }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                        ]),
                                                                        _: 1
                                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(VWindowItem, { value: 1 }, {
                                                                default: withCtx(() => [
                                                                  createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                                  createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VForm, {
                                                                        modelValue: unref(valid),
                                                                        "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                        onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                        ref: "form",
                                                                        "lazy-validation": ""
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VCol, { cols: "auto" }, {
                                                                            default: withCtx(() => [
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(createUser).phone,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                "prepend-inner-icon": "mdi-phone",
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("phone"),
                                                                                variant: "outlined",
                                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                                type: "tel"
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(createUser).password1,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(createUser).password2,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                            ]),
                                                                            _: 1
                                                                          }),
                                                                          createVNode("div", { class: "text-center" }, [
                                                                            createVNode(VBtn, {
                                                                              type: "submit",
                                                                              color: "#0F9D58",
                                                                              class: "mb-4 button-menu",
                                                                              "min-width": "300px"
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                              ]),
                                                                              _: 1
                                                                            }),
                                                                            createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                          ])
                                                                        ]),
                                                                        _: 1
                                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(VWindowItem, { value: 2 }, {
                                                                default: withCtx(() => [
                                                                  createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                                  createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VForm, {
                                                                        modelValue: unref(valid),
                                                                        "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                        onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                        ref: "form",
                                                                        "lazy-validation": ""
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(user).phonenumber,
                                                                            "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                            "prepend-inner-icon": "mdi-phone",
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("phone"),
                                                                            variant: "outlined",
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            type: "tel"
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                          createVNode("div", { class: "text-center" }, [
                                                                            createVNode(VBtn, {
                                                                              type: "submit",
                                                                              color: "#0F9D58",
                                                                              class: "mb-4 button-menu",
                                                                              "min-width": "200px"
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                              ]),
                                                                              _: 1
                                                                            })
                                                                          ]),
                                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                        ]),
                                                                        _: 1
                                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 2
                                                  }, _parent8, _scopeId7));
                                                } else {
                                                  return [
                                                    createVNode(VCard, {
                                                      flat: "",
                                                      outlined: "",
                                                      width: "auto",
                                                      class: "mx-auto"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(VTabs, {
                                                          modelValue: unref(tab),
                                                          "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                          "active-class": "white",
                                                          height: "40",
                                                          "fixed-tabs": "",
                                                          "hide-slider": ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(VBtn, {
                                                              color: "#0F9D58",
                                                              "min-width": "140px",
                                                              class: "button-menu",
                                                              onClick: ($event) => handleTabClick(0),
                                                              flat: ""
                                                            }, {
                                                              default: withCtx(() => [
                                                                createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                              ]),
                                                              _: 1
                                                            }, 8, ["onClick"]),
                                                            createVNode(VBtn, {
                                                              color: "#0F9D58",
                                                              class: "button-menu",
                                                              onClick: ($event) => handleTabClick(1),
                                                              flat: ""
                                                            }, {
                                                              default: withCtx(() => [
                                                                createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                              ]),
                                                              _: 1
                                                            }, 8, ["onClick"])
                                                          ]),
                                                          _: 1
                                                        }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                        createVNode(VWindow, {
                                                          modelValue: unref(tab),
                                                          "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(VWindowItem, { value: 0 }, {
                                                              default: withCtx(() => [
                                                                createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                                createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VForm, {
                                                                      modelValue: unref(valid),
                                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                      onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                      ref: "form",
                                                                      "lazy-validation": ""
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(user).phonenumber,
                                                                          "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                          "prepend-inner-icon": "mdi-phone",
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("phone"),
                                                                          variant: "outlined",
                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                          type: "tel"
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(user).password,
                                                                          "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                          type: unref(visible) ? "text" : "password",
                                                                          rules: [rules.passwordRequired, rules.min],
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("password"),
                                                                          "prepend-inner-icon": "mdi-lock-outline",
                                                                          variant: "outlined",
                                                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                        createVNode("div", { class: "text-center" }, [
                                                                          createVNode(VBtn, {
                                                                            type: "submit",
                                                                            color: "#0F9D58",
                                                                            class: "mb-4 button-menu",
                                                                            "min-width": "200px"
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                            ]),
                                                                            _: 1
                                                                          })
                                                                        ]),
                                                                        createVNode("div", {
                                                                          onClick: ($event) => handleTabClick(2),
                                                                          class: "text-body-2 font-weight-regular",
                                                                          style: { "cursor": "pointer" }
                                                                        }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                      ]),
                                                                      _: 1
                                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(VWindowItem, { value: 1 }, {
                                                              default: withCtx(() => [
                                                                createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                                createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VForm, {
                                                                      modelValue: unref(valid),
                                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                      onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                      ref: "form",
                                                                      "lazy-validation": ""
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VCol, { cols: "auto" }, {
                                                                          default: withCtx(() => [
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(createUser).phone,
                                                                              "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                              "prepend-inner-icon": "mdi-phone",
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("phone"),
                                                                              variant: "outlined",
                                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                                              type: "tel"
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(createUser).password1,
                                                                              "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                              type: unref(visible) ? "text" : "password",
                                                                              rules: [rules.passwordRequired, rules.min],
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("password"),
                                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                                              variant: "outlined",
                                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(createUser).password2,
                                                                              "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                              type: unref(visible) ? "text" : "password",
                                                                              rules: [rules.passwordRequired, rules.min],
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("password"),
                                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                                              variant: "outlined",
                                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                          ]),
                                                                          _: 1
                                                                        }),
                                                                        createVNode("div", { class: "text-center" }, [
                                                                          createVNode(VBtn, {
                                                                            type: "submit",
                                                                            color: "#0F9D58",
                                                                            class: "mb-4 button-menu",
                                                                            "min-width": "300px"
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                            ]),
                                                                            _: 1
                                                                          }),
                                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                        ])
                                                                      ]),
                                                                      _: 1
                                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(VWindowItem, { value: 2 }, {
                                                              default: withCtx(() => [
                                                                createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                                createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VForm, {
                                                                      modelValue: unref(valid),
                                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                      onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                      ref: "form",
                                                                      "lazy-validation": ""
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(user).phonenumber,
                                                                          "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                          "prepend-inner-icon": "mdi-phone",
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("phone"),
                                                                          variant: "outlined",
                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                          type: "tel"
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                        createVNode("div", { class: "text-center" }, [
                                                                          createVNode(VBtn, {
                                                                            type: "submit",
                                                                            color: "#0F9D58",
                                                                            class: "mb-4 button-menu",
                                                                            "min-width": "200px"
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                            ]),
                                                                            _: 1
                                                                          })
                                                                        ]),
                                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                      ]),
                                                                      _: 1
                                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                          } else {
                                            return [
                                              createVNode(VCol, {
                                                cols: "12",
                                                lg: "6",
                                                md: "8",
                                                sm: "12"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VCard, {
                                                    flat: "",
                                                    outlined: "",
                                                    width: "auto",
                                                    class: "mx-auto"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(VTabs, {
                                                        modelValue: unref(tab),
                                                        "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                        "active-class": "white",
                                                        height: "40",
                                                        "fixed-tabs": "",
                                                        "hide-slider": ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(VBtn, {
                                                            color: "#0F9D58",
                                                            "min-width": "140px",
                                                            class: "button-menu",
                                                            onClick: ($event) => handleTabClick(0),
                                                            flat: ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["onClick"]),
                                                          createVNode(VBtn, {
                                                            color: "#0F9D58",
                                                            class: "button-menu",
                                                            onClick: ($event) => handleTabClick(1),
                                                            flat: ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["onClick"])
                                                        ]),
                                                        _: 1
                                                      }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                      createVNode(VWindow, {
                                                        modelValue: unref(tab),
                                                        "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(VWindowItem, { value: 0 }, {
                                                            default: withCtx(() => [
                                                              createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                              createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).phonenumber,
                                                                        "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                        "prepend-inner-icon": "mdi-phone",
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("phone"),
                                                                        variant: "outlined",
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        type: "tel"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).password,
                                                                        "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                        type: unref(visible) ? "text" : "password",
                                                                        rules: [rules.passwordRequired, rules.min],
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("password"),
                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                        variant: "outlined",
                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "200px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        })
                                                                      ]),
                                                                      createVNode("div", {
                                                                        onClick: ($event) => handleTabClick(2),
                                                                        class: "text-body-2 font-weight-regular",
                                                                        style: { "cursor": "pointer" }
                                                                      }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                      createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(VWindowItem, { value: 1 }, {
                                                            default: withCtx(() => [
                                                              createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                              createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VCol, { cols: "auto" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).phone,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                            "prepend-inner-icon": "mdi-phone",
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("phone"),
                                                                            variant: "outlined",
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            type: "tel"
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).password1,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                            type: unref(visible) ? "text" : "password",
                                                                            rules: [rules.passwordRequired, rules.min],
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("password"),
                                                                            "prepend-inner-icon": "mdi-lock-outline",
                                                                            variant: "outlined",
                                                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).password2,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                            type: unref(visible) ? "text" : "password",
                                                                            rules: [rules.passwordRequired, rules.min],
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("password"),
                                                                            "prepend-inner-icon": "mdi-lock-outline",
                                                                            variant: "outlined",
                                                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "300px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        }),
                                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                      ])
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(VWindowItem, { value: 2 }, {
                                                            default: withCtx(() => [
                                                              createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                              createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).phonenumber,
                                                                        "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                        "prepend-inner-icon": "mdi-phone",
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("phone"),
                                                                        variant: "outlined",
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        type: "tel"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "200px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        })
                                                                      ]),
                                                                      createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                      _push6(`</div>`);
                                    } else {
                                      return [
                                        createVNode("div", { class: "grey lighten-4 py-12" }, [
                                          createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                            default: withCtx(() => [
                                              createVNode(VCol, {
                                                cols: "12",
                                                lg: "6",
                                                md: "8",
                                                sm: "12"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VCard, {
                                                    flat: "",
                                                    outlined: "",
                                                    width: "auto",
                                                    class: "mx-auto"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(VTabs, {
                                                        modelValue: unref(tab),
                                                        "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                        "active-class": "white",
                                                        height: "40",
                                                        "fixed-tabs": "",
                                                        "hide-slider": ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(VBtn, {
                                                            color: "#0F9D58",
                                                            "min-width": "140px",
                                                            class: "button-menu",
                                                            onClick: ($event) => handleTabClick(0),
                                                            flat: ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["onClick"]),
                                                          createVNode(VBtn, {
                                                            color: "#0F9D58",
                                                            class: "button-menu",
                                                            onClick: ($event) => handleTabClick(1),
                                                            flat: ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["onClick"])
                                                        ]),
                                                        _: 1
                                                      }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                      createVNode(VWindow, {
                                                        modelValue: unref(tab),
                                                        "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(VWindowItem, { value: 0 }, {
                                                            default: withCtx(() => [
                                                              createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                              createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).phonenumber,
                                                                        "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                        "prepend-inner-icon": "mdi-phone",
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("phone"),
                                                                        variant: "outlined",
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        type: "tel"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).password,
                                                                        "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                        type: unref(visible) ? "text" : "password",
                                                                        rules: [rules.passwordRequired, rules.min],
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("password"),
                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                        variant: "outlined",
                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "200px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        })
                                                                      ]),
                                                                      createVNode("div", {
                                                                        onClick: ($event) => handleTabClick(2),
                                                                        class: "text-body-2 font-weight-regular",
                                                                        style: { "cursor": "pointer" }
                                                                      }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                      createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(VWindowItem, { value: 1 }, {
                                                            default: withCtx(() => [
                                                              createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                              createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VCol, { cols: "auto" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).phone,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                            "prepend-inner-icon": "mdi-phone",
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("phone"),
                                                                            variant: "outlined",
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            type: "tel"
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).password1,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                            type: unref(visible) ? "text" : "password",
                                                                            rules: [rules.passwordRequired, rules.min],
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("password"),
                                                                            "prepend-inner-icon": "mdi-lock-outline",
                                                                            variant: "outlined",
                                                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).password2,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                            type: unref(visible) ? "text" : "password",
                                                                            rules: [rules.passwordRequired, rules.min],
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("password"),
                                                                            "prepend-inner-icon": "mdi-lock-outline",
                                                                            variant: "outlined",
                                                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "300px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        }),
                                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                      ])
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(VWindowItem, { value: 2 }, {
                                                            default: withCtx(() => [
                                                              createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                              createVNode(VCardText, { class: "p-0 my-7" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).phonenumber,
                                                                        "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                        "prepend-inner-icon": "mdi-phone",
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("phone"),
                                                                        variant: "outlined",
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        type: "tel"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "200px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        })
                                                                      ]),
                                                                      createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                                _push5(ssrRenderComponent(VStepperWindowItem, {
                                  value: unref(token) ? 2 : null
                                }, {
                                  default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(ssrRenderComponent(VCard, { flat: "" }, {
                                        default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                          if (_push7) {
                                            _push7(`<h2 class="text-h5 text-center mt-5 mb-5" data-v-4d6f8a3a${_scopeId6}>${ssrInterpolate(_ctx.$t("order"))}</h2>`);
                                            _push7(ssrRenderComponent(VCardText, null, {
                                              default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(ssrRenderComponent(VContainer, null, {
                                                    default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                      if (_push9) {
                                                        _push9(ssrRenderComponent(VForm, {
                                                          modelValue: unref(valid),
                                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                          onSubmit: onMyorders
                                                        }, {
                                                          default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                            if (_push10) {
                                                              _push10(ssrRenderComponent(VRow, null, {
                                                                default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                  if (_push11) {
                                                                    _push11(ssrRenderComponent(VCol, { cols: "12" }, {
                                                                      default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                        if (_push12) {
                                                                          _push12(ssrRenderComponent(VTextField, {
                                                                            modelValue: unref(order).full_name,
                                                                            "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                            rules: [rules.fullName],
                                                                            label: _ctx.$t("f"),
                                                                            "hide-details": "",
                                                                            variant: "outlined",
                                                                            density: "compact",
                                                                            required: ""
                                                                          }, null, _parent12, _scopeId11));
                                                                        } else {
                                                                          return [
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(order).full_name,
                                                                              "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                              rules: [rules.fullName],
                                                                              label: _ctx.$t("f"),
                                                                              "hide-details": "",
                                                                              variant: "outlined",
                                                                              density: "compact",
                                                                              required: ""
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 2
                                                                    }, _parent11, _scopeId10));
                                                                    _push11(ssrRenderComponent(VCol, { cols: "12" }, {
                                                                      default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                        if (_push12) {
                                                                          _push12(ssrRenderComponent(VTextField, {
                                                                            modelValue: unref(order).phone,
                                                                            "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                            label: _ctx.$t("phone"),
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            "hide-details": "",
                                                                            variant: "outlined",
                                                                            density: "compact",
                                                                            required: ""
                                                                          }, null, _parent12, _scopeId11));
                                                                        } else {
                                                                          return [
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(order).phone,
                                                                              "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                              label: _ctx.$t("phone"),
                                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                                              "hide-details": "",
                                                                              variant: "outlined",
                                                                              density: "compact",
                                                                              required: ""
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 2
                                                                    }, _parent11, _scopeId10));
                                                                    _push11(ssrRenderComponent(VCol, { cols: "12" }, {
                                                                      default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                        if (_push12) {
                                                                          _push12(ssrRenderComponent(VTextField, {
                                                                            modelValue: unref(order).address,
                                                                            "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                            disabled: !unref(order).is_delivery,
                                                                            rules: unref(getAddressRules),
                                                                            label: _ctx.$t("addres"),
                                                                            "hide-details": "",
                                                                            variant: "outlined",
                                                                            density: "compact",
                                                                            required: ""
                                                                          }, null, _parent12, _scopeId11));
                                                                        } else {
                                                                          return [
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(order).address,
                                                                              "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                              disabled: !unref(order).is_delivery,
                                                                              rules: unref(getAddressRules),
                                                                              label: _ctx.$t("addres"),
                                                                              "hide-details": "",
                                                                              variant: "outlined",
                                                                              density: "compact",
                                                                              required: ""
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 2
                                                                    }, _parent11, _scopeId10));
                                                                    _push11(ssrRenderComponent(VCol, { cols: "12" }, {
                                                                      default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                        if (_push12) {
                                                                          _push12(ssrRenderComponent(VCheckbox, {
                                                                            color: "#0F9D58",
                                                                            modelValue: unref(order).is_delivery,
                                                                            "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                            label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                                          }, null, _parent12, _scopeId11));
                                                                        } else {
                                                                          return [
                                                                            createVNode(VCheckbox, {
                                                                              color: "#0F9D58",
                                                                              modelValue: unref(order).is_delivery,
                                                                              "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                              label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 2
                                                                    }, _parent11, _scopeId10));
                                                                    _push11(ssrRenderComponent(VCol, { class: "text-end" }, {
                                                                      default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                        if (_push12) {
                                                                          _push12(ssrRenderComponent(VBtn, {
                                                                            color: "#0F9D58",
                                                                            type: "submit"
                                                                          }, {
                                                                            default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                              if (_push13) {
                                                                                _push13(`${ssrInterpolate(_ctx.$t("send"))}`);
                                                                              } else {
                                                                                return [
                                                                                  createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                                ];
                                                                              }
                                                                            }),
                                                                            _: 2
                                                                          }, _parent12, _scopeId11));
                                                                        } else {
                                                                          return [
                                                                            createVNode(VBtn, {
                                                                              color: "#0F9D58",
                                                                              type: "submit"
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                              ]),
                                                                              _: 1
                                                                            })
                                                                          ];
                                                                        }
                                                                      }),
                                                                      _: 2
                                                                    }, _parent11, _scopeId10));
                                                                  } else {
                                                                    return [
                                                                      createVNode(VCol, { cols: "12" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(order).full_name,
                                                                            "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                            rules: [rules.fullName],
                                                                            label: _ctx.$t("f"),
                                                                            "hide-details": "",
                                                                            variant: "outlined",
                                                                            density: "compact",
                                                                            required: ""
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode(VCol, { cols: "12" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(order).phone,
                                                                            "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                            label: _ctx.$t("phone"),
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            "hide-details": "",
                                                                            variant: "outlined",
                                                                            density: "compact",
                                                                            required: ""
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode(VCol, { cols: "12" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(order).address,
                                                                            "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                            disabled: !unref(order).is_delivery,
                                                                            rules: unref(getAddressRules),
                                                                            label: _ctx.$t("addres"),
                                                                            "hide-details": "",
                                                                            variant: "outlined",
                                                                            density: "compact",
                                                                            required: ""
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode(VCol, { cols: "12" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VCheckbox, {
                                                                            color: "#0F9D58",
                                                                            modelValue: unref(order).is_delivery,
                                                                            "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                            label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode(VCol, { class: "text-end" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VBtn, {
                                                                            color: "#0F9D58",
                                                                            type: "submit"
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                            ]),
                                                                            _: 1
                                                                          })
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ];
                                                                  }
                                                                }),
                                                                _: 2
                                                              }, _parent10, _scopeId9));
                                                            } else {
                                                              return [
                                                                createVNode(VRow, null, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VCol, { cols: "12" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(order).full_name,
                                                                          "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                          rules: [rules.fullName],
                                                                          label: _ctx.$t("f"),
                                                                          "hide-details": "",
                                                                          variant: "outlined",
                                                                          density: "compact",
                                                                          required: ""
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode(VCol, { cols: "12" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(order).phone,
                                                                          "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                          label: _ctx.$t("phone"),
                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                          "hide-details": "",
                                                                          variant: "outlined",
                                                                          density: "compact",
                                                                          required: ""
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode(VCol, { cols: "12" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(order).address,
                                                                          "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                          disabled: !unref(order).is_delivery,
                                                                          rules: unref(getAddressRules),
                                                                          label: _ctx.$t("addres"),
                                                                          "hide-details": "",
                                                                          variant: "outlined",
                                                                          density: "compact",
                                                                          required: ""
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode(VCol, { cols: "12" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VCheckbox, {
                                                                          color: "#0F9D58",
                                                                          modelValue: unref(order).is_delivery,
                                                                          "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                          label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode(VCol, { class: "text-end" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VBtn, {
                                                                          color: "#0F9D58",
                                                                          type: "submit"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        })
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ];
                                                            }
                                                          }),
                                                          _: 2
                                                        }, _parent9, _scopeId8));
                                                      } else {
                                                        return [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(onMyorders, ["prevent"])
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VRow, null, {
                                                                default: withCtx(() => [
                                                                  createVNode(VCol, { cols: "12" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(order).full_name,
                                                                        "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                        rules: [rules.fullName],
                                                                        label: _ctx.$t("f"),
                                                                        "hide-details": "",
                                                                        variant: "outlined",
                                                                        density: "compact",
                                                                        required: ""
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode(VCol, { cols: "12" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(order).phone,
                                                                        "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                        label: _ctx.$t("phone"),
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        "hide-details": "",
                                                                        variant: "outlined",
                                                                        density: "compact",
                                                                        required: ""
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode(VCol, { cols: "12" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(order).address,
                                                                        "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                        disabled: !unref(order).is_delivery,
                                                                        rules: unref(getAddressRules),
                                                                        label: _ctx.$t("addres"),
                                                                        "hide-details": "",
                                                                        variant: "outlined",
                                                                        density: "compact",
                                                                        required: ""
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode(VCol, { cols: "12" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VCheckbox, {
                                                                        color: "#0F9D58",
                                                                        modelValue: unref(order).is_delivery,
                                                                        "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                        label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode(VCol, { class: "text-end" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VBtn, {
                                                                        color: "#0F9D58",
                                                                        type: "submit"
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ];
                                                      }
                                                    }),
                                                    _: 2
                                                  }, _parent8, _scopeId7));
                                                } else {
                                                  return [
                                                    createVNode(VContainer, null, {
                                                      default: withCtx(() => [
                                                        createVNode(VForm, {
                                                          modelValue: unref(valid),
                                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                          onSubmit: withModifiers(onMyorders, ["prevent"])
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(VRow, null, {
                                                              default: withCtx(() => [
                                                                createVNode(VCol, { cols: "12" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(order).full_name,
                                                                      "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                      rules: [rules.fullName],
                                                                      label: _ctx.$t("f"),
                                                                      "hide-details": "",
                                                                      variant: "outlined",
                                                                      density: "compact",
                                                                      required: ""
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(VCol, { cols: "12" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(order).phone,
                                                                      "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                      label: _ctx.$t("phone"),
                                                                      rules: [rules.phoneRequired, rules.phonenumber],
                                                                      "hide-details": "",
                                                                      variant: "outlined",
                                                                      density: "compact",
                                                                      required: ""
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(VCol, { cols: "12" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(order).address,
                                                                      "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                      disabled: !unref(order).is_delivery,
                                                                      rules: unref(getAddressRules),
                                                                      label: _ctx.$t("addres"),
                                                                      "hide-details": "",
                                                                      variant: "outlined",
                                                                      density: "compact",
                                                                      required: ""
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(VCol, { cols: "12" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VCheckbox, {
                                                                      color: "#0F9D58",
                                                                      modelValue: unref(order).is_delivery,
                                                                      "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                      label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode(VCol, { class: "text-end" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VBtn, {
                                                                      color: "#0F9D58",
                                                                      type: "submit"
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 2
                                            }, _parent7, _scopeId6));
                                          } else {
                                            return [
                                              createVNode("h2", { class: "text-h5 text-center mt-5 mb-5" }, toDisplayString(_ctx.$t("order")), 1),
                                              createVNode(VCardText, null, {
                                                default: withCtx(() => [
                                                  createVNode(VContainer, null, {
                                                    default: withCtx(() => [
                                                      createVNode(VForm, {
                                                        modelValue: unref(valid),
                                                        "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                        onSubmit: withModifiers(onMyorders, ["prevent"])
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(VRow, null, {
                                                            default: withCtx(() => [
                                                              createVNode(VCol, { cols: "12" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(order).full_name,
                                                                    "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                    rules: [rules.fullName],
                                                                    label: _ctx.$t("f"),
                                                                    "hide-details": "",
                                                                    variant: "outlined",
                                                                    density: "compact",
                                                                    required: ""
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(VCol, { cols: "12" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(order).phone,
                                                                    "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                    label: _ctx.$t("phone"),
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    "hide-details": "",
                                                                    variant: "outlined",
                                                                    density: "compact",
                                                                    required: ""
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(VCol, { cols: "12" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(order).address,
                                                                    "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                    disabled: !unref(order).is_delivery,
                                                                    rules: unref(getAddressRules),
                                                                    label: _ctx.$t("addres"),
                                                                    "hide-details": "",
                                                                    variant: "outlined",
                                                                    density: "compact",
                                                                    required: ""
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(VCol, { cols: "12" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VCheckbox, {
                                                                    color: "#0F9D58",
                                                                    modelValue: unref(order).is_delivery,
                                                                    "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                    label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode(VCol, { class: "text-end" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VBtn, {
                                                                    color: "#0F9D58",
                                                                    type: "submit"
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ];
                                          }
                                        }),
                                        _: 2
                                      }, _parent6, _scopeId5));
                                    } else {
                                      return [
                                        createVNode(VCard, { flat: "" }, {
                                          default: withCtx(() => [
                                            createVNode("h2", { class: "text-h5 text-center mt-5 mb-5" }, toDisplayString(_ctx.$t("order")), 1),
                                            createVNode(VCardText, null, {
                                              default: withCtx(() => [
                                                createVNode(VContainer, null, {
                                                  default: withCtx(() => [
                                                    createVNode(VForm, {
                                                      modelValue: unref(valid),
                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                      onSubmit: withModifiers(onMyorders, ["prevent"])
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(VRow, null, {
                                                          default: withCtx(() => [
                                                            createVNode(VCol, { cols: "12" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(order).full_name,
                                                                  "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                  rules: [rules.fullName],
                                                                  label: _ctx.$t("f"),
                                                                  "hide-details": "",
                                                                  variant: "outlined",
                                                                  density: "compact",
                                                                  required: ""
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(VCol, { cols: "12" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(order).phone,
                                                                  "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                  label: _ctx.$t("phone"),
                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                  "hide-details": "",
                                                                  variant: "outlined",
                                                                  density: "compact",
                                                                  required: ""
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(VCol, { cols: "12" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(order).address,
                                                                  "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                  disabled: !unref(order).is_delivery,
                                                                  rules: unref(getAddressRules),
                                                                  label: _ctx.$t("addres"),
                                                                  "hide-details": "",
                                                                  variant: "outlined",
                                                                  density: "compact",
                                                                  required: ""
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(VCol, { cols: "12" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VCheckbox, {
                                                                  color: "#0F9D58",
                                                                  modelValue: unref(order).is_delivery,
                                                                  "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                  label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode(VCol, { class: "text-end" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VBtn, {
                                                                  color: "#0F9D58",
                                                                  type: "submit"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(VStepperWindowItem, {
                                    value: !unref(token) ? 1 : null
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "grey lighten-4 py-12" }, [
                                        createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                          default: withCtx(() => [
                                            createVNode(VCol, {
                                              cols: "12",
                                              lg: "6",
                                              md: "8",
                                              sm: "12"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(VCard, {
                                                  flat: "",
                                                  outlined: "",
                                                  width: "auto",
                                                  class: "mx-auto"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(VTabs, {
                                                      modelValue: unref(tab),
                                                      "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                      "active-class": "white",
                                                      height: "40",
                                                      "fixed-tabs": "",
                                                      "hide-slider": ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(VBtn, {
                                                          color: "#0F9D58",
                                                          "min-width": "140px",
                                                          class: "button-menu",
                                                          onClick: ($event) => handleTabClick(0),
                                                          flat: ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                          ]),
                                                          _: 1
                                                        }, 8, ["onClick"]),
                                                        createVNode(VBtn, {
                                                          color: "#0F9D58",
                                                          class: "button-menu",
                                                          onClick: ($event) => handleTabClick(1),
                                                          flat: ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                          ]),
                                                          _: 1
                                                        }, 8, ["onClick"])
                                                      ]),
                                                      _: 1
                                                    }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                    createVNode(VWindow, {
                                                      modelValue: unref(tab),
                                                      "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(VWindowItem, { value: 0 }, {
                                                          default: withCtx(() => [
                                                            createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                            createVNode(VCardText, { class: "p-0 my-7" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VForm, {
                                                                  modelValue: unref(valid),
                                                                  "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                  onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                  ref: "form",
                                                                  "lazy-validation": ""
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(user).phonenumber,
                                                                      "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                      "prepend-inner-icon": "mdi-phone",
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("phone"),
                                                                      variant: "outlined",
                                                                      rules: [rules.phoneRequired, rules.phonenumber],
                                                                      type: "tel"
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(user).password,
                                                                      "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                      "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                      type: unref(visible) ? "text" : "password",
                                                                      rules: [rules.passwordRequired, rules.min],
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("password"),
                                                                      "prepend-inner-icon": "mdi-lock-outline",
                                                                      variant: "outlined",
                                                                      "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                    createVNode("div", { class: "text-center" }, [
                                                                      createVNode(VBtn, {
                                                                        type: "submit",
                                                                        color: "#0F9D58",
                                                                        class: "mb-4 button-menu",
                                                                        "min-width": "200px"
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ]),
                                                                    createVNode("div", {
                                                                      onClick: ($event) => handleTabClick(2),
                                                                      class: "text-body-2 font-weight-regular",
                                                                      style: { "cursor": "pointer" }
                                                                    }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                    createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(VWindowItem, { value: 1 }, {
                                                          default: withCtx(() => [
                                                            createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                            createVNode(VCardText, { class: "p-0 my-7" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VForm, {
                                                                  modelValue: unref(valid),
                                                                  "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                  onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                  ref: "form",
                                                                  "lazy-validation": ""
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VCol, { cols: "auto" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(createUser).phone,
                                                                          "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                          "prepend-inner-icon": "mdi-phone",
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("phone"),
                                                                          variant: "outlined",
                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                          type: "tel"
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(createUser).password1,
                                                                          "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                          type: unref(visible) ? "text" : "password",
                                                                          rules: [rules.passwordRequired, rules.min],
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("password"),
                                                                          "prepend-inner-icon": "mdi-lock-outline",
                                                                          variant: "outlined",
                                                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(createUser).password2,
                                                                          "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                          type: unref(visible) ? "text" : "password",
                                                                          rules: [rules.passwordRequired, rules.min],
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("password"),
                                                                          "prepend-inner-icon": "mdi-lock-outline",
                                                                          variant: "outlined",
                                                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode("div", { class: "text-center" }, [
                                                                      createVNode(VBtn, {
                                                                        type: "submit",
                                                                        color: "#0F9D58",
                                                                        class: "mb-4 button-menu",
                                                                        "min-width": "300px"
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                    ])
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(VWindowItem, { value: 2 }, {
                                                          default: withCtx(() => [
                                                            createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                            createVNode(VCardText, { class: "p-0 my-7" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VForm, {
                                                                  modelValue: unref(valid),
                                                                  "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                  onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                  ref: "form",
                                                                  "lazy-validation": ""
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(user).phonenumber,
                                                                      "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                      "prepend-inner-icon": "mdi-phone",
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("phone"),
                                                                      variant: "outlined",
                                                                      rules: [rules.phoneRequired, rules.phonenumber],
                                                                      type: "tel"
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                    createVNode("div", { class: "text-center" }, [
                                                                      createVNode(VBtn, {
                                                                        type: "submit",
                                                                        color: "#0F9D58",
                                                                        class: "mb-4 button-menu",
                                                                        "min-width": "200px"
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ]),
                                                                    createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ])
                                    ]),
                                    _: 1
                                  }, 8, ["value"]),
                                  createVNode(VStepperWindowItem, {
                                    value: unref(token) ? 2 : null
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(VCard, { flat: "" }, {
                                        default: withCtx(() => [
                                          createVNode("h2", { class: "text-h5 text-center mt-5 mb-5" }, toDisplayString(_ctx.$t("order")), 1),
                                          createVNode(VCardText, null, {
                                            default: withCtx(() => [
                                              createVNode(VContainer, null, {
                                                default: withCtx(() => [
                                                  createVNode(VForm, {
                                                    modelValue: unref(valid),
                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                    onSubmit: withModifiers(onMyorders, ["prevent"])
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(VRow, null, {
                                                        default: withCtx(() => [
                                                          createVNode(VCol, { cols: "12" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(order).full_name,
                                                                "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                                rules: [rules.fullName],
                                                                label: _ctx.$t("f"),
                                                                "hide-details": "",
                                                                variant: "outlined",
                                                                density: "compact",
                                                                required: ""
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(VCol, { cols: "12" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(order).phone,
                                                                "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                                label: _ctx.$t("phone"),
                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                "hide-details": "",
                                                                variant: "outlined",
                                                                density: "compact",
                                                                required: ""
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(VCol, { cols: "12" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(order).address,
                                                                "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                                disabled: !unref(order).is_delivery,
                                                                rules: unref(getAddressRules),
                                                                label: _ctx.$t("addres"),
                                                                "hide-details": "",
                                                                variant: "outlined",
                                                                density: "compact",
                                                                required: ""
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(VCol, { cols: "12" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VCheckbox, {
                                                                color: "#0F9D58",
                                                                modelValue: unref(order).is_delivery,
                                                                "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                                label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode(VCol, { class: "text-end" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VBtn, {
                                                                color: "#0F9D58",
                                                                type: "submit"
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["value"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(VStepperHeader, null, {
                              default: withCtx(() => [
                                createVNode(VDivider),
                                createVNode(VStepperItem, {
                                  complete: unref(e1) > 1,
                                  title: _ctx.$t("login"),
                                  value: 1,
                                  editable: "",
                                  disabled: !!unref(token),
                                  color: "#0F9D58"
                                }, null, 8, ["complete", "title", "disabled"]),
                                createVNode(VDivider),
                                createVNode(VDivider),
                                createVNode(VStepperItem, {
                                  complete: unref(e1) > 2,
                                  title: _ctx.$t("order_item"),
                                  value: 2,
                                  editable: "",
                                  disabled: !unref(token),
                                  color: "#0F9D58"
                                }, null, 8, ["complete", "title", "disabled"]),
                                createVNode(VDivider)
                              ]),
                              _: 1
                            }),
                            createVNode(VStepperWindow, null, {
                              default: withCtx(() => [
                                createVNode(VStepperWindowItem, {
                                  value: !unref(token) ? 1 : null
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "grey lighten-4 py-12" }, [
                                      createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                        default: withCtx(() => [
                                          createVNode(VCol, {
                                            cols: "12",
                                            lg: "6",
                                            md: "8",
                                            sm: "12"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(VCard, {
                                                flat: "",
                                                outlined: "",
                                                width: "auto",
                                                class: "mx-auto"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VTabs, {
                                                    modelValue: unref(tab),
                                                    "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                    "active-class": "white",
                                                    height: "40",
                                                    "fixed-tabs": "",
                                                    "hide-slider": ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(VBtn, {
                                                        color: "#0F9D58",
                                                        "min-width": "140px",
                                                        class: "button-menu",
                                                        onClick: ($event) => handleTabClick(0),
                                                        flat: ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                        ]),
                                                        _: 1
                                                      }, 8, ["onClick"]),
                                                      createVNode(VBtn, {
                                                        color: "#0F9D58",
                                                        class: "button-menu",
                                                        onClick: ($event) => handleTabClick(1),
                                                        flat: ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                        ]),
                                                        _: 1
                                                      }, 8, ["onClick"])
                                                    ]),
                                                    _: 1
                                                  }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                  createVNode(VWindow, {
                                                    modelValue: unref(tab),
                                                    "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(VWindowItem, { value: 0 }, {
                                                        default: withCtx(() => [
                                                          createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                          createVNode(VCardText, { class: "p-0 my-7" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VForm, {
                                                                modelValue: unref(valid),
                                                                "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                ref: "form",
                                                                "lazy-validation": ""
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(user).phonenumber,
                                                                    "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                    "prepend-inner-icon": "mdi-phone",
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("phone"),
                                                                    variant: "outlined",
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    type: "tel"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(user).password,
                                                                    "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                  createVNode("div", { class: "text-center" }, [
                                                                    createVNode(VBtn, {
                                                                      type: "submit",
                                                                      color: "#0F9D58",
                                                                      class: "mb-4 button-menu",
                                                                      "min-width": "200px"
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  createVNode("div", {
                                                                    onClick: ($event) => handleTabClick(2),
                                                                    class: "text-body-2 font-weight-regular",
                                                                    style: { "cursor": "pointer" }
                                                                  }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                ]),
                                                                _: 1
                                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(VWindowItem, { value: 1 }, {
                                                        default: withCtx(() => [
                                                          createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                          createVNode(VCardText, { class: "p-0 my-7" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VForm, {
                                                                modelValue: unref(valid),
                                                                "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                ref: "form",
                                                                "lazy-validation": ""
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VCol, { cols: "auto" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(createUser).phone,
                                                                        "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                        "prepend-inner-icon": "mdi-phone",
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("phone"),
                                                                        variant: "outlined",
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        type: "tel"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(createUser).password1,
                                                                        "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                        type: unref(visible) ? "text" : "password",
                                                                        rules: [rules.passwordRequired, rules.min],
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("password"),
                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                        variant: "outlined",
                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(createUser).password2,
                                                                        "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                        type: unref(visible) ? "text" : "password",
                                                                        rules: [rules.passwordRequired, rules.min],
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("password"),
                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                        variant: "outlined",
                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode("div", { class: "text-center" }, [
                                                                    createVNode(VBtn, {
                                                                      type: "submit",
                                                                      color: "#0F9D58",
                                                                      class: "mb-4 button-menu",
                                                                      "min-width": "300px"
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                  ])
                                                                ]),
                                                                _: 1
                                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(VWindowItem, { value: 2 }, {
                                                        default: withCtx(() => [
                                                          createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                          createVNode(VCardText, { class: "p-0 my-7" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VForm, {
                                                                modelValue: unref(valid),
                                                                "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                ref: "form",
                                                                "lazy-validation": ""
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(user).phonenumber,
                                                                    "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                    "prepend-inner-icon": "mdi-phone",
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("phone"),
                                                                    variant: "outlined",
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    type: "tel"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                  createVNode("div", { class: "text-center" }, [
                                                                    createVNode(VBtn, {
                                                                      type: "submit",
                                                                      color: "#0F9D58",
                                                                      class: "mb-4 button-menu",
                                                                      "min-width": "200px"
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                ]),
                                                                _: 1
                                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ])
                                  ]),
                                  _: 1
                                }, 8, ["value"]),
                                createVNode(VStepperWindowItem, {
                                  value: unref(token) ? 2 : null
                                }, {
                                  default: withCtx(() => [
                                    createVNode(VCard, { flat: "" }, {
                                      default: withCtx(() => [
                                        createVNode("h2", { class: "text-h5 text-center mt-5 mb-5" }, toDisplayString(_ctx.$t("order")), 1),
                                        createVNode(VCardText, null, {
                                          default: withCtx(() => [
                                            createVNode(VContainer, null, {
                                              default: withCtx(() => [
                                                createVNode(VForm, {
                                                  modelValue: unref(valid),
                                                  "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                  onSubmit: withModifiers(onMyorders, ["prevent"])
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(VRow, null, {
                                                      default: withCtx(() => [
                                                        createVNode(VCol, { cols: "12" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VTextField, {
                                                              modelValue: unref(order).full_name,
                                                              "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                              rules: [rules.fullName],
                                                              label: _ctx.$t("f"),
                                                              "hide-details": "",
                                                              variant: "outlined",
                                                              density: "compact",
                                                              required: ""
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(VCol, { cols: "12" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VTextField, {
                                                              modelValue: unref(order).phone,
                                                              "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                              label: _ctx.$t("phone"),
                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                              "hide-details": "",
                                                              variant: "outlined",
                                                              density: "compact",
                                                              required: ""
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(VCol, { cols: "12" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VTextField, {
                                                              modelValue: unref(order).address,
                                                              "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                              disabled: !unref(order).is_delivery,
                                                              rules: unref(getAddressRules),
                                                              label: _ctx.$t("addres"),
                                                              "hide-details": "",
                                                              variant: "outlined",
                                                              density: "compact",
                                                              required: ""
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(VCol, { cols: "12" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VCheckbox, {
                                                              color: "#0F9D58",
                                                              modelValue: unref(order).is_delivery,
                                                              "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                              label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(VCol, { class: "text-end" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VBtn, {
                                                              color: "#0F9D58",
                                                              type: "submit"
                                                            }, {
                                                              default: withCtx(() => [
                                                                createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["value"])
                              ]),
                              _: 1
                            })
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(VBtn, {
                      text: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C",
                      class: "mt-3",
                      color: "#0F9D58",
                      onClick: ($event) => dialog.value = false
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(VCardActions, null, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(VSpacer, null, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(VSpacer)
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(VStepper, {
                        modelValue: unref(e1),
                        "onUpdate:modelValue": ($event) => isRef(e1) ? e1.value = $event : null,
                        "hide-actions": ""
                      }, {
                        default: withCtx(({ props }) => [
                          createVNode(VStepperHeader, null, {
                            default: withCtx(() => [
                              createVNode(VDivider),
                              createVNode(VStepperItem, {
                                complete: unref(e1) > 1,
                                title: _ctx.$t("login"),
                                value: 1,
                                editable: "",
                                disabled: !!unref(token),
                                color: "#0F9D58"
                              }, null, 8, ["complete", "title", "disabled"]),
                              createVNode(VDivider),
                              createVNode(VDivider),
                              createVNode(VStepperItem, {
                                complete: unref(e1) > 2,
                                title: _ctx.$t("order_item"),
                                value: 2,
                                editable: "",
                                disabled: !unref(token),
                                color: "#0F9D58"
                              }, null, 8, ["complete", "title", "disabled"]),
                              createVNode(VDivider)
                            ]),
                            _: 1
                          }),
                          createVNode(VStepperWindow, null, {
                            default: withCtx(() => [
                              createVNode(VStepperWindowItem, {
                                value: !unref(token) ? 1 : null
                              }, {
                                default: withCtx(() => [
                                  createVNode("div", { class: "grey lighten-4 py-12" }, [
                                    createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                      default: withCtx(() => [
                                        createVNode(VCol, {
                                          cols: "12",
                                          lg: "6",
                                          md: "8",
                                          sm: "12"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(VCard, {
                                              flat: "",
                                              outlined: "",
                                              width: "auto",
                                              class: "mx-auto"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(VTabs, {
                                                  modelValue: unref(tab),
                                                  "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                  "active-class": "white",
                                                  height: "40",
                                                  "fixed-tabs": "",
                                                  "hide-slider": ""
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(VBtn, {
                                                      color: "#0F9D58",
                                                      "min-width": "140px",
                                                      class: "button-menu",
                                                      onClick: ($event) => handleTabClick(0),
                                                      flat: ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onClick"]),
                                                    createVNode(VBtn, {
                                                      color: "#0F9D58",
                                                      class: "button-menu",
                                                      onClick: ($event) => handleTabClick(1),
                                                      flat: ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onClick"])
                                                  ]),
                                                  _: 1
                                                }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                createVNode(VWindow, {
                                                  modelValue: unref(tab),
                                                  "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(VWindowItem, { value: 0 }, {
                                                      default: withCtx(() => [
                                                        createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                        createVNode(VCardText, { class: "p-0 my-7" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VForm, {
                                                              modelValue: unref(valid),
                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                              onSubmit: withModifiers(onLogin, ["prevent"]),
                                                              ref: "form",
                                                              "lazy-validation": ""
                                                            }, {
                                                              default: withCtx(() => [
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(user).phonenumber,
                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                  "prepend-inner-icon": "mdi-phone",
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("phone"),
                                                                  variant: "outlined",
                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                  type: "tel"
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(user).password,
                                                                  "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                  type: unref(visible) ? "text" : "password",
                                                                  rules: [rules.passwordRequired, rules.min],
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("password"),
                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                  variant: "outlined",
                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                createVNode("div", { class: "text-center" }, [
                                                                  createVNode(VBtn, {
                                                                    type: "submit",
                                                                    color: "#0F9D58",
                                                                    class: "mb-4 button-menu",
                                                                    "min-width": "200px"
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                createVNode("div", {
                                                                  onClick: ($event) => handleTabClick(2),
                                                                  class: "text-body-2 font-weight-regular",
                                                                  style: { "cursor": "pointer" }
                                                                }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                              ]),
                                                              _: 1
                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(VWindowItem, { value: 1 }, {
                                                      default: withCtx(() => [
                                                        createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                        createVNode(VCardText, { class: "p-0 my-7" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VForm, {
                                                              modelValue: unref(valid),
                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                              onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                              ref: "form",
                                                              "lazy-validation": ""
                                                            }, {
                                                              default: withCtx(() => [
                                                                createVNode(VCol, { cols: "auto" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(createUser).phone,
                                                                      "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                      "prepend-inner-icon": "mdi-phone",
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("phone"),
                                                                      variant: "outlined",
                                                                      rules: [rules.phoneRequired, rules.phonenumber],
                                                                      type: "tel"
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(createUser).password1,
                                                                      "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                      "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                      type: unref(visible) ? "text" : "password",
                                                                      rules: [rules.passwordRequired, rules.min],
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("password"),
                                                                      "prepend-inner-icon": "mdi-lock-outline",
                                                                      variant: "outlined",
                                                                      "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(createUser).password2,
                                                                      "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                      "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                      type: unref(visible) ? "text" : "password",
                                                                      rules: [rules.passwordRequired, rules.min],
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("password"),
                                                                      "prepend-inner-icon": "mdi-lock-outline",
                                                                      variant: "outlined",
                                                                      "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode("div", { class: "text-center" }, [
                                                                  createVNode(VBtn, {
                                                                    type: "submit",
                                                                    color: "#0F9D58",
                                                                    class: "mb-4 button-menu",
                                                                    "min-width": "300px"
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                ])
                                                              ]),
                                                              _: 1
                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(VWindowItem, { value: 2 }, {
                                                      default: withCtx(() => [
                                                        createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                        createVNode(VCardText, { class: "p-0 my-7" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VForm, {
                                                              modelValue: unref(valid),
                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                              onSubmit: withModifiers(onLogin, ["prevent"]),
                                                              ref: "form",
                                                              "lazy-validation": ""
                                                            }, {
                                                              default: withCtx(() => [
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(user).phonenumber,
                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                  "prepend-inner-icon": "mdi-phone",
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("phone"),
                                                                  variant: "outlined",
                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                  type: "tel"
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                createVNode("div", { class: "text-center" }, [
                                                                  createVNode(VBtn, {
                                                                    type: "submit",
                                                                    color: "#0F9D58",
                                                                    class: "mb-4 button-menu",
                                                                    "min-width": "200px"
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                              ]),
                                                              _: 1
                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ])
                                ]),
                                _: 1
                              }, 8, ["value"]),
                              createVNode(VStepperWindowItem, {
                                value: unref(token) ? 2 : null
                              }, {
                                default: withCtx(() => [
                                  createVNode(VCard, { flat: "" }, {
                                    default: withCtx(() => [
                                      createVNode("h2", { class: "text-h5 text-center mt-5 mb-5" }, toDisplayString(_ctx.$t("order")), 1),
                                      createVNode(VCardText, null, {
                                        default: withCtx(() => [
                                          createVNode(VContainer, null, {
                                            default: withCtx(() => [
                                              createVNode(VForm, {
                                                modelValue: unref(valid),
                                                "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                onSubmit: withModifiers(onMyorders, ["prevent"])
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VRow, null, {
                                                    default: withCtx(() => [
                                                      createVNode(VCol, { cols: "12" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VTextField, {
                                                            modelValue: unref(order).full_name,
                                                            "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                            rules: [rules.fullName],
                                                            label: _ctx.$t("f"),
                                                            "hide-details": "",
                                                            variant: "outlined",
                                                            density: "compact",
                                                            required: ""
                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(VCol, { cols: "12" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VTextField, {
                                                            modelValue: unref(order).phone,
                                                            "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                            label: _ctx.$t("phone"),
                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                            "hide-details": "",
                                                            variant: "outlined",
                                                            density: "compact",
                                                            required: ""
                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(VCol, { cols: "12" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VTextField, {
                                                            modelValue: unref(order).address,
                                                            "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                            disabled: !unref(order).is_delivery,
                                                            rules: unref(getAddressRules),
                                                            label: _ctx.$t("addres"),
                                                            "hide-details": "",
                                                            variant: "outlined",
                                                            density: "compact",
                                                            required: ""
                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(VCol, { cols: "12" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VCheckbox, {
                                                            color: "#0F9D58",
                                                            modelValue: unref(order).is_delivery,
                                                            "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                            label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(VCol, { class: "text-end" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VBtn, {
                                                            color: "#0F9D58",
                                                            type: "submit"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["value"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(VBtn, {
                        text: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C",
                        class: "mt-3",
                        color: "#0F9D58",
                        onClick: ($event) => dialog.value = false
                      }, null, 8, ["onClick"]),
                      createVNode(VCardActions, null, {
                        default: withCtx(() => [
                          createVNode(VSpacer)
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(VDialog, {
                  modelValue: unref(dialog),
                  "onUpdate:modelValue": ($event) => isRef(dialog) ? dialog.value = $event : null,
                  width: "1024"
                }, {
                  activator: withCtx(({ props }) => [
                    createVNode(VBtn, mergeProps({
                      color: "#0F9D58",
                      class: "mr-3 elevation-0"
                    }, props, { style: { "border-radius": "7px" } }), {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(_ctx.$t("buy")), 1)
                      ]),
                      _: 2
                    }, 1040)
                  ]),
                  default: withCtx(() => [
                    createVNode(VStepper, {
                      modelValue: unref(e1),
                      "onUpdate:modelValue": ($event) => isRef(e1) ? e1.value = $event : null,
                      "hide-actions": ""
                    }, {
                      default: withCtx(({ props }) => [
                        createVNode(VStepperHeader, null, {
                          default: withCtx(() => [
                            createVNode(VDivider),
                            createVNode(VStepperItem, {
                              complete: unref(e1) > 1,
                              title: _ctx.$t("login"),
                              value: 1,
                              editable: "",
                              disabled: !!unref(token),
                              color: "#0F9D58"
                            }, null, 8, ["complete", "title", "disabled"]),
                            createVNode(VDivider),
                            createVNode(VDivider),
                            createVNode(VStepperItem, {
                              complete: unref(e1) > 2,
                              title: _ctx.$t("order_item"),
                              value: 2,
                              editable: "",
                              disabled: !unref(token),
                              color: "#0F9D58"
                            }, null, 8, ["complete", "title", "disabled"]),
                            createVNode(VDivider)
                          ]),
                          _: 1
                        }),
                        createVNode(VStepperWindow, null, {
                          default: withCtx(() => [
                            createVNode(VStepperWindowItem, {
                              value: !unref(token) ? 1 : null
                            }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "grey lighten-4 py-12" }, [
                                  createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                    default: withCtx(() => [
                                      createVNode(VCol, {
                                        cols: "12",
                                        lg: "6",
                                        md: "8",
                                        sm: "12"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(VCard, {
                                            flat: "",
                                            outlined: "",
                                            width: "auto",
                                            class: "mx-auto"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(VTabs, {
                                                modelValue: unref(tab),
                                                "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event,
                                                "active-class": "white",
                                                height: "40",
                                                "fixed-tabs": "",
                                                "hide-slider": ""
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VBtn, {
                                                    color: "#0F9D58",
                                                    "min-width": "140px",
                                                    class: "button-menu",
                                                    onClick: ($event) => handleTabClick(0),
                                                    flat: ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"]),
                                                  createVNode(VBtn, {
                                                    color: "#0F9D58",
                                                    class: "button-menu",
                                                    onClick: ($event) => handleTabClick(1),
                                                    flat: ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"])
                                                ]),
                                                _: 1
                                              }, 8, ["modelValue", "onUpdate:modelValue"]),
                                              createVNode(VWindow, {
                                                modelValue: unref(tab),
                                                "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : tab = $event
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VWindowItem, { value: 0 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                      createVNode(VCardText, { class: "p-0 my-7" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(onLogin, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(user).phonenumber,
                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                "prepend-inner-icon": "mdi-phone",
                                                                density: "compact",
                                                                placeholder: _ctx.$t("phone"),
                                                                variant: "outlined",
                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                type: "tel"
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                              createVNode(VTextField, {
                                                                modelValue: unref(user).password,
                                                                "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                type: unref(visible) ? "text" : "password",
                                                                rules: [rules.passwordRequired, rules.min],
                                                                density: "compact",
                                                                placeholder: _ctx.$t("password"),
                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                variant: "outlined",
                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "200px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              createVNode("div", {
                                                                onClick: ($event) => handleTabClick(2),
                                                                class: "text-body-2 font-weight-regular",
                                                                style: { "cursor": "pointer" }
                                                              }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(VWindowItem, { value: 1 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("reg")), 1),
                                                      createVNode(VCardText, { class: "p-0 my-7" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VCol, { cols: "auto" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).phone,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                    "prepend-inner-icon": "mdi-phone",
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("phone"),
                                                                    variant: "outlined",
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    type: "tel"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).password1,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).password2,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "300px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                              ])
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(VWindowItem, { value: 2 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4" }, toDisplayString(_ctx.$t("restore")), 1),
                                                      createVNode(VCardText, { class: "p-0 my-7" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(onLogin, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(user).phonenumber,
                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                "prepend-inner-icon": "mdi-phone",
                                                                density: "compact",
                                                                placeholder: _ctx.$t("phone"),
                                                                variant: "outlined",
                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                type: "tel"
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "200px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ])
                              ]),
                              _: 1
                            }, 8, ["value"]),
                            createVNode(VStepperWindowItem, {
                              value: unref(token) ? 2 : null
                            }, {
                              default: withCtx(() => [
                                createVNode(VCard, { flat: "" }, {
                                  default: withCtx(() => [
                                    createVNode("h2", { class: "text-h5 text-center mt-5 mb-5" }, toDisplayString(_ctx.$t("order")), 1),
                                    createVNode(VCardText, null, {
                                      default: withCtx(() => [
                                        createVNode(VContainer, null, {
                                          default: withCtx(() => [
                                            createVNode(VForm, {
                                              modelValue: unref(valid),
                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                              onSubmit: withModifiers(onMyorders, ["prevent"])
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(VRow, null, {
                                                  default: withCtx(() => [
                                                    createVNode(VCol, { cols: "12" }, {
                                                      default: withCtx(() => [
                                                        createVNode(VTextField, {
                                                          modelValue: unref(order).full_name,
                                                          "onUpdate:modelValue": ($event) => unref(order).full_name = $event,
                                                          rules: [rules.fullName],
                                                          label: _ctx.$t("f"),
                                                          "hide-details": "",
                                                          variant: "outlined",
                                                          density: "compact",
                                                          required: ""
                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "rules", "label"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(VCol, { cols: "12" }, {
                                                      default: withCtx(() => [
                                                        createVNode(VTextField, {
                                                          modelValue: unref(order).phone,
                                                          "onUpdate:modelValue": ($event) => unref(order).phone = $event,
                                                          label: _ctx.$t("phone"),
                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                          "hide-details": "",
                                                          variant: "outlined",
                                                          density: "compact",
                                                          required: ""
                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "label", "rules"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(VCol, { cols: "12" }, {
                                                      default: withCtx(() => [
                                                        createVNode(VTextField, {
                                                          modelValue: unref(order).address,
                                                          "onUpdate:modelValue": ($event) => unref(order).address = $event,
                                                          disabled: !unref(order).is_delivery,
                                                          rules: unref(getAddressRules),
                                                          label: _ctx.$t("addres"),
                                                          "hide-details": "",
                                                          variant: "outlined",
                                                          density: "compact",
                                                          required: ""
                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "rules", "label"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(VCol, { cols: "12" }, {
                                                      default: withCtx(() => [
                                                        createVNode(VCheckbox, {
                                                          color: "#0F9D58",
                                                          modelValue: unref(order).is_delivery,
                                                          "onUpdate:modelValue": ($event) => unref(order).is_delivery = $event,
                                                          label: "\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430"
                                                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(VCol, { class: "text-end" }, {
                                                      default: withCtx(() => [
                                                        createVNode(VBtn, {
                                                          color: "#0F9D58",
                                                          type: "submit"
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["value"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(VBtn, {
                      text: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C",
                      class: "mt-3",
                      color: "#0F9D58",
                      onClick: ($event) => dialog.value = false
                    }, null, 8, ["onClick"]),
                    createVNode(VCardActions, null, {
                      default: withCtx(() => [
                        createVNode(VSpacer)
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<div class="centered-container" data-v-4d6f8a3a><img${ssrRenderAttr("src", _imports_0)} alt="No Products Available" class="centered-image" data-v-4d6f8a3a></div>`);
      }
      _push(`</div></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/basket/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-4d6f8a3a"]]);

export { index as default };
//# sourceMappingURL=index-fccbe61b.mjs.map
