import { _ as __nuxt_component_0$1 } from './nuxt-link-691e5b50.mjs';
import { toRef, createVNode, mergeProps, withDirectives, vShow, useSSRContext, ref, withCtx, toDisplayString, unref, isRef, createTextVNode, openBlock, createBlock, Fragment, renderList, withModifiers } from 'vue';
import { p as propsFactory, I as IconValue, m as makeComponentProps, e as makeThemeProps, g as genericComponent, R as useLocale, ae as useTheme, k as useRender, af as pickWithRest, t as productStore, x as useAuth, v as useAuthToken, ag as useI18n } from '../server.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderStyle, ssrRenderAttrs, ssrRenderAttr, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import { j as makeLocationProps, g as makeRoundedProps, a as makeTagProps, c as useBackgroundColor, p as useRounded, b as useTextColor, l as useLocation, V as VIcon, d as VBtn } from './VBtn-55c932b0.mjs';
import { V as VMenu, a as VList, b as VListItem, c as VListItemTitle } from './VMenu-6cf816e1.mjs';
import { m as makeTransitionProps$1, M as MaybeTransition, V as VCardText, b as VCardTitle } from './ssrBoot-66bca22f.mjs';
import { c as VStepper, d as VStepperHeader, e as VStepperItem, f as VStepperWindow, g as VStepperWindowItem, b as VRow, h as VCol, i as VForm, j as VTextField } from './VTextField-17db1185.mjs';
import { V as VDivider, a as VCard, b as VCardActions } from './VSheet-f502d2db.mjs';
import { V as VTabs, a as VWindow, b as VWindowItem } from './VTabs-f421e6b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const makeVBadgeProps = propsFactory({
  bordered: Boolean,
  color: String,
  content: [Number, String],
  dot: Boolean,
  floating: Boolean,
  icon: IconValue,
  inline: Boolean,
  label: {
    type: String,
    default: "$vuetify.badge"
  },
  max: [Number, String],
  modelValue: {
    type: Boolean,
    default: true
  },
  offsetX: [Number, String],
  offsetY: [Number, String],
  textColor: String,
  ...makeComponentProps(),
  ...makeLocationProps({
    location: "top end"
  }),
  ...makeRoundedProps(),
  ...makeTagProps(),
  ...makeThemeProps(),
  ...makeTransitionProps$1({
    transition: "scale-rotate-transition"
  })
}, "VBadge");
const VBadge = genericComponent()({
  name: "VBadge",
  inheritAttrs: false,
  props: makeVBadgeProps(),
  setup(props, ctx) {
    const {
      backgroundColorClasses,
      backgroundColorStyles
    } = useBackgroundColor(toRef(props, "color"));
    const {
      roundedClasses
    } = useRounded(props);
    const {
      t
    } = useLocale();
    const {
      textColorClasses,
      textColorStyles
    } = useTextColor(toRef(props, "textColor"));
    const {
      themeClasses
    } = useTheme();
    const {
      locationStyles
    } = useLocation(props, true, (side) => {
      var _a, _b;
      const base = props.floating ? props.dot ? 2 : 4 : props.dot ? 8 : 12;
      return base + (["top", "bottom"].includes(side) ? +((_a = props.offsetY) != null ? _a : 0) : ["left", "right"].includes(side) ? +((_b = props.offsetX) != null ? _b : 0) : 0);
    });
    useRender(() => {
      const value = Number(props.content);
      const content = !props.max || isNaN(value) ? props.content : value <= +props.max ? value : `${props.max}+`;
      const [badgeAttrs, attrs] = pickWithRest(ctx.attrs, ["aria-atomic", "aria-label", "aria-live", "role", "title"]);
      return createVNode(props.tag, mergeProps({
        "class": ["v-badge", {
          "v-badge--bordered": props.bordered,
          "v-badge--dot": props.dot,
          "v-badge--floating": props.floating,
          "v-badge--inline": props.inline
        }, props.class]
      }, attrs, {
        "style": props.style
      }), {
        default: () => {
          var _a, _b;
          return [createVNode("div", {
            "class": "v-badge__wrapper"
          }, [(_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a), createVNode(MaybeTransition, {
            "transition": props.transition
          }, {
            default: () => {
              var _a2, _b2;
              return [withDirectives(createVNode("span", mergeProps({
                "class": ["v-badge__badge", themeClasses.value, backgroundColorClasses.value, roundedClasses.value, textColorClasses.value],
                "style": [backgroundColorStyles.value, textColorStyles.value, props.inline ? {} : locationStyles.value],
                "aria-atomic": "true",
                "aria-label": t(props.label, value),
                "aria-live": "polite",
                "role": "status"
              }, badgeAttrs), [props.dot ? void 0 : ctx.slots.badge ? (_b2 = (_a2 = ctx.slots).badge) == null ? void 0 : _b2.call(_a2) : props.icon ? createVNode(VIcon, {
                "icon": props.icon
              }, null) : content]), [[vShow, props.modelValue]])];
            }
          })])];
        }
      });
    });
    return {};
  }
});
const _sfc_main$2 = {
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    const store = productStore();
    const isMenuOpen = ref(false);
    const { login, registrations, logout, change_password, reset_password } = useAuth();
    const menu = ref(false);
    const valid = ref(false);
    const visible = ref(false);
    const token = useAuthToken();
    const errorMessage = ref("");
    const errorStatus = ref("");
    const tab = ref(0);
    const e1 = ref(1);
    let activLang = ref("ru");
    const { locales, locale } = useI18n();
    const user = ref({
      phonenumber: "",
      password: ""
    });
    const createUser = ref({
      phone: "",
      password1: "",
      password2: ""
    });
    const Update = ref({
      old_password: "",
      new_password: ""
    });
    const reset = ref({
      phone_number: ""
    });
    const rules = {
      phonenumber: (value) => {
        const pattern = /^\+?\d{12}$/;
        return pattern.test(value) || "\u041F\u0440\u0438\u043C\u0435\u0440 +998993332211";
      },
      phoneRequired: (value) => !!value || "You must enter your phone",
      passwordRequired: (value) => !!value || "Your password is required",
      min: (v) => v.length >= 6 || "\u041C\u0438\u043D\u0438\u043C\u0443\u043C 6 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
    };
    const changeLocale = (selectedLocale) => {
      activLang.value = selectedLocale;
      locale.value = selectedLocale;
      isMenuOpen.value = false;
    };
    const handleTabClick = (index) => {
      tab.value = index;
    };
    async function Change_password() {
      if (valid.value) {
        try {
          await change_password(Update.value.old_password, Update.value.new_password);
          menu.value = false;
        } catch (error) {
          console.error(error);
        }
      }
    }
    async function Reset_Password() {
      if (valid.value) {
        try {
          await reset_password(reset.value.phone_number);
          tab.value = 0;
        } catch (error) {
          console.error(error);
          errorMessage.value = "\u041D\u0435 \u0432\u0435\u0440\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440!";
        }
      }
    }
    async function onLogin() {
      if (valid.value) {
        try {
          await login(user.value.phonenumber, user.value.password);
          await store.getUser();
          e1.value++;
          menu.value = false;
        } catch (error) {
          console.error(error);
          errorMessage.value = "\u041D\u0435 \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0438\u043B\u0438 \u043F\u0430\u0440\u043E\u043B\u044C!!";
        }
      }
    }
    async function onRegistrations() {
      try {
        if (valid.value) {
          const { user: user2, status } = await registrations(createUser.value.phone, createUser.value.password1, createUser.value.password2);
          if (user2.value !== null && status !== "error") {
            await login(createUser.value.phone, createUser.value.password1);
            await store.getUser();
            e1.value++;
            menu.value = false;
          } else {
            errorStatus.value = "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0443\u0436\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442";
          }
        }
      } catch (error) {
        console.error("Unexpected error during registration:", error);
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<!--[--><div class="mb-nav" data-v-62fd77cd><div class="mb-move-item" data-v-62fd77cd></div><div class="mb-nav-item active" data-v-62fd77cd>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#home" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VIcon, {
              icon: "mdi-home",
              color: "grey"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(VIcon, {
                icon: "mdi-home",
                color: "grey"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="mb-nav-item" data-v-62fd77cd>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#about" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VIcon, {
              icon: "mdi-information-outline",
              color: "grey"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(VIcon, {
                icon: "mdi-information-outline",
                color: "grey"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="mb-nav-item" data-v-62fd77cd>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#delivery" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VIcon, {
              icon: "mdi-truck",
              color: "grey"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(VIcon, {
                icon: "mdi-truck",
                color: "grey"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="mb-nav-item" data-v-62fd77cd>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#manufacture" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VIcon, {
              icon: "mdi-handshake",
              color: "grey"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(VIcon, {
                icon: "mdi-handshake",
                color: "grey"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="mb-nav-item" data-v-62fd77cd>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/products" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VIcon, {
              icon: "mdi-medical-bag",
              color: "grey"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(VIcon, {
                icon: "mdi-medical-bag",
                color: "grey"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><button class="back-to-top" data-v-62fd77cd>`);
      _push(ssrRenderComponent(VIcon, {
        icon: "mdi-arrow-up",
        color: "#fff",
        size: "small"
      }, null, _parent));
      _push(`</button><div class="nav" data-v-62fd77cd><div class="menu-wrap" data-v-62fd77cd>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#home" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="logo" data-v-62fd77cd${_scopeId}> SVS </div>`);
          } else {
            return [
              createVNode("div", { class: "logo" }, " SVS ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="menu h-xs" data-v-62fd77cd>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#home" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="menu-item active" data-target="home" data-v-62fd77cd${_scopeId}>${ssrInterpolate(_ctx.$t("home"))}</div>`);
          } else {
            return [
              createVNode("div", {
                class: "menu-item active",
                "data-target": "home"
              }, toDisplayString(_ctx.$t("home")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#about" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="menu-item" data-target="about" data-v-62fd77cd${_scopeId}>${ssrInterpolate(_ctx.$t("about"))}</div>`);
          } else {
            return [
              createVNode("div", {
                class: "menu-item",
                "data-target": "about"
              }, toDisplayString(_ctx.$t("about")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#delivery" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="menu-item" data-target="delivery" data-v-62fd77cd${_scopeId}>${ssrInterpolate(_ctx.$t("delivery"))}</div>`);
          } else {
            return [
              createVNode("div", {
                class: "menu-item",
                "data-target": "delivery"
              }, toDisplayString(_ctx.$t("delivery")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#manufacture" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="menu-item" data-target="manufacture" data-v-62fd77cd${_scopeId}>${ssrInterpolate(_ctx.$t("manufacture"))}</div>`);
          } else {
            return [
              createVNode("div", {
                class: "menu-item",
                "data-target": "manufacture"
              }, toDisplayString(_ctx.$t("manufacture")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/products", hash: "" } }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="menu-item" data-v-62fd77cd${_scopeId}>${ssrInterpolate(_ctx.$t("products"))}</div>`);
          } else {
            return [
              createVNode("div", { class: "menu-item" }, toDisplayString(_ctx.$t("products")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="right-menu" data-v-62fd77cd><div class="d-flex mx-3" data-v-62fd77cd>`);
      _push(ssrRenderComponent(VMenu, {
        modelValue: unref(isMenuOpen),
        "onUpdate:modelValue": ($event) => isRef(isMenuOpen) ? isMenuOpen.value = $event : null
      }, {
        activator: withCtx(({ props }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VBtn, mergeProps({
              color: "#0F9D58",
              width: "48px",
              class: "mx-3 px-0 align-self-center button-lang"
            }, props), {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VIcon, { left: "" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`mdi-translate`);
                      } else {
                        return [
                          createTextVNode("mdi-translate")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(VIcon, {
                    small: "",
                    right: ""
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`mdi-menu-down`);
                      } else {
                        return [
                          createTextVNode("mdi-menu-down")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VIcon, { left: "" }, {
                      default: withCtx(() => [
                        createTextVNode("mdi-translate")
                      ]),
                      _: 1
                    }),
                    createVNode(VIcon, {
                      small: "",
                      right: ""
                    }, {
                      default: withCtx(() => [
                        createTextVNode("mdi-menu-down")
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VBtn, mergeProps({
                color: "#0F9D58",
                width: "48px",
                class: "mx-3 px-0 align-self-center button-lang"
              }, props), {
                default: withCtx(() => [
                  createVNode(VIcon, { left: "" }, {
                    default: withCtx(() => [
                      createTextVNode("mdi-translate")
                    ]),
                    _: 1
                  }),
                  createVNode(VIcon, {
                    small: "",
                    right: ""
                  }, {
                    default: withCtx(() => [
                      createTextVNode("mdi-menu-down")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, 1040)
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VList, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(locales), (item, index) => {
                    _push3(ssrRenderComponent(VListItem, {
                      key: index,
                      onClick: ($event) => changeLocale(item.code)
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(VListItemTitle, null, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(`${ssrInterpolate(item.code)}`);
                              } else {
                                return [
                                  createTextVNode(toDisplayString(item.code), 1)
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(VListItemTitle, null, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(item.code), 1)
                              ]),
                              _: 2
                            }, 1024)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(locales), (item, index) => {
                      return openBlock(), createBlock(VListItem, {
                        key: index,
                        onClick: ($event) => changeLocale(item.code)
                      }, {
                        default: withCtx(() => [
                          createVNode(VListItemTitle, null, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(item.code), 1)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1032, ["onClick"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VList, null, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(locales), (item, index) => {
                    return openBlock(), createBlock(VListItem, {
                      key: index,
                      onClick: ($event) => changeLocale(item.code)
                    }, {
                      default: withCtx(() => [
                        createVNode(VListItemTitle, null, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(item.code), 1)
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1032, ["onClick"]);
                  }), 128))
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(VBadge, {
        content: unref(store).cards.length
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_nuxt_link, {
              to: "/basket",
              class: "basket-btn"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VIcon, {
                    icon: "mdi-cart",
                    color: "#fff"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VIcon, {
                      icon: "mdi-cart",
                      color: "#fff"
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_nuxt_link, {
                to: "/basket",
                class: "basket-btn"
              }, {
                default: withCtx(() => [
                  createVNode(VIcon, {
                    icon: "mdi-cart",
                    color: "#fff"
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(VMenu, {
        modelValue: unref(menu),
        "onUpdate:modelValue": ($event) => isRef(menu) ? menu.value = $event : null,
        "close-on-content-click": false,
        location: "left",
        transition: "slide-y-transition"
      }, {
        activator: withCtx(({ props }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VBtn, mergeProps({
              class: "mx-3 profile-button",
              color: "#0F9D58",
              icon: unref(token) ? "mdi-account" : "mdi-login"
            }, props), null, _parent2, _scopeId));
          } else {
            return [
              createVNode(VBtn, mergeProps({
                class: "mx-3 profile-button",
                color: "#0F9D58",
                icon: unref(token) ? "mdi-account" : "mdi-login"
              }, props), null, 16, ["icon"])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(VStepper, {
              modelValue: unref(e1),
              "onUpdate:modelValue": ($event) => isRef(e1) ? e1.value = $event : null,
              "hide-actions": ""
            }, {
              default: withCtx(({ props }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(VStepperHeader, { class: "d-none" }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(VStepperItem, {
                          complete: unref(e1) > 1,
                          title: `\u0412\u0445\u043E\u0434`,
                          value: 1,
                          editable: "",
                          disabled: !!unref(token),
                          color: "#0F9D58"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(VDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(VDivider, null, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(VStepperItem, {
                          complete: unref(e1) > 2,
                          title: `Step 2`,
                          value: 2,
                          editable: "",
                          disabled: !unref(token),
                          color: "#0F9D58"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(VDivider, null, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VDivider),
                          createVNode(VStepperItem, {
                            complete: unref(e1) > 1,
                            title: `\u0412\u0445\u043E\u0434`,
                            value: 1,
                            editable: "",
                            disabled: !!unref(token),
                            color: "#0F9D58"
                          }, null, 8, ["complete", "disabled"]),
                          createVNode(VDivider),
                          createVNode(VDivider),
                          createVNode(VStepperItem, {
                            complete: unref(e1) > 2,
                            title: `Step 2`,
                            value: 2,
                            editable: "",
                            disabled: !unref(token),
                            color: "#0F9D58"
                          }, null, 8, ["complete", "disabled"]),
                          createVNode(VDivider)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(VStepperWindow, null, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(VStepperWindowItem, {
                          value: !unref(token) ? 1 : null
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="grey lighten-4" data-v-62fd77cd${_scopeId4}>`);
                              _push5(ssrRenderComponent(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(VCol, { cols: "12" }, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(VCard, {
                                            flat: "",
                                            outlined: "",
                                            "min-width": "300",
                                            class: "mx-auto"
                                          }, {
                                            default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(ssrRenderComponent(VTabs, {
                                                  modelValue: unref(tab),
                                                  "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null,
                                                  "active-class": "white",
                                                  height: "40",
                                                  "fixed-tabs": "",
                                                  "hide-slider": ""
                                                }, {
                                                  default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(ssrRenderComponent(VBtn, {
                                                        color: "#0F9D58",
                                                        "min-width": "100",
                                                        class: "button-menu",
                                                        onClick: ($event) => handleTabClick(0),
                                                        flat: ""
                                                      }, {
                                                        default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`${ssrInterpolate(_ctx.$t("login"))}`);
                                                          } else {
                                                            return [
                                                              createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                            ];
                                                          }
                                                        }),
                                                        _: 2
                                                      }, _parent9, _scopeId8));
                                                      _push9(ssrRenderComponent(VBtn, {
                                                        color: "#0F9D58",
                                                        "min-width": "100",
                                                        class: "button-menu",
                                                        onClick: ($event) => handleTabClick(1),
                                                        flat: ""
                                                      }, {
                                                        default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`${ssrInterpolate(_ctx.$t("reg"))}`);
                                                          } else {
                                                            return [
                                                              createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                            ];
                                                          }
                                                        }),
                                                        _: 2
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      return [
                                                        createVNode(VBtn, {
                                                          color: "#0F9D58",
                                                          "min-width": "100",
                                                          class: "button-menu",
                                                          onClick: ($event) => handleTabClick(0),
                                                          flat: ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                          ]),
                                                          _: 1
                                                        }, 8, ["onClick"]),
                                                        createVNode(VBtn, {
                                                          color: "#0F9D58",
                                                          "min-width": "100",
                                                          class: "button-menu",
                                                          onClick: ($event) => handleTabClick(1),
                                                          flat: ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                          ]),
                                                          _: 1
                                                        }, 8, ["onClick"])
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                                _push8(ssrRenderComponent(VWindow, {
                                                  modelValue: unref(tab),
                                                  "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null
                                                }, {
                                                  default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(ssrRenderComponent(VWindowItem, { value: 0 }, {
                                                        default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<h1 class="mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" data-v-62fd77cd${_scopeId9}>${ssrInterpolate(_ctx.$t("login"))}</h1>`);
                                                            _push10(ssrRenderComponent(VCardText, { class: "my-7 my-auth" }, {
                                                              default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                if (_push11) {
                                                                  _push11(ssrRenderComponent(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: onLogin,
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                      if (_push12) {
                                                                        _push12(ssrRenderComponent(VCol, { cols: "auto" }, {
                                                                          default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                            if (_push13) {
                                                                              _push13(ssrRenderComponent(VTextField, {
                                                                                modelValue: unref(user).phonenumber,
                                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                class: "mb-4",
                                                                                "prepend-inner-icon": "mdi-phone",
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("phone"),
                                                                                variant: "outlined",
                                                                                "single-line": "",
                                                                                "hide-details": "",
                                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                                type: "tel"
                                                                              }, null, _parent13, _scopeId12));
                                                                              _push13(ssrRenderComponent(VTextField, {
                                                                                modelValue: unref(user).password,
                                                                                "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "single-line": "",
                                                                                "hide-details": "",
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, _parent13, _scopeId12));
                                                                            } else {
                                                                              return [
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(user).phonenumber,
                                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                  class: "mb-4",
                                                                                  "prepend-inner-icon": "mdi-phone",
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("phone"),
                                                                                  variant: "outlined",
                                                                                  "single-line": "",
                                                                                  "hide-details": "",
                                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                                  type: "tel"
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(user).password,
                                                                                  "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                  type: unref(visible) ? "text" : "password",
                                                                                  rules: [rules.passwordRequired, rules.min],
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("password"),
                                                                                  "single-line": "",
                                                                                  "hide-details": "",
                                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                                  variant: "outlined",
                                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                              ];
                                                                            }
                                                                          }),
                                                                          _: 2
                                                                        }, _parent12, _scopeId11));
                                                                        _push12(`<div class="text-center" data-v-62fd77cd${_scopeId11}>`);
                                                                        _push12(ssrRenderComponent(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "200px"
                                                                        }, {
                                                                          default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                            if (_push13) {
                                                                              _push13(`${ssrInterpolate(_ctx.$t("login"))}`);
                                                                            } else {
                                                                              return [
                                                                                createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                              ];
                                                                            }
                                                                          }),
                                                                          _: 2
                                                                        }, _parent12, _scopeId11));
                                                                        _push12(`</div><div class="text-body-2 font-weight-regular" style="${ssrRenderStyle({ "cursor": "pointer" })}" data-v-62fd77cd${_scopeId11}>${ssrInterpolate(_ctx.$t("reset_pass"))}</div><div class="text-red" data-v-62fd77cd${_scopeId11}>${ssrInterpolate(unref(errorMessage))}</div>`);
                                                                      } else {
                                                                        return [
                                                                          createVNode(VCol, { cols: "auto" }, {
                                                                            default: withCtx(() => [
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(user).phonenumber,
                                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                                class: "mb-4",
                                                                                "prepend-inner-icon": "mdi-phone",
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("phone"),
                                                                                variant: "outlined",
                                                                                "single-line": "",
                                                                                "hide-details": "",
                                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                                type: "tel"
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(user).password,
                                                                                "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "single-line": "",
                                                                                "hide-details": "",
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                            ]),
                                                                            _: 1
                                                                          }),
                                                                          createVNode("div", { class: "text-center" }, [
                                                                            createVNode(VBtn, {
                                                                              type: "submit",
                                                                              color: "#0F9D58",
                                                                              class: "mb-4 button-menu",
                                                                              "min-width": "200px"
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                              ]),
                                                                              _: 1
                                                                            })
                                                                          ]),
                                                                          createVNode("div", {
                                                                            onClick: ($event) => handleTabClick(2),
                                                                            class: "text-body-2 font-weight-regular",
                                                                            style: { "cursor": "pointer" }
                                                                          }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                        ];
                                                                      }
                                                                    }),
                                                                    _: 2
                                                                  }, _parent11, _scopeId10));
                                                                } else {
                                                                  return [
                                                                    createVNode(VForm, {
                                                                      modelValue: unref(valid),
                                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                      onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                      ref: "form",
                                                                      "lazy-validation": ""
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VCol, { cols: "auto" }, {
                                                                          default: withCtx(() => [
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(user).phonenumber,
                                                                              "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                              class: "mb-4",
                                                                              "prepend-inner-icon": "mdi-phone",
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("phone"),
                                                                              variant: "outlined",
                                                                              "single-line": "",
                                                                              "hide-details": "",
                                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                                              type: "tel"
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(user).password,
                                                                              "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                              type: unref(visible) ? "text" : "password",
                                                                              rules: [rules.passwordRequired, rules.min],
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("password"),
                                                                              "single-line": "",
                                                                              "hide-details": "",
                                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                                              variant: "outlined",
                                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                          ]),
                                                                          _: 1
                                                                        }),
                                                                        createVNode("div", { class: "text-center" }, [
                                                                          createVNode(VBtn, {
                                                                            type: "submit",
                                                                            color: "#0F9D58",
                                                                            class: "mb-4 button-menu",
                                                                            "min-width": "200px"
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                            ]),
                                                                            _: 1
                                                                          })
                                                                        ]),
                                                                        createVNode("div", {
                                                                          onClick: ($event) => handleTabClick(2),
                                                                          class: "text-body-2 font-weight-regular",
                                                                          style: { "cursor": "pointer" }
                                                                        }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                      ]),
                                                                      _: 1
                                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                  ];
                                                                }
                                                              }),
                                                              _: 2
                                                            }, _parent10, _scopeId9));
                                                          } else {
                                                            return [
                                                              createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                              createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VCol, { cols: "auto" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(user).phonenumber,
                                                                            "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                            class: "mb-4",
                                                                            "prepend-inner-icon": "mdi-phone",
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("phone"),
                                                                            variant: "outlined",
                                                                            "single-line": "",
                                                                            "hide-details": "",
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            type: "tel"
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(user).password,
                                                                            "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                            type: unref(visible) ? "text" : "password",
                                                                            rules: [rules.passwordRequired, rules.min],
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("password"),
                                                                            "single-line": "",
                                                                            "hide-details": "",
                                                                            "prepend-inner-icon": "mdi-lock-outline",
                                                                            variant: "outlined",
                                                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "200px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        })
                                                                      ]),
                                                                      createVNode("div", {
                                                                        onClick: ($event) => handleTabClick(2),
                                                                        class: "text-body-2 font-weight-regular",
                                                                        style: { "cursor": "pointer" }
                                                                      }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                      createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ];
                                                          }
                                                        }),
                                                        _: 2
                                                      }, _parent9, _scopeId8));
                                                      _push9(ssrRenderComponent(VWindowItem, { value: 1 }, {
                                                        default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<h1 class="mt-4 auth" data-v-62fd77cd${_scopeId9}>${ssrInterpolate(_ctx.$t("reg"))}</h1>`);
                                                            _push10(ssrRenderComponent(VCardText, { class: "my-7" }, {
                                                              default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                if (_push11) {
                                                                  _push11(ssrRenderComponent(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: onRegistrations,
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                      if (_push12) {
                                                                        _push12(ssrRenderComponent(VCol, { cols: "auto" }, {
                                                                          default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                            if (_push13) {
                                                                              _push13(ssrRenderComponent(VTextField, {
                                                                                modelValue: unref(createUser).phone,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                "prepend-inner-icon": "mdi-phone",
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("phone"),
                                                                                variant: "outlined",
                                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                                type: "tel"
                                                                              }, null, _parent13, _scopeId12));
                                                                              _push13(ssrRenderComponent(VTextField, {
                                                                                modelValue: unref(createUser).password1,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, _parent13, _scopeId12));
                                                                              _push13(ssrRenderComponent(VTextField, {
                                                                                modelValue: unref(createUser).password2,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, _parent13, _scopeId12));
                                                                            } else {
                                                                              return [
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(createUser).phone,
                                                                                  "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                  "prepend-inner-icon": "mdi-phone",
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("phone"),
                                                                                  variant: "outlined",
                                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                                  type: "tel"
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(createUser).password1,
                                                                                  "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                  type: unref(visible) ? "text" : "password",
                                                                                  rules: [rules.passwordRequired, rules.min],
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("password"),
                                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                                  variant: "outlined",
                                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                                createVNode(VTextField, {
                                                                                  modelValue: unref(createUser).password2,
                                                                                  "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                  type: unref(visible) ? "text" : "password",
                                                                                  rules: [rules.passwordRequired, rules.min],
                                                                                  density: "compact",
                                                                                  placeholder: _ctx.$t("password"),
                                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                                  variant: "outlined",
                                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                              ];
                                                                            }
                                                                          }),
                                                                          _: 2
                                                                        }, _parent12, _scopeId11));
                                                                        _push12(`<div class="text-center" data-v-62fd77cd${_scopeId11}>`);
                                                                        _push12(ssrRenderComponent(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "300px"
                                                                        }, {
                                                                          default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                            if (_push13) {
                                                                              _push13(`${ssrInterpolate(_ctx.$t("reg"))}`);
                                                                            } else {
                                                                              return [
                                                                                createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                              ];
                                                                            }
                                                                          }),
                                                                          _: 2
                                                                        }, _parent12, _scopeId11));
                                                                        _push12(`<div class="text-red" data-v-62fd77cd${_scopeId11}>${ssrInterpolate(unref(errorStatus))}</div></div>`);
                                                                      } else {
                                                                        return [
                                                                          createVNode(VCol, { cols: "auto" }, {
                                                                            default: withCtx(() => [
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(createUser).phone,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                                "prepend-inner-icon": "mdi-phone",
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("phone"),
                                                                                variant: "outlined",
                                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                                type: "tel"
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(createUser).password1,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                              createVNode(VTextField, {
                                                                                modelValue: unref(createUser).password2,
                                                                                "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                                type: unref(visible) ? "text" : "password",
                                                                                rules: [rules.passwordRequired, rules.min],
                                                                                density: "compact",
                                                                                placeholder: _ctx.$t("password"),
                                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                                variant: "outlined",
                                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                            ]),
                                                                            _: 1
                                                                          }),
                                                                          createVNode("div", { class: "text-center" }, [
                                                                            createVNode(VBtn, {
                                                                              type: "submit",
                                                                              color: "#0F9D58",
                                                                              class: "mb-4 button-menu",
                                                                              "min-width": "300px"
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                              ]),
                                                                              _: 1
                                                                            }),
                                                                            createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                          ])
                                                                        ];
                                                                      }
                                                                    }),
                                                                    _: 2
                                                                  }, _parent11, _scopeId10));
                                                                } else {
                                                                  return [
                                                                    createVNode(VForm, {
                                                                      modelValue: unref(valid),
                                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                      onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                      ref: "form",
                                                                      "lazy-validation": ""
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VCol, { cols: "auto" }, {
                                                                          default: withCtx(() => [
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(createUser).phone,
                                                                              "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                              "prepend-inner-icon": "mdi-phone",
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("phone"),
                                                                              variant: "outlined",
                                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                                              type: "tel"
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(createUser).password1,
                                                                              "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                              type: unref(visible) ? "text" : "password",
                                                                              rules: [rules.passwordRequired, rules.min],
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("password"),
                                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                                              variant: "outlined",
                                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                            createVNode(VTextField, {
                                                                              modelValue: unref(createUser).password2,
                                                                              "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                              type: unref(visible) ? "text" : "password",
                                                                              rules: [rules.passwordRequired, rules.min],
                                                                              density: "compact",
                                                                              placeholder: _ctx.$t("password"),
                                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                                              variant: "outlined",
                                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                          ]),
                                                                          _: 1
                                                                        }),
                                                                        createVNode("div", { class: "text-center" }, [
                                                                          createVNode(VBtn, {
                                                                            type: "submit",
                                                                            color: "#0F9D58",
                                                                            class: "mb-4 button-menu",
                                                                            "min-width": "300px"
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                            ]),
                                                                            _: 1
                                                                          }),
                                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                        ])
                                                                      ]),
                                                                      _: 1
                                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                  ];
                                                                }
                                                              }),
                                                              _: 2
                                                            }, _parent10, _scopeId9));
                                                          } else {
                                                            return [
                                                              createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                              createVNode(VCardText, { class: "my-7" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VCol, { cols: "auto" }, {
                                                                        default: withCtx(() => [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).phone,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                            "prepend-inner-icon": "mdi-phone",
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("phone"),
                                                                            variant: "outlined",
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            type: "tel"
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).password1,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                            type: unref(visible) ? "text" : "password",
                                                                            rules: [rules.passwordRequired, rules.min],
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("password"),
                                                                            "prepend-inner-icon": "mdi-lock-outline",
                                                                            variant: "outlined",
                                                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(createUser).password2,
                                                                            "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                            type: unref(visible) ? "text" : "password",
                                                                            rules: [rules.passwordRequired, rules.min],
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("password"),
                                                                            "prepend-inner-icon": "mdi-lock-outline",
                                                                            variant: "outlined",
                                                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "300px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        }),
                                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                      ])
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ];
                                                          }
                                                        }),
                                                        _: 2
                                                      }, _parent9, _scopeId8));
                                                      _push9(ssrRenderComponent(VWindowItem, { value: 2 }, {
                                                        default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`<h1 class="mt-4 auth" data-v-62fd77cd${_scopeId9}>${ssrInterpolate(_ctx.$t("restore"))}</h1>`);
                                                            _push10(ssrRenderComponent(VCardText, { class: "my-7" }, {
                                                              default: withCtx((_9, _push11, _parent11, _scopeId10) => {
                                                                if (_push11) {
                                                                  _push11(ssrRenderComponent(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: Reset_Password,
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx((_10, _push12, _parent12, _scopeId11) => {
                                                                      if (_push12) {
                                                                        _push12(ssrRenderComponent(VTextField, {
                                                                          modelValue: unref(user).phonenumber,
                                                                          "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                          "prepend-inner-icon": "mdi-phone",
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("phone"),
                                                                          variant: "outlined",
                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                          type: "tel"
                                                                        }, null, _parent12, _scopeId11));
                                                                        _push12(`<div class="text-center" data-v-62fd77cd${_scopeId11}>`);
                                                                        _push12(ssrRenderComponent(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "200px"
                                                                        }, {
                                                                          default: withCtx((_11, _push13, _parent13, _scopeId12) => {
                                                                            if (_push13) {
                                                                              _push13(`${ssrInterpolate(_ctx.$t("send"))}`);
                                                                            } else {
                                                                              return [
                                                                                createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                              ];
                                                                            }
                                                                          }),
                                                                          _: 2
                                                                        }, _parent12, _scopeId11));
                                                                        _push12(`</div><div class="text-red" data-v-62fd77cd${_scopeId11}>${ssrInterpolate(unref(errorMessage))}</div>`);
                                                                      } else {
                                                                        return [
                                                                          createVNode(VTextField, {
                                                                            modelValue: unref(user).phonenumber,
                                                                            "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                            "prepend-inner-icon": "mdi-phone",
                                                                            density: "compact",
                                                                            placeholder: _ctx.$t("phone"),
                                                                            variant: "outlined",
                                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                                            type: "tel"
                                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                          createVNode("div", { class: "text-center" }, [
                                                                            createVNode(VBtn, {
                                                                              type: "submit",
                                                                              color: "#0F9D58",
                                                                              class: "mb-4 button-menu",
                                                                              "min-width": "200px"
                                                                            }, {
                                                                              default: withCtx(() => [
                                                                                createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                              ]),
                                                                              _: 1
                                                                            })
                                                                          ]),
                                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                        ];
                                                                      }
                                                                    }),
                                                                    _: 2
                                                                  }, _parent11, _scopeId10));
                                                                } else {
                                                                  return [
                                                                    createVNode(VForm, {
                                                                      modelValue: unref(valid),
                                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                      onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                                      ref: "form",
                                                                      "lazy-validation": ""
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(user).phonenumber,
                                                                          "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                          "prepend-inner-icon": "mdi-phone",
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("phone"),
                                                                          variant: "outlined",
                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                          type: "tel"
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                        createVNode("div", { class: "text-center" }, [
                                                                          createVNode(VBtn, {
                                                                            type: "submit",
                                                                            color: "#0F9D58",
                                                                            class: "mb-4 button-menu",
                                                                            "min-width": "200px"
                                                                          }, {
                                                                            default: withCtx(() => [
                                                                              createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                            ]),
                                                                            _: 1
                                                                          })
                                                                        ]),
                                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                      ]),
                                                                      _: 1
                                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                  ];
                                                                }
                                                              }),
                                                              _: 2
                                                            }, _parent10, _scopeId9));
                                                          } else {
                                                            return [
                                                              createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                              createVNode(VCardText, { class: "my-7" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VForm, {
                                                                    modelValue: unref(valid),
                                                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                    onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                                    ref: "form",
                                                                    "lazy-validation": ""
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).phonenumber,
                                                                        "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                        "prepend-inner-icon": "mdi-phone",
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("phone"),
                                                                        variant: "outlined",
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        type: "tel"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                      createVNode("div", { class: "text-center" }, [
                                                                        createVNode(VBtn, {
                                                                          type: "submit",
                                                                          color: "#0F9D58",
                                                                          class: "mb-4 button-menu",
                                                                          "min-width": "200px"
                                                                        }, {
                                                                          default: withCtx(() => [
                                                                            createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                          ]),
                                                                          _: 1
                                                                        })
                                                                      ]),
                                                                      createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                    ]),
                                                                    _: 1
                                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                                ]),
                                                                _: 1
                                                              })
                                                            ];
                                                          }
                                                        }),
                                                        _: 2
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      return [
                                                        createVNode(VWindowItem, { value: 0 }, {
                                                          default: withCtx(() => [
                                                            createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                            createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VForm, {
                                                                  modelValue: unref(valid),
                                                                  "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                  onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                  ref: "form",
                                                                  "lazy-validation": ""
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VCol, { cols: "auto" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(user).phonenumber,
                                                                          "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                          class: "mb-4",
                                                                          "prepend-inner-icon": "mdi-phone",
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("phone"),
                                                                          variant: "outlined",
                                                                          "single-line": "",
                                                                          "hide-details": "",
                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                          type: "tel"
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(user).password,
                                                                          "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                          type: unref(visible) ? "text" : "password",
                                                                          rules: [rules.passwordRequired, rules.min],
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("password"),
                                                                          "single-line": "",
                                                                          "hide-details": "",
                                                                          "prepend-inner-icon": "mdi-lock-outline",
                                                                          variant: "outlined",
                                                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode("div", { class: "text-center" }, [
                                                                      createVNode(VBtn, {
                                                                        type: "submit",
                                                                        color: "#0F9D58",
                                                                        class: "mb-4 button-menu",
                                                                        "min-width": "200px"
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ]),
                                                                    createVNode("div", {
                                                                      onClick: ($event) => handleTabClick(2),
                                                                      class: "text-body-2 font-weight-regular",
                                                                      style: { "cursor": "pointer" }
                                                                    }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                    createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(VWindowItem, { value: 1 }, {
                                                          default: withCtx(() => [
                                                            createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                            createVNode(VCardText, { class: "my-7" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VForm, {
                                                                  modelValue: unref(valid),
                                                                  "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                  onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                  ref: "form",
                                                                  "lazy-validation": ""
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VCol, { cols: "auto" }, {
                                                                      default: withCtx(() => [
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(createUser).phone,
                                                                          "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                          "prepend-inner-icon": "mdi-phone",
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("phone"),
                                                                          variant: "outlined",
                                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                                          type: "tel"
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(createUser).password1,
                                                                          "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                          type: unref(visible) ? "text" : "password",
                                                                          rules: [rules.passwordRequired, rules.min],
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("password"),
                                                                          "prepend-inner-icon": "mdi-lock-outline",
                                                                          variant: "outlined",
                                                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                        createVNode(VTextField, {
                                                                          modelValue: unref(createUser).password2,
                                                                          "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                          type: unref(visible) ? "text" : "password",
                                                                          rules: [rules.passwordRequired, rules.min],
                                                                          density: "compact",
                                                                          placeholder: _ctx.$t("password"),
                                                                          "prepend-inner-icon": "mdi-lock-outline",
                                                                          variant: "outlined",
                                                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode("div", { class: "text-center" }, [
                                                                      createVNode(VBtn, {
                                                                        type: "submit",
                                                                        color: "#0F9D58",
                                                                        class: "mb-4 button-menu",
                                                                        "min-width": "300px"
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                        ]),
                                                                        _: 1
                                                                      }),
                                                                      createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                    ])
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode(VWindowItem, { value: 2 }, {
                                                          default: withCtx(() => [
                                                            createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                            createVNode(VCardText, { class: "my-7" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VForm, {
                                                                  modelValue: unref(valid),
                                                                  "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                  onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                                  ref: "form",
                                                                  "lazy-validation": ""
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(user).phonenumber,
                                                                      "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                      "prepend-inner-icon": "mdi-phone",
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("phone"),
                                                                      variant: "outlined",
                                                                      rules: [rules.phoneRequired, rules.phonenumber],
                                                                      type: "tel"
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                    createVNode("div", { class: "text-center" }, [
                                                                      createVNode(VBtn, {
                                                                        type: "submit",
                                                                        color: "#0F9D58",
                                                                        class: "mb-4 button-menu",
                                                                        "min-width": "200px"
                                                                      }, {
                                                                        default: withCtx(() => [
                                                                          createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                        ]),
                                                                        _: 1
                                                                      })
                                                                    ]),
                                                                    createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                  ]),
                                                                  _: 1
                                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          _: 1
                                                        })
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                              } else {
                                                return [
                                                  createVNode(VTabs, {
                                                    modelValue: unref(tab),
                                                    "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null,
                                                    "active-class": "white",
                                                    height: "40",
                                                    "fixed-tabs": "",
                                                    "hide-slider": ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(VBtn, {
                                                        color: "#0F9D58",
                                                        "min-width": "100",
                                                        class: "button-menu",
                                                        onClick: ($event) => handleTabClick(0),
                                                        flat: ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                        ]),
                                                        _: 1
                                                      }, 8, ["onClick"]),
                                                      createVNode(VBtn, {
                                                        color: "#0F9D58",
                                                        "min-width": "100",
                                                        class: "button-menu",
                                                        onClick: ($event) => handleTabClick(1),
                                                        flat: ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                        ]),
                                                        _: 1
                                                      }, 8, ["onClick"])
                                                    ]),
                                                    _: 1
                                                  }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                  createVNode(VWindow, {
                                                    modelValue: unref(tab),
                                                    "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(VWindowItem, { value: 0 }, {
                                                        default: withCtx(() => [
                                                          createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                          createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VForm, {
                                                                modelValue: unref(valid),
                                                                "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                onSubmit: withModifiers(onLogin, ["prevent"]),
                                                                ref: "form",
                                                                "lazy-validation": ""
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VCol, { cols: "auto" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).phonenumber,
                                                                        "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                        class: "mb-4",
                                                                        "prepend-inner-icon": "mdi-phone",
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("phone"),
                                                                        variant: "outlined",
                                                                        "single-line": "",
                                                                        "hide-details": "",
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        type: "tel"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(user).password,
                                                                        "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                        type: unref(visible) ? "text" : "password",
                                                                        rules: [rules.passwordRequired, rules.min],
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("password"),
                                                                        "single-line": "",
                                                                        "hide-details": "",
                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                        variant: "outlined",
                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode("div", { class: "text-center" }, [
                                                                    createVNode(VBtn, {
                                                                      type: "submit",
                                                                      color: "#0F9D58",
                                                                      class: "mb-4 button-menu",
                                                                      "min-width": "200px"
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  createVNode("div", {
                                                                    onClick: ($event) => handleTabClick(2),
                                                                    class: "text-body-2 font-weight-regular",
                                                                    style: { "cursor": "pointer" }
                                                                  }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                ]),
                                                                _: 1
                                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(VWindowItem, { value: 1 }, {
                                                        default: withCtx(() => [
                                                          createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                          createVNode(VCardText, { class: "my-7" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VForm, {
                                                                modelValue: unref(valid),
                                                                "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                                ref: "form",
                                                                "lazy-validation": ""
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VCol, { cols: "auto" }, {
                                                                    default: withCtx(() => [
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(createUser).phone,
                                                                        "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                        "prepend-inner-icon": "mdi-phone",
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("phone"),
                                                                        variant: "outlined",
                                                                        rules: [rules.phoneRequired, rules.phonenumber],
                                                                        type: "tel"
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(createUser).password1,
                                                                        "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                        type: unref(visible) ? "text" : "password",
                                                                        rules: [rules.passwordRequired, rules.min],
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("password"),
                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                        variant: "outlined",
                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                      createVNode(VTextField, {
                                                                        modelValue: unref(createUser).password2,
                                                                        "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                        type: unref(visible) ? "text" : "password",
                                                                        rules: [rules.passwordRequired, rules.min],
                                                                        density: "compact",
                                                                        placeholder: _ctx.$t("password"),
                                                                        "prepend-inner-icon": "mdi-lock-outline",
                                                                        variant: "outlined",
                                                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode("div", { class: "text-center" }, [
                                                                    createVNode(VBtn, {
                                                                      type: "submit",
                                                                      color: "#0F9D58",
                                                                      class: "mb-4 button-menu",
                                                                      "min-width": "300px"
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                      ]),
                                                                      _: 1
                                                                    }),
                                                                    createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                  ])
                                                                ]),
                                                                _: 1
                                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      }),
                                                      createVNode(VWindowItem, { value: 2 }, {
                                                        default: withCtx(() => [
                                                          createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                          createVNode(VCardText, { class: "my-7" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VForm, {
                                                                modelValue: unref(valid),
                                                                "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                                onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                                ref: "form",
                                                                "lazy-validation": ""
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(user).phonenumber,
                                                                    "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                    "prepend-inner-icon": "mdi-phone",
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("phone"),
                                                                    variant: "outlined",
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    type: "tel"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                  createVNode("div", { class: "text-center" }, [
                                                                    createVNode(VBtn, {
                                                                      type: "submit",
                                                                      color: "#0F9D58",
                                                                      class: "mb-4 button-menu",
                                                                      "min-width": "200px"
                                                                    }, {
                                                                      default: withCtx(() => [
                                                                        createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                      ]),
                                                                      _: 1
                                                                    })
                                                                  ]),
                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                                ]),
                                                                _: 1
                                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(VCard, {
                                              flat: "",
                                              outlined: "",
                                              "min-width": "300",
                                              class: "mx-auto"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(VTabs, {
                                                  modelValue: unref(tab),
                                                  "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null,
                                                  "active-class": "white",
                                                  height: "40",
                                                  "fixed-tabs": "",
                                                  "hide-slider": ""
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(VBtn, {
                                                      color: "#0F9D58",
                                                      "min-width": "100",
                                                      class: "button-menu",
                                                      onClick: ($event) => handleTabClick(0),
                                                      flat: ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onClick"]),
                                                    createVNode(VBtn, {
                                                      color: "#0F9D58",
                                                      "min-width": "100",
                                                      class: "button-menu",
                                                      onClick: ($event) => handleTabClick(1),
                                                      flat: ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onClick"])
                                                  ]),
                                                  _: 1
                                                }, 8, ["modelValue", "onUpdate:modelValue"]),
                                                createVNode(VWindow, {
                                                  modelValue: unref(tab),
                                                  "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(VWindowItem, { value: 0 }, {
                                                      default: withCtx(() => [
                                                        createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                        createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VForm, {
                                                              modelValue: unref(valid),
                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                              onSubmit: withModifiers(onLogin, ["prevent"]),
                                                              ref: "form",
                                                              "lazy-validation": ""
                                                            }, {
                                                              default: withCtx(() => [
                                                                createVNode(VCol, { cols: "auto" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(user).phonenumber,
                                                                      "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                      class: "mb-4",
                                                                      "prepend-inner-icon": "mdi-phone",
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("phone"),
                                                                      variant: "outlined",
                                                                      "single-line": "",
                                                                      "hide-details": "",
                                                                      rules: [rules.phoneRequired, rules.phonenumber],
                                                                      type: "tel"
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(user).password,
                                                                      "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                      "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                      type: unref(visible) ? "text" : "password",
                                                                      rules: [rules.passwordRequired, rules.min],
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("password"),
                                                                      "single-line": "",
                                                                      "hide-details": "",
                                                                      "prepend-inner-icon": "mdi-lock-outline",
                                                                      variant: "outlined",
                                                                      "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode("div", { class: "text-center" }, [
                                                                  createVNode(VBtn, {
                                                                    type: "submit",
                                                                    color: "#0F9D58",
                                                                    class: "mb-4 button-menu",
                                                                    "min-width": "200px"
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                createVNode("div", {
                                                                  onClick: ($event) => handleTabClick(2),
                                                                  class: "text-body-2 font-weight-regular",
                                                                  style: { "cursor": "pointer" }
                                                                }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                              ]),
                                                              _: 1
                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(VWindowItem, { value: 1 }, {
                                                      default: withCtx(() => [
                                                        createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                        createVNode(VCardText, { class: "my-7" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VForm, {
                                                              modelValue: unref(valid),
                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                              onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                              ref: "form",
                                                              "lazy-validation": ""
                                                            }, {
                                                              default: withCtx(() => [
                                                                createVNode(VCol, { cols: "auto" }, {
                                                                  default: withCtx(() => [
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(createUser).phone,
                                                                      "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                      "prepend-inner-icon": "mdi-phone",
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("phone"),
                                                                      variant: "outlined",
                                                                      rules: [rules.phoneRequired, rules.phonenumber],
                                                                      type: "tel"
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(createUser).password1,
                                                                      "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                      "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                      type: unref(visible) ? "text" : "password",
                                                                      rules: [rules.passwordRequired, rules.min],
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("password"),
                                                                      "prepend-inner-icon": "mdi-lock-outline",
                                                                      variant: "outlined",
                                                                      "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                    createVNode(VTextField, {
                                                                      modelValue: unref(createUser).password2,
                                                                      "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                      "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                      type: unref(visible) ? "text" : "password",
                                                                      rules: [rules.passwordRequired, rules.min],
                                                                      density: "compact",
                                                                      placeholder: _ctx.$t("password"),
                                                                      "prepend-inner-icon": "mdi-lock-outline",
                                                                      variant: "outlined",
                                                                      "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                    }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode("div", { class: "text-center" }, [
                                                                  createVNode(VBtn, {
                                                                    type: "submit",
                                                                    color: "#0F9D58",
                                                                    class: "mb-4 button-menu",
                                                                    "min-width": "300px"
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                    ]),
                                                                    _: 1
                                                                  }),
                                                                  createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                                ])
                                                              ]),
                                                              _: 1
                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    }),
                                                    createVNode(VWindowItem, { value: 2 }, {
                                                      default: withCtx(() => [
                                                        createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                        createVNode(VCardText, { class: "my-7" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VForm, {
                                                              modelValue: unref(valid),
                                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                              onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                              ref: "form",
                                                              "lazy-validation": ""
                                                            }, {
                                                              default: withCtx(() => [
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(user).phonenumber,
                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                  "prepend-inner-icon": "mdi-phone",
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("phone"),
                                                                  variant: "outlined",
                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                  type: "tel"
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                createVNode("div", { class: "text-center" }, [
                                                                  createVNode(VBtn, {
                                                                    type: "submit",
                                                                    color: "#0F9D58",
                                                                    class: "mb-4 button-menu",
                                                                    "min-width": "200px"
                                                                  }, {
                                                                    default: withCtx(() => [
                                                                      createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                    ]),
                                                                    _: 1
                                                                  })
                                                                ]),
                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                              ]),
                                                              _: 1
                                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                                          ]),
                                                          _: 1
                                                        })
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }, 8, ["modelValue", "onUpdate:modelValue"])
                                              ]),
                                              _: 1
                                            })
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(VCol, { cols: "12" }, {
                                        default: withCtx(() => [
                                          createVNode(VCard, {
                                            flat: "",
                                            outlined: "",
                                            "min-width": "300",
                                            class: "mx-auto"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(VTabs, {
                                                modelValue: unref(tab),
                                                "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null,
                                                "active-class": "white",
                                                height: "40",
                                                "fixed-tabs": "",
                                                "hide-slider": ""
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VBtn, {
                                                    color: "#0F9D58",
                                                    "min-width": "100",
                                                    class: "button-menu",
                                                    onClick: ($event) => handleTabClick(0),
                                                    flat: ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"]),
                                                  createVNode(VBtn, {
                                                    color: "#0F9D58",
                                                    "min-width": "100",
                                                    class: "button-menu",
                                                    onClick: ($event) => handleTabClick(1),
                                                    flat: ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"])
                                                ]),
                                                _: 1
                                              }, 8, ["modelValue", "onUpdate:modelValue"]),
                                              createVNode(VWindow, {
                                                modelValue: unref(tab),
                                                "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VWindowItem, { value: 0 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                      createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(onLogin, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VCol, { cols: "auto" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(user).phonenumber,
                                                                    "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                    class: "mb-4",
                                                                    "prepend-inner-icon": "mdi-phone",
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("phone"),
                                                                    variant: "outlined",
                                                                    "single-line": "",
                                                                    "hide-details": "",
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    type: "tel"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(user).password,
                                                                    "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "single-line": "",
                                                                    "hide-details": "",
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "200px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              createVNode("div", {
                                                                onClick: ($event) => handleTabClick(2),
                                                                class: "text-body-2 font-weight-regular",
                                                                style: { "cursor": "pointer" }
                                                              }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(VWindowItem, { value: 1 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                      createVNode(VCardText, { class: "my-7" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VCol, { cols: "auto" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).phone,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                    "prepend-inner-icon": "mdi-phone",
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("phone"),
                                                                    variant: "outlined",
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    type: "tel"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).password1,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).password2,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "300px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                              ])
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(VWindowItem, { value: 2 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                      createVNode(VCardText, { class: "my-7" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(user).phonenumber,
                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                "prepend-inner-icon": "mdi-phone",
                                                                density: "compact",
                                                                placeholder: _ctx.$t("phone"),
                                                                variant: "outlined",
                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                type: "tel"
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "200px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                              _push5(`</div>`);
                            } else {
                              return [
                                createVNode("div", { class: "grey lighten-4" }, [
                                  createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                    default: withCtx(() => [
                                      createVNode(VCol, { cols: "12" }, {
                                        default: withCtx(() => [
                                          createVNode(VCard, {
                                            flat: "",
                                            outlined: "",
                                            "min-width": "300",
                                            class: "mx-auto"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(VTabs, {
                                                modelValue: unref(tab),
                                                "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null,
                                                "active-class": "white",
                                                height: "40",
                                                "fixed-tabs": "",
                                                "hide-slider": ""
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VBtn, {
                                                    color: "#0F9D58",
                                                    "min-width": "100",
                                                    class: "button-menu",
                                                    onClick: ($event) => handleTabClick(0),
                                                    flat: ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"]),
                                                  createVNode(VBtn, {
                                                    color: "#0F9D58",
                                                    "min-width": "100",
                                                    class: "button-menu",
                                                    onClick: ($event) => handleTabClick(1),
                                                    flat: ""
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"])
                                                ]),
                                                _: 1
                                              }, 8, ["modelValue", "onUpdate:modelValue"]),
                                              createVNode(VWindow, {
                                                modelValue: unref(tab),
                                                "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(VWindowItem, { value: 0 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                      createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(onLogin, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VCol, { cols: "auto" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(user).phonenumber,
                                                                    "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                    class: "mb-4",
                                                                    "prepend-inner-icon": "mdi-phone",
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("phone"),
                                                                    variant: "outlined",
                                                                    "single-line": "",
                                                                    "hide-details": "",
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    type: "tel"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(user).password,
                                                                    "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "single-line": "",
                                                                    "hide-details": "",
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "200px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              createVNode("div", {
                                                                onClick: ($event) => handleTabClick(2),
                                                                class: "text-body-2 font-weight-regular",
                                                                style: { "cursor": "pointer" }
                                                              }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(VWindowItem, { value: 1 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                      createVNode(VCardText, { class: "my-7" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VCol, { cols: "auto" }, {
                                                                default: withCtx(() => [
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).phone,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                    "prepend-inner-icon": "mdi-phone",
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("phone"),
                                                                    variant: "outlined",
                                                                    rules: [rules.phoneRequired, rules.phonenumber],
                                                                    type: "tel"
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).password1,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                  createVNode(VTextField, {
                                                                    modelValue: unref(createUser).password2,
                                                                    "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                    type: unref(visible) ? "text" : "password",
                                                                    rules: [rules.passwordRequired, rules.min],
                                                                    density: "compact",
                                                                    placeholder: _ctx.$t("password"),
                                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                                    variant: "outlined",
                                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "300px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                  ]),
                                                                  _: 1
                                                                }),
                                                                createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                              ])
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  }),
                                                  createVNode(VWindowItem, { value: 2 }, {
                                                    default: withCtx(() => [
                                                      createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                      createVNode(VCardText, { class: "my-7" }, {
                                                        default: withCtx(() => [
                                                          createVNode(VForm, {
                                                            modelValue: unref(valid),
                                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                            onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                            ref: "form",
                                                            "lazy-validation": ""
                                                          }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(user).phonenumber,
                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                "prepend-inner-icon": "mdi-phone",
                                                                density: "compact",
                                                                placeholder: _ctx.$t("phone"),
                                                                variant: "outlined",
                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                type: "tel"
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                              createVNode("div", { class: "text-center" }, [
                                                                createVNode(VBtn, {
                                                                  type: "submit",
                                                                  color: "#0F9D58",
                                                                  class: "mb-4 button-menu",
                                                                  "min-width": "200px"
                                                                }, {
                                                                  default: withCtx(() => [
                                                                    createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                  ]),
                                                                  _: 1
                                                                })
                                                              ]),
                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                            ]),
                                                            _: 1
                                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }, 8, ["modelValue", "onUpdate:modelValue"])
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(VStepperWindowItem, {
                          value: unref(token) ? 2 : null
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(VCard, { "min-width": "300" }, {
                                default: withCtx((_4, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(VCardTitle, { class: "text-center my-3" }, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`${ssrInterpolate(_ctx.$t("profile"))}`);
                                        } else {
                                          return [
                                            createTextVNode(toDisplayString(_ctx.$t("profile")), 1)
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(VCardText, null, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<div class="d-flex align-center justify-center" data-v-62fd77cd${_scopeId6}><span class="text-h6" data-v-62fd77cd${_scopeId6}>${ssrInterpolate(unref(store).user.phone_number ? unref(store).user.phone_number : "\u041F\u0443\u0441\u0442\u043E\u0439")}</span>`);
                                          _push7(ssrRenderComponent(VBtn, {
                                            onClick: unref(logout),
                                            class: "mx-3 close-button",
                                            width: "35px",
                                            height: "35px",
                                            color: "#0F9D58",
                                            icon: "mdi-logout-variant"
                                          }, null, _parent7, _scopeId6));
                                          _push7(`</div>`);
                                        } else {
                                          return [
                                            createVNode("div", { class: "d-flex align-center justify-center" }, [
                                              createVNode("span", { class: "text-h6" }, toDisplayString(unref(store).user.phone_number ? unref(store).user.phone_number : "\u041F\u0443\u0441\u0442\u043E\u0439"), 1),
                                              createVNode(VBtn, {
                                                onClick: unref(logout),
                                                class: "mx-3 close-button",
                                                width: "35px",
                                                height: "35px",
                                                color: "#0F9D58",
                                                icon: "mdi-logout-variant"
                                              }, null, 8, ["onClick"])
                                            ])
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(VCardText, null, {
                                      default: withCtx((_5, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<h5 class="text-center my-3" data-v-62fd77cd${_scopeId6}>${ssrInterpolate(_ctx.$t("change_pass"))}</h5>`);
                                          _push7(ssrRenderComponent(VForm, {
                                            modelValue: unref(valid),
                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                            onSubmit: Change_password,
                                            ref: "form",
                                            "lazy-validation": ""
                                          }, {
                                            default: withCtx((_6, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(ssrRenderComponent(VTextField, {
                                                  modelValue: unref(Update).old_password,
                                                  "onUpdate:modelValue": ($event) => unref(Update).old_password = $event,
                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                  type: unref(visible) ? "text" : "password",
                                                  rules: [rules.passwordRequired, rules.min],
                                                  density: "compact",
                                                  placeholder: _ctx.$t("password"),
                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                  variant: "outlined",
                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                }, null, _parent8, _scopeId7));
                                                _push8(ssrRenderComponent(VTextField, {
                                                  modelValue: unref(Update).new_password,
                                                  "onUpdate:modelValue": ($event) => unref(Update).new_password = $event,
                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                  type: unref(visible) ? "text" : "password",
                                                  rules: [rules.passwordRequired, rules.min],
                                                  density: "compact",
                                                  placeholder: _ctx.$t("password"),
                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                  variant: "outlined",
                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                }, null, _parent8, _scopeId7));
                                                _push8(ssrRenderComponent(VCardActions, { class: "text-end" }, {
                                                  default: withCtx((_7, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(ssrRenderComponent(VBtn, {
                                                        variant: "text",
                                                        color: "#0F9D58",
                                                        onClick: ($event) => menu.value = false
                                                      }, {
                                                        default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`${ssrInterpolate(_ctx.$t("cancel"))}`);
                                                          } else {
                                                            return [
                                                              createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                                            ];
                                                          }
                                                        }),
                                                        _: 2
                                                      }, _parent9, _scopeId8));
                                                      _push9(ssrRenderComponent(VBtn, {
                                                        variant: "text",
                                                        color: "#0F9D58",
                                                        type: "submit"
                                                      }, {
                                                        default: withCtx((_8, _push10, _parent10, _scopeId9) => {
                                                          if (_push10) {
                                                            _push10(`${ssrInterpolate(_ctx.$t("reset"))}`);
                                                          } else {
                                                            return [
                                                              createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                                            ];
                                                          }
                                                        }),
                                                        _: 2
                                                      }, _parent9, _scopeId8));
                                                    } else {
                                                      return [
                                                        createVNode(VBtn, {
                                                          variant: "text",
                                                          color: "#0F9D58",
                                                          onClick: ($event) => menu.value = false
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                                          ]),
                                                          _: 1
                                                        }, 8, ["onClick"]),
                                                        createVNode(VBtn, {
                                                          variant: "text",
                                                          color: "#0F9D58",
                                                          type: "submit"
                                                        }, {
                                                          default: withCtx(() => [
                                                            createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                                          ]),
                                                          _: 1
                                                        })
                                                      ];
                                                    }
                                                  }),
                                                  _: 2
                                                }, _parent8, _scopeId7));
                                              } else {
                                                return [
                                                  createVNode(VTextField, {
                                                    modelValue: unref(Update).old_password,
                                                    "onUpdate:modelValue": ($event) => unref(Update).old_password = $event,
                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                    type: unref(visible) ? "text" : "password",
                                                    rules: [rules.passwordRequired, rules.min],
                                                    density: "compact",
                                                    placeholder: _ctx.$t("password"),
                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                    variant: "outlined",
                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                  createVNode(VTextField, {
                                                    modelValue: unref(Update).new_password,
                                                    "onUpdate:modelValue": ($event) => unref(Update).new_password = $event,
                                                    "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                    type: unref(visible) ? "text" : "password",
                                                    rules: [rules.passwordRequired, rules.min],
                                                    density: "compact",
                                                    placeholder: _ctx.$t("password"),
                                                    "prepend-inner-icon": "mdi-lock-outline",
                                                    variant: "outlined",
                                                    "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                  createVNode(VCardActions, { class: "text-end" }, {
                                                    default: withCtx(() => [
                                                      createVNode(VBtn, {
                                                        variant: "text",
                                                        color: "#0F9D58",
                                                        onClick: ($event) => menu.value = false
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                                        ]),
                                                        _: 1
                                                      }, 8, ["onClick"]),
                                                      createVNode(VBtn, {
                                                        variant: "text",
                                                        color: "#0F9D58",
                                                        type: "submit"
                                                      }, {
                                                        default: withCtx(() => [
                                                          createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                                        ]),
                                                        _: 1
                                                      })
                                                    ]),
                                                    _: 1
                                                  })
                                                ];
                                              }
                                            }),
                                            _: 2
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode("h5", { class: "text-center my-3" }, toDisplayString(_ctx.$t("change_pass")), 1),
                                            createVNode(VForm, {
                                              modelValue: unref(valid),
                                              "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                              onSubmit: withModifiers(Change_password, ["prevent"]),
                                              ref: "form",
                                              "lazy-validation": ""
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(VTextField, {
                                                  modelValue: unref(Update).old_password,
                                                  "onUpdate:modelValue": ($event) => unref(Update).old_password = $event,
                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                  type: unref(visible) ? "text" : "password",
                                                  rules: [rules.passwordRequired, rules.min],
                                                  density: "compact",
                                                  placeholder: _ctx.$t("password"),
                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                  variant: "outlined",
                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                createVNode(VTextField, {
                                                  modelValue: unref(Update).new_password,
                                                  "onUpdate:modelValue": ($event) => unref(Update).new_password = $event,
                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                  type: unref(visible) ? "text" : "password",
                                                  rules: [rules.passwordRequired, rules.min],
                                                  density: "compact",
                                                  placeholder: _ctx.$t("password"),
                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                  variant: "outlined",
                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                createVNode(VCardActions, { class: "text-end" }, {
                                                  default: withCtx(() => [
                                                    createVNode(VBtn, {
                                                      variant: "text",
                                                      color: "#0F9D58",
                                                      onClick: ($event) => menu.value = false
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                                      ]),
                                                      _: 1
                                                    }, 8, ["onClick"]),
                                                    createVNode(VBtn, {
                                                      variant: "text",
                                                      color: "#0F9D58",
                                                      type: "submit"
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                          ];
                                        }
                                      }),
                                      _: 2
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(VCardTitle, { class: "text-center my-3" }, {
                                        default: withCtx(() => [
                                          createTextVNode(toDisplayString(_ctx.$t("profile")), 1)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(VCardText, null, {
                                        default: withCtx(() => [
                                          createVNode("div", { class: "d-flex align-center justify-center" }, [
                                            createVNode("span", { class: "text-h6" }, toDisplayString(unref(store).user.phone_number ? unref(store).user.phone_number : "\u041F\u0443\u0441\u0442\u043E\u0439"), 1),
                                            createVNode(VBtn, {
                                              onClick: unref(logout),
                                              class: "mx-3 close-button",
                                              width: "35px",
                                              height: "35px",
                                              color: "#0F9D58",
                                              icon: "mdi-logout-variant"
                                            }, null, 8, ["onClick"])
                                          ])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(VCardText, null, {
                                        default: withCtx(() => [
                                          createVNode("h5", { class: "text-center my-3" }, toDisplayString(_ctx.$t("change_pass")), 1),
                                          createVNode(VForm, {
                                            modelValue: unref(valid),
                                            "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                            onSubmit: withModifiers(Change_password, ["prevent"]),
                                            ref: "form",
                                            "lazy-validation": ""
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(VTextField, {
                                                modelValue: unref(Update).old_password,
                                                "onUpdate:modelValue": ($event) => unref(Update).old_password = $event,
                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                type: unref(visible) ? "text" : "password",
                                                rules: [rules.passwordRequired, rules.min],
                                                density: "compact",
                                                placeholder: _ctx.$t("password"),
                                                "prepend-inner-icon": "mdi-lock-outline",
                                                variant: "outlined",
                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                              createVNode(VTextField, {
                                                modelValue: unref(Update).new_password,
                                                "onUpdate:modelValue": ($event) => unref(Update).new_password = $event,
                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                type: unref(visible) ? "text" : "password",
                                                rules: [rules.passwordRequired, rules.min],
                                                density: "compact",
                                                placeholder: _ctx.$t("password"),
                                                "prepend-inner-icon": "mdi-lock-outline",
                                                variant: "outlined",
                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                              createVNode(VCardActions, { class: "text-end" }, {
                                                default: withCtx(() => [
                                                  createVNode(VBtn, {
                                                    variant: "text",
                                                    color: "#0F9D58",
                                                    onClick: ($event) => menu.value = false
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                                    ]),
                                                    _: 1
                                                  }, 8, ["onClick"]),
                                                  createVNode(VBtn, {
                                                    variant: "text",
                                                    color: "#0F9D58",
                                                    type: "submit"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(VCard, { "min-width": "300" }, {
                                  default: withCtx(() => [
                                    createVNode(VCardTitle, { class: "text-center my-3" }, {
                                      default: withCtx(() => [
                                        createTextVNode(toDisplayString(_ctx.$t("profile")), 1)
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(VCardText, null, {
                                      default: withCtx(() => [
                                        createVNode("div", { class: "d-flex align-center justify-center" }, [
                                          createVNode("span", { class: "text-h6" }, toDisplayString(unref(store).user.phone_number ? unref(store).user.phone_number : "\u041F\u0443\u0441\u0442\u043E\u0439"), 1),
                                          createVNode(VBtn, {
                                            onClick: unref(logout),
                                            class: "mx-3 close-button",
                                            width: "35px",
                                            height: "35px",
                                            color: "#0F9D58",
                                            icon: "mdi-logout-variant"
                                          }, null, 8, ["onClick"])
                                        ])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(VCardText, null, {
                                      default: withCtx(() => [
                                        createVNode("h5", { class: "text-center my-3" }, toDisplayString(_ctx.$t("change_pass")), 1),
                                        createVNode(VForm, {
                                          modelValue: unref(valid),
                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                          onSubmit: withModifiers(Change_password, ["prevent"]),
                                          ref: "form",
                                          "lazy-validation": ""
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(VTextField, {
                                              modelValue: unref(Update).old_password,
                                              "onUpdate:modelValue": ($event) => unref(Update).old_password = $event,
                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                              type: unref(visible) ? "text" : "password",
                                              rules: [rules.passwordRequired, rules.min],
                                              density: "compact",
                                              placeholder: _ctx.$t("password"),
                                              "prepend-inner-icon": "mdi-lock-outline",
                                              variant: "outlined",
                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                            createVNode(VTextField, {
                                              modelValue: unref(Update).new_password,
                                              "onUpdate:modelValue": ($event) => unref(Update).new_password = $event,
                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                              type: unref(visible) ? "text" : "password",
                                              rules: [rules.passwordRequired, rules.min],
                                              density: "compact",
                                              placeholder: _ctx.$t("password"),
                                              "prepend-inner-icon": "mdi-lock-outline",
                                              variant: "outlined",
                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                            createVNode(VCardActions, { class: "text-end" }, {
                                              default: withCtx(() => [
                                                createVNode(VBtn, {
                                                  variant: "text",
                                                  color: "#0F9D58",
                                                  onClick: ($event) => menu.value = false
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                                  ]),
                                                  _: 1
                                                }, 8, ["onClick"]),
                                                createVNode(VBtn, {
                                                  variant: "text",
                                                  color: "#0F9D58",
                                                  type: "submit"
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(VStepperWindowItem, {
                            value: !unref(token) ? 1 : null
                          }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "grey lighten-4" }, [
                                createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                  default: withCtx(() => [
                                    createVNode(VCol, { cols: "12" }, {
                                      default: withCtx(() => [
                                        createVNode(VCard, {
                                          flat: "",
                                          outlined: "",
                                          "min-width": "300",
                                          class: "mx-auto"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(VTabs, {
                                              modelValue: unref(tab),
                                              "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null,
                                              "active-class": "white",
                                              height: "40",
                                              "fixed-tabs": "",
                                              "hide-slider": ""
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(VBtn, {
                                                  color: "#0F9D58",
                                                  "min-width": "100",
                                                  class: "button-menu",
                                                  onClick: ($event) => handleTabClick(0),
                                                  flat: ""
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                  ]),
                                                  _: 1
                                                }, 8, ["onClick"]),
                                                createVNode(VBtn, {
                                                  color: "#0F9D58",
                                                  "min-width": "100",
                                                  class: "button-menu",
                                                  onClick: ($event) => handleTabClick(1),
                                                  flat: ""
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                  ]),
                                                  _: 1
                                                }, 8, ["onClick"])
                                              ]),
                                              _: 1
                                            }, 8, ["modelValue", "onUpdate:modelValue"]),
                                            createVNode(VWindow, {
                                              modelValue: unref(tab),
                                              "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(VWindowItem, { value: 0 }, {
                                                  default: withCtx(() => [
                                                    createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                    createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                      default: withCtx(() => [
                                                        createVNode(VForm, {
                                                          modelValue: unref(valid),
                                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                          onSubmit: withModifiers(onLogin, ["prevent"]),
                                                          ref: "form",
                                                          "lazy-validation": ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(VCol, { cols: "auto" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(user).phonenumber,
                                                                  "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                  class: "mb-4",
                                                                  "prepend-inner-icon": "mdi-phone",
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("phone"),
                                                                  variant: "outlined",
                                                                  "single-line": "",
                                                                  "hide-details": "",
                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                  type: "tel"
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(user).password,
                                                                  "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                  type: unref(visible) ? "text" : "password",
                                                                  rules: [rules.passwordRequired, rules.min],
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("password"),
                                                                  "single-line": "",
                                                                  "hide-details": "",
                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                  variant: "outlined",
                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode("div", { class: "text-center" }, [
                                                              createVNode(VBtn, {
                                                                type: "submit",
                                                                color: "#0F9D58",
                                                                class: "mb-4 button-menu",
                                                                "min-width": "200px"
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            createVNode("div", {
                                                              onClick: ($event) => handleTabClick(2),
                                                              class: "text-body-2 font-weight-regular",
                                                              style: { "cursor": "pointer" }
                                                            }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                            createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                          ]),
                                                          _: 1
                                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(VWindowItem, { value: 1 }, {
                                                  default: withCtx(() => [
                                                    createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                    createVNode(VCardText, { class: "my-7" }, {
                                                      default: withCtx(() => [
                                                        createVNode(VForm, {
                                                          modelValue: unref(valid),
                                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                          onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                          ref: "form",
                                                          "lazy-validation": ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(VCol, { cols: "auto" }, {
                                                              default: withCtx(() => [
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(createUser).phone,
                                                                  "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                  "prepend-inner-icon": "mdi-phone",
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("phone"),
                                                                  variant: "outlined",
                                                                  rules: [rules.phoneRequired, rules.phonenumber],
                                                                  type: "tel"
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(createUser).password1,
                                                                  "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                  type: unref(visible) ? "text" : "password",
                                                                  rules: [rules.passwordRequired, rules.min],
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("password"),
                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                  variant: "outlined",
                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                                createVNode(VTextField, {
                                                                  modelValue: unref(createUser).password2,
                                                                  "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                  "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                  type: unref(visible) ? "text" : "password",
                                                                  rules: [rules.passwordRequired, rules.min],
                                                                  density: "compact",
                                                                  placeholder: _ctx.$t("password"),
                                                                  "prepend-inner-icon": "mdi-lock-outline",
                                                                  variant: "outlined",
                                                                  "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                                }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode("div", { class: "text-center" }, [
                                                              createVNode(VBtn, {
                                                                type: "submit",
                                                                color: "#0F9D58",
                                                                class: "mb-4 button-menu",
                                                                "min-width": "300px"
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                                ]),
                                                                _: 1
                                                              }),
                                                              createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                            ])
                                                          ]),
                                                          _: 1
                                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                }),
                                                createVNode(VWindowItem, { value: 2 }, {
                                                  default: withCtx(() => [
                                                    createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                    createVNode(VCardText, { class: "my-7" }, {
                                                      default: withCtx(() => [
                                                        createVNode(VForm, {
                                                          modelValue: unref(valid),
                                                          "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                          onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                          ref: "form",
                                                          "lazy-validation": ""
                                                        }, {
                                                          default: withCtx(() => [
                                                            createVNode(VTextField, {
                                                              modelValue: unref(user).phonenumber,
                                                              "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                              "prepend-inner-icon": "mdi-phone",
                                                              density: "compact",
                                                              placeholder: _ctx.$t("phone"),
                                                              variant: "outlined",
                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                              type: "tel"
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                            createVNode("div", { class: "text-center" }, [
                                                              createVNode(VBtn, {
                                                                type: "submit",
                                                                color: "#0F9D58",
                                                                class: "mb-4 button-menu",
                                                                "min-width": "200px"
                                                              }, {
                                                                default: withCtx(() => [
                                                                  createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                                ]),
                                                                _: 1
                                                              })
                                                            ]),
                                                            createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                          ]),
                                                          _: 1
                                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                                      ]),
                                                      _: 1
                                                    })
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["modelValue", "onUpdate:modelValue"])
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ])
                            ]),
                            _: 1
                          }, 8, ["value"]),
                          createVNode(VStepperWindowItem, {
                            value: unref(token) ? 2 : null
                          }, {
                            default: withCtx(() => [
                              createVNode(VCard, { "min-width": "300" }, {
                                default: withCtx(() => [
                                  createVNode(VCardTitle, { class: "text-center my-3" }, {
                                    default: withCtx(() => [
                                      createTextVNode(toDisplayString(_ctx.$t("profile")), 1)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(VCardText, null, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "d-flex align-center justify-center" }, [
                                        createVNode("span", { class: "text-h6" }, toDisplayString(unref(store).user.phone_number ? unref(store).user.phone_number : "\u041F\u0443\u0441\u0442\u043E\u0439"), 1),
                                        createVNode(VBtn, {
                                          onClick: unref(logout),
                                          class: "mx-3 close-button",
                                          width: "35px",
                                          height: "35px",
                                          color: "#0F9D58",
                                          icon: "mdi-logout-variant"
                                        }, null, 8, ["onClick"])
                                      ])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(VCardText, null, {
                                    default: withCtx(() => [
                                      createVNode("h5", { class: "text-center my-3" }, toDisplayString(_ctx.$t("change_pass")), 1),
                                      createVNode(VForm, {
                                        modelValue: unref(valid),
                                        "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                        onSubmit: withModifiers(Change_password, ["prevent"]),
                                        ref: "form",
                                        "lazy-validation": ""
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(VTextField, {
                                            modelValue: unref(Update).old_password,
                                            "onUpdate:modelValue": ($event) => unref(Update).old_password = $event,
                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                            type: unref(visible) ? "text" : "password",
                                            rules: [rules.passwordRequired, rules.min],
                                            density: "compact",
                                            placeholder: _ctx.$t("password"),
                                            "prepend-inner-icon": "mdi-lock-outline",
                                            variant: "outlined",
                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                          createVNode(VTextField, {
                                            modelValue: unref(Update).new_password,
                                            "onUpdate:modelValue": ($event) => unref(Update).new_password = $event,
                                            "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                            type: unref(visible) ? "text" : "password",
                                            rules: [rules.passwordRequired, rules.min],
                                            density: "compact",
                                            placeholder: _ctx.$t("password"),
                                            "prepend-inner-icon": "mdi-lock-outline",
                                            variant: "outlined",
                                            "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                          createVNode(VCardActions, { class: "text-end" }, {
                                            default: withCtx(() => [
                                              createVNode(VBtn, {
                                                variant: "text",
                                                color: "#0F9D58",
                                                onClick: ($event) => menu.value = false
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"]),
                                              createVNode(VBtn, {
                                                variant: "text",
                                                color: "#0F9D58",
                                                type: "submit"
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["value"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(VStepperHeader, { class: "d-none" }, {
                      default: withCtx(() => [
                        createVNode(VDivider),
                        createVNode(VStepperItem, {
                          complete: unref(e1) > 1,
                          title: `\u0412\u0445\u043E\u0434`,
                          value: 1,
                          editable: "",
                          disabled: !!unref(token),
                          color: "#0F9D58"
                        }, null, 8, ["complete", "disabled"]),
                        createVNode(VDivider),
                        createVNode(VDivider),
                        createVNode(VStepperItem, {
                          complete: unref(e1) > 2,
                          title: `Step 2`,
                          value: 2,
                          editable: "",
                          disabled: !unref(token),
                          color: "#0F9D58"
                        }, null, 8, ["complete", "disabled"]),
                        createVNode(VDivider)
                      ]),
                      _: 1
                    }),
                    createVNode(VStepperWindow, null, {
                      default: withCtx(() => [
                        createVNode(VStepperWindowItem, {
                          value: !unref(token) ? 1 : null
                        }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "grey lighten-4" }, [
                              createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                                default: withCtx(() => [
                                  createVNode(VCol, { cols: "12" }, {
                                    default: withCtx(() => [
                                      createVNode(VCard, {
                                        flat: "",
                                        outlined: "",
                                        "min-width": "300",
                                        class: "mx-auto"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(VTabs, {
                                            modelValue: unref(tab),
                                            "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null,
                                            "active-class": "white",
                                            height: "40",
                                            "fixed-tabs": "",
                                            "hide-slider": ""
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(VBtn, {
                                                color: "#0F9D58",
                                                "min-width": "100",
                                                class: "button-menu",
                                                onClick: ($event) => handleTabClick(0),
                                                flat: ""
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"]),
                                              createVNode(VBtn, {
                                                color: "#0F9D58",
                                                "min-width": "100",
                                                class: "button-menu",
                                                onClick: ($event) => handleTabClick(1),
                                                flat: ""
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                ]),
                                                _: 1
                                              }, 8, ["onClick"])
                                            ]),
                                            _: 1
                                          }, 8, ["modelValue", "onUpdate:modelValue"]),
                                          createVNode(VWindow, {
                                            modelValue: unref(tab),
                                            "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(VWindowItem, { value: 0 }, {
                                                default: withCtx(() => [
                                                  createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                  createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                    default: withCtx(() => [
                                                      createVNode(VForm, {
                                                        modelValue: unref(valid),
                                                        "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                        onSubmit: withModifiers(onLogin, ["prevent"]),
                                                        ref: "form",
                                                        "lazy-validation": ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(VCol, { cols: "auto" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(user).phonenumber,
                                                                "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                                class: "mb-4",
                                                                "prepend-inner-icon": "mdi-phone",
                                                                density: "compact",
                                                                placeholder: _ctx.$t("phone"),
                                                                variant: "outlined",
                                                                "single-line": "",
                                                                "hide-details": "",
                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                type: "tel"
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                              createVNode(VTextField, {
                                                                modelValue: unref(user).password,
                                                                "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                type: unref(visible) ? "text" : "password",
                                                                rules: [rules.passwordRequired, rules.min],
                                                                density: "compact",
                                                                placeholder: _ctx.$t("password"),
                                                                "single-line": "",
                                                                "hide-details": "",
                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                variant: "outlined",
                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode("div", { class: "text-center" }, [
                                                            createVNode(VBtn, {
                                                              type: "submit",
                                                              color: "#0F9D58",
                                                              class: "mb-4 button-menu",
                                                              "min-width": "200px"
                                                            }, {
                                                              default: withCtx(() => [
                                                                createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          createVNode("div", {
                                                            onClick: ($event) => handleTabClick(2),
                                                            class: "text-body-2 font-weight-regular",
                                                            style: { "cursor": "pointer" }
                                                          }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                        ]),
                                                        _: 1
                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(VWindowItem, { value: 1 }, {
                                                default: withCtx(() => [
                                                  createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                  createVNode(VCardText, { class: "my-7" }, {
                                                    default: withCtx(() => [
                                                      createVNode(VForm, {
                                                        modelValue: unref(valid),
                                                        "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                        onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                        ref: "form",
                                                        "lazy-validation": ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(VCol, { cols: "auto" }, {
                                                            default: withCtx(() => [
                                                              createVNode(VTextField, {
                                                                modelValue: unref(createUser).phone,
                                                                "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                                "prepend-inner-icon": "mdi-phone",
                                                                density: "compact",
                                                                placeholder: _ctx.$t("phone"),
                                                                variant: "outlined",
                                                                rules: [rules.phoneRequired, rules.phonenumber],
                                                                type: "tel"
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                              createVNode(VTextField, {
                                                                modelValue: unref(createUser).password1,
                                                                "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                type: unref(visible) ? "text" : "password",
                                                                rules: [rules.passwordRequired, rules.min],
                                                                density: "compact",
                                                                placeholder: _ctx.$t("password"),
                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                variant: "outlined",
                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                              createVNode(VTextField, {
                                                                modelValue: unref(createUser).password2,
                                                                "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                                "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                                type: unref(visible) ? "text" : "password",
                                                                rules: [rules.passwordRequired, rules.min],
                                                                density: "compact",
                                                                placeholder: _ctx.$t("password"),
                                                                "prepend-inner-icon": "mdi-lock-outline",
                                                                variant: "outlined",
                                                                "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                              }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode("div", { class: "text-center" }, [
                                                            createVNode(VBtn, {
                                                              type: "submit",
                                                              color: "#0F9D58",
                                                              class: "mb-4 button-menu",
                                                              "min-width": "300px"
                                                            }, {
                                                              default: withCtx(() => [
                                                                createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                              ]),
                                                              _: 1
                                                            }),
                                                            createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                          ])
                                                        ]),
                                                        _: 1
                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              }),
                                              createVNode(VWindowItem, { value: 2 }, {
                                                default: withCtx(() => [
                                                  createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                  createVNode(VCardText, { class: "my-7" }, {
                                                    default: withCtx(() => [
                                                      createVNode(VForm, {
                                                        modelValue: unref(valid),
                                                        "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                        onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                        ref: "form",
                                                        "lazy-validation": ""
                                                      }, {
                                                        default: withCtx(() => [
                                                          createVNode(VTextField, {
                                                            modelValue: unref(user).phonenumber,
                                                            "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                            "prepend-inner-icon": "mdi-phone",
                                                            density: "compact",
                                                            placeholder: _ctx.$t("phone"),
                                                            variant: "outlined",
                                                            rules: [rules.phoneRequired, rules.phonenumber],
                                                            type: "tel"
                                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                          createVNode("div", { class: "text-center" }, [
                                                            createVNode(VBtn, {
                                                              type: "submit",
                                                              color: "#0F9D58",
                                                              class: "mb-4 button-menu",
                                                              "min-width": "200px"
                                                            }, {
                                                              default: withCtx(() => [
                                                                createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                              ]),
                                                              _: 1
                                                            })
                                                          ]),
                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                        ]),
                                                        _: 1
                                                      }, 8, ["modelValue", "onUpdate:modelValue"])
                                                    ]),
                                                    _: 1
                                                  })
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["modelValue", "onUpdate:modelValue"])
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ])
                          ]),
                          _: 1
                        }, 8, ["value"]),
                        createVNode(VStepperWindowItem, {
                          value: unref(token) ? 2 : null
                        }, {
                          default: withCtx(() => [
                            createVNode(VCard, { "min-width": "300" }, {
                              default: withCtx(() => [
                                createVNode(VCardTitle, { class: "text-center my-3" }, {
                                  default: withCtx(() => [
                                    createTextVNode(toDisplayString(_ctx.$t("profile")), 1)
                                  ]),
                                  _: 1
                                }),
                                createVNode(VCardText, null, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "d-flex align-center justify-center" }, [
                                      createVNode("span", { class: "text-h6" }, toDisplayString(unref(store).user.phone_number ? unref(store).user.phone_number : "\u041F\u0443\u0441\u0442\u043E\u0439"), 1),
                                      createVNode(VBtn, {
                                        onClick: unref(logout),
                                        class: "mx-3 close-button",
                                        width: "35px",
                                        height: "35px",
                                        color: "#0F9D58",
                                        icon: "mdi-logout-variant"
                                      }, null, 8, ["onClick"])
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode(VCardText, null, {
                                  default: withCtx(() => [
                                    createVNode("h5", { class: "text-center my-3" }, toDisplayString(_ctx.$t("change_pass")), 1),
                                    createVNode(VForm, {
                                      modelValue: unref(valid),
                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                      onSubmit: withModifiers(Change_password, ["prevent"]),
                                      ref: "form",
                                      "lazy-validation": ""
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(VTextField, {
                                          modelValue: unref(Update).old_password,
                                          "onUpdate:modelValue": ($event) => unref(Update).old_password = $event,
                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                          type: unref(visible) ? "text" : "password",
                                          rules: [rules.passwordRequired, rules.min],
                                          density: "compact",
                                          placeholder: _ctx.$t("password"),
                                          "prepend-inner-icon": "mdi-lock-outline",
                                          variant: "outlined",
                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                        createVNode(VTextField, {
                                          modelValue: unref(Update).new_password,
                                          "onUpdate:modelValue": ($event) => unref(Update).new_password = $event,
                                          "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                          type: unref(visible) ? "text" : "password",
                                          rules: [rules.passwordRequired, rules.min],
                                          density: "compact",
                                          placeholder: _ctx.$t("password"),
                                          "prepend-inner-icon": "mdi-lock-outline",
                                          variant: "outlined",
                                          "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                        createVNode(VCardActions, { class: "text-end" }, {
                                          default: withCtx(() => [
                                            createVNode(VBtn, {
                                              variant: "text",
                                              color: "#0F9D58",
                                              onClick: ($event) => menu.value = false
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"]),
                                            createVNode(VBtn, {
                                              variant: "text",
                                              color: "#0F9D58",
                                              type: "submit"
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["value"])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(VStepper, {
                modelValue: unref(e1),
                "onUpdate:modelValue": ($event) => isRef(e1) ? e1.value = $event : null,
                "hide-actions": ""
              }, {
                default: withCtx(({ props }) => [
                  createVNode(VStepperHeader, { class: "d-none" }, {
                    default: withCtx(() => [
                      createVNode(VDivider),
                      createVNode(VStepperItem, {
                        complete: unref(e1) > 1,
                        title: `\u0412\u0445\u043E\u0434`,
                        value: 1,
                        editable: "",
                        disabled: !!unref(token),
                        color: "#0F9D58"
                      }, null, 8, ["complete", "disabled"]),
                      createVNode(VDivider),
                      createVNode(VDivider),
                      createVNode(VStepperItem, {
                        complete: unref(e1) > 2,
                        title: `Step 2`,
                        value: 2,
                        editable: "",
                        disabled: !unref(token),
                        color: "#0F9D58"
                      }, null, 8, ["complete", "disabled"]),
                      createVNode(VDivider)
                    ]),
                    _: 1
                  }),
                  createVNode(VStepperWindow, null, {
                    default: withCtx(() => [
                      createVNode(VStepperWindowItem, {
                        value: !unref(token) ? 1 : null
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "grey lighten-4" }, [
                            createVNode(VRow, { class: "d-flex align-items-center justify-content-center" }, {
                              default: withCtx(() => [
                                createVNode(VCol, { cols: "12" }, {
                                  default: withCtx(() => [
                                    createVNode(VCard, {
                                      flat: "",
                                      outlined: "",
                                      "min-width": "300",
                                      class: "mx-auto"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(VTabs, {
                                          modelValue: unref(tab),
                                          "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null,
                                          "active-class": "white",
                                          height: "40",
                                          "fixed-tabs": "",
                                          "hide-slider": ""
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(VBtn, {
                                              color: "#0F9D58",
                                              "min-width": "100",
                                              class: "button-menu",
                                              onClick: ($event) => handleTabClick(0),
                                              flat: ""
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"]),
                                            createVNode(VBtn, {
                                              color: "#0F9D58",
                                              "min-width": "100",
                                              class: "button-menu",
                                              onClick: ($event) => handleTabClick(1),
                                              flat: ""
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"])
                                          ]),
                                          _: 1
                                        }, 8, ["modelValue", "onUpdate:modelValue"]),
                                        createVNode(VWindow, {
                                          modelValue: unref(tab),
                                          "onUpdate:modelValue": ($event) => isRef(tab) ? tab.value = $event : null
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(VWindowItem, { value: 0 }, {
                                              default: withCtx(() => [
                                                createVNode("h1", { class: "mt-4 xs:body-1 sm:body-1 md:headline-6 lg:headline-5 xl:headline-4" }, toDisplayString(_ctx.$t("login")), 1),
                                                createVNode(VCardText, { class: "my-7 my-auth" }, {
                                                  default: withCtx(() => [
                                                    createVNode(VForm, {
                                                      modelValue: unref(valid),
                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                      onSubmit: withModifiers(onLogin, ["prevent"]),
                                                      ref: "form",
                                                      "lazy-validation": ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(VCol, { cols: "auto" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VTextField, {
                                                              modelValue: unref(user).phonenumber,
                                                              "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                              class: "mb-4",
                                                              "prepend-inner-icon": "mdi-phone",
                                                              density: "compact",
                                                              placeholder: _ctx.$t("phone"),
                                                              variant: "outlined",
                                                              "single-line": "",
                                                              "hide-details": "",
                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                              type: "tel"
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                            createVNode(VTextField, {
                                                              modelValue: unref(user).password,
                                                              "onUpdate:modelValue": ($event) => unref(user).password = $event,
                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                              type: unref(visible) ? "text" : "password",
                                                              rules: [rules.passwordRequired, rules.min],
                                                              density: "compact",
                                                              placeholder: _ctx.$t("password"),
                                                              "single-line": "",
                                                              "hide-details": "",
                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                              variant: "outlined",
                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode("div", { class: "text-center" }, [
                                                          createVNode(VBtn, {
                                                            type: "submit",
                                                            color: "#0F9D58",
                                                            class: "mb-4 button-menu",
                                                            "min-width": "200px"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(_ctx.$t("login")), 1)
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        createVNode("div", {
                                                          onClick: ($event) => handleTabClick(2),
                                                          class: "text-body-2 font-weight-regular",
                                                          style: { "cursor": "pointer" }
                                                        }, toDisplayString(_ctx.$t("reset_pass")), 9, ["onClick"]),
                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                      ]),
                                                      _: 1
                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(VWindowItem, { value: 1 }, {
                                              default: withCtx(() => [
                                                createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("reg")), 1),
                                                createVNode(VCardText, { class: "my-7" }, {
                                                  default: withCtx(() => [
                                                    createVNode(VForm, {
                                                      modelValue: unref(valid),
                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                      onSubmit: withModifiers(onRegistrations, ["prevent"]),
                                                      ref: "form",
                                                      "lazy-validation": ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(VCol, { cols: "auto" }, {
                                                          default: withCtx(() => [
                                                            createVNode(VTextField, {
                                                              modelValue: unref(createUser).phone,
                                                              "onUpdate:modelValue": ($event) => unref(createUser).phone = $event,
                                                              "prepend-inner-icon": "mdi-phone",
                                                              density: "compact",
                                                              placeholder: _ctx.$t("phone"),
                                                              variant: "outlined",
                                                              rules: [rules.phoneRequired, rules.phonenumber],
                                                              type: "tel"
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                            createVNode(VTextField, {
                                                              modelValue: unref(createUser).password1,
                                                              "onUpdate:modelValue": ($event) => unref(createUser).password1 = $event,
                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                              type: unref(visible) ? "text" : "password",
                                                              rules: [rules.passwordRequired, rules.min],
                                                              density: "compact",
                                                              placeholder: _ctx.$t("password"),
                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                              variant: "outlined",
                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                                            createVNode(VTextField, {
                                                              modelValue: unref(createUser).password2,
                                                              "onUpdate:modelValue": ($event) => unref(createUser).password2 = $event,
                                                              "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                                              type: unref(visible) ? "text" : "password",
                                                              rules: [rules.passwordRequired, rules.min],
                                                              density: "compact",
                                                              placeholder: _ctx.$t("password"),
                                                              "prepend-inner-icon": "mdi-lock-outline",
                                                              variant: "outlined",
                                                              "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"])
                                                          ]),
                                                          _: 1
                                                        }),
                                                        createVNode("div", { class: "text-center" }, [
                                                          createVNode(VBtn, {
                                                            type: "submit",
                                                            color: "#0F9D58",
                                                            class: "mb-4 button-menu",
                                                            "min-width": "300px"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(_ctx.$t("reg")), 1)
                                                            ]),
                                                            _: 1
                                                          }),
                                                          createVNode("div", { class: "text-red" }, toDisplayString(unref(errorStatus)), 1)
                                                        ])
                                                      ]),
                                                      _: 1
                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }),
                                            createVNode(VWindowItem, { value: 2 }, {
                                              default: withCtx(() => [
                                                createVNode("h1", { class: "mt-4 auth" }, toDisplayString(_ctx.$t("restore")), 1),
                                                createVNode(VCardText, { class: "my-7" }, {
                                                  default: withCtx(() => [
                                                    createVNode(VForm, {
                                                      modelValue: unref(valid),
                                                      "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                                      onSubmit: withModifiers(Reset_Password, ["prevent"]),
                                                      ref: "form",
                                                      "lazy-validation": ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createVNode(VTextField, {
                                                          modelValue: unref(user).phonenumber,
                                                          "onUpdate:modelValue": ($event) => unref(user).phonenumber = $event,
                                                          "prepend-inner-icon": "mdi-phone",
                                                          density: "compact",
                                                          placeholder: _ctx.$t("phone"),
                                                          variant: "outlined",
                                                          rules: [rules.phoneRequired, rules.phonenumber],
                                                          type: "tel"
                                                        }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder", "rules"]),
                                                        createVNode("div", { class: "text-center" }, [
                                                          createVNode(VBtn, {
                                                            type: "submit",
                                                            color: "#0F9D58",
                                                            class: "mb-4 button-menu",
                                                            "min-width": "200px"
                                                          }, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                                                            ]),
                                                            _: 1
                                                          })
                                                        ]),
                                                        createVNode("div", { class: "text-red" }, toDisplayString(unref(errorMessage)), 1)
                                                      ]),
                                                      _: 1
                                                    }, 8, ["modelValue", "onUpdate:modelValue"])
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["modelValue", "onUpdate:modelValue"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ])
                        ]),
                        _: 1
                      }, 8, ["value"]),
                      createVNode(VStepperWindowItem, {
                        value: unref(token) ? 2 : null
                      }, {
                        default: withCtx(() => [
                          createVNode(VCard, { "min-width": "300" }, {
                            default: withCtx(() => [
                              createVNode(VCardTitle, { class: "text-center my-3" }, {
                                default: withCtx(() => [
                                  createTextVNode(toDisplayString(_ctx.$t("profile")), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(VCardText, null, {
                                default: withCtx(() => [
                                  createVNode("div", { class: "d-flex align-center justify-center" }, [
                                    createVNode("span", { class: "text-h6" }, toDisplayString(unref(store).user.phone_number ? unref(store).user.phone_number : "\u041F\u0443\u0441\u0442\u043E\u0439"), 1),
                                    createVNode(VBtn, {
                                      onClick: unref(logout),
                                      class: "mx-3 close-button",
                                      width: "35px",
                                      height: "35px",
                                      color: "#0F9D58",
                                      icon: "mdi-logout-variant"
                                    }, null, 8, ["onClick"])
                                  ])
                                ]),
                                _: 1
                              }),
                              createVNode(VCardText, null, {
                                default: withCtx(() => [
                                  createVNode("h5", { class: "text-center my-3" }, toDisplayString(_ctx.$t("change_pass")), 1),
                                  createVNode(VForm, {
                                    modelValue: unref(valid),
                                    "onUpdate:modelValue": ($event) => isRef(valid) ? valid.value = $event : null,
                                    onSubmit: withModifiers(Change_password, ["prevent"]),
                                    ref: "form",
                                    "lazy-validation": ""
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(VTextField, {
                                        modelValue: unref(Update).old_password,
                                        "onUpdate:modelValue": ($event) => unref(Update).old_password = $event,
                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                        type: unref(visible) ? "text" : "password",
                                        rules: [rules.passwordRequired, rules.min],
                                        density: "compact",
                                        placeholder: _ctx.$t("password"),
                                        "prepend-inner-icon": "mdi-lock-outline",
                                        variant: "outlined",
                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                      createVNode(VTextField, {
                                        modelValue: unref(Update).new_password,
                                        "onUpdate:modelValue": ($event) => unref(Update).new_password = $event,
                                        "append-inner-icon": unref(visible) ? "mdi-eye-off" : "mdi-eye",
                                        type: unref(visible) ? "text" : "password",
                                        rules: [rules.passwordRequired, rules.min],
                                        density: "compact",
                                        placeholder: _ctx.$t("password"),
                                        "prepend-inner-icon": "mdi-lock-outline",
                                        variant: "outlined",
                                        "onClick:appendInner": ($event) => visible.value = !unref(visible)
                                      }, null, 8, ["modelValue", "onUpdate:modelValue", "append-inner-icon", "type", "rules", "placeholder", "onClick:appendInner"]),
                                      createVNode(VCardActions, { class: "text-end" }, {
                                        default: withCtx(() => [
                                          createVNode(VBtn, {
                                            variant: "text",
                                            color: "#0F9D58",
                                            onClick: ($event) => menu.value = false
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(_ctx.$t("cancel")), 1)
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"]),
                                          createVNode(VBtn, {
                                            variant: "text",
                                            color: "#0F9D58",
                                            type: "submit"
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(_ctx.$t("reset")), 1)
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }, 8, ["value"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-62fd77cd"]]);
const _sfc_main$1 = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    const store = productStore();
    useAuth();
    const form = ref({
      contact: "",
      title: "",
      message: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "footer" }, _attrs))} data-v-90769e4c><div class="container" data-v-90769e4c><!--[-->`);
      ssrRenderList(unref(store).about, ({ id, phone_number1, phone_number2, site_name, email }) => {
        _push(`<div class="row d-flex justify-center align-start" data-v-90769e4c><div class="col-4 col-xs-12" data-v-90769e4c><h1 data-v-90769e4c>${ssrInterpolate(site_name)}</h1><br data-v-90769e4c><ul class="d-flex flex-row ga-5" data-v-90769e4c><!--[-->`);
        ssrRenderList(unref(store).Social, (items) => {
          _push(`<li data-v-90769e4c><a${ssrRenderAttr("href", items.link)} data-v-90769e4c>`);
          _push(ssrRenderComponent(VIcon, null, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`mdi-${ssrInterpolate(items.slug)}`);
              } else {
                return [
                  createTextVNode("mdi-" + toDisplayString(items.slug), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</a></li>`);
        });
        _push(`<!--]--></ul><br data-v-90769e4c><p data-v-90769e4c>${ssrInterpolate(_ctx.$t("email"))}: \u2002${ssrInterpolate(email)}</p><div class="phone-container" data-v-90769e4c><div class="d-flex mr-2" data-v-90769e4c><span data-v-90769e4c>${ssrInterpolate(_ctx.$t("phone"))}: </span></div><div class="d-flex flex-column" data-v-90769e4c><span data-v-90769e4c>${ssrInterpolate(phone_number1)}</span><span data-v-90769e4c>${ssrInterpolate(phone_number2)}</span></div></div></div><div class="col-4 col-xs-12" data-v-90769e4c><h1 data-v-90769e4c>${ssrInterpolate(_ctx.$t("about"))}</h1><br data-v-90769e4c><p data-v-90769e4c>`);
        _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#home" } }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$t("home"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$t("home")), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</p><p data-v-90769e4c>`);
        _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#about" } }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$t("about"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$t("about")), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</p><p data-v-90769e4c>`);
        _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#delivery" } }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$t("delivery"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$t("delivery")), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</p><p data-v-90769e4c>`);
        _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/products", hash: "" } }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$t("products"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$t("products")), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</p><p data-v-90769e4c>`);
        _push(ssrRenderComponent(_component_nuxt_link, { to: { path: "/", hash: "#testimonial" } }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$t("manufacture"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$t("manufacture")), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</p></div><div class="col-4 col-xs-12" data-v-90769e4c><h1 data-v-90769e4c>${ssrInterpolate(_ctx.$t("feedback"))}</h1><br data-v-90769e4c><form data-v-90769e4c><div class="input-group" data-v-90769e4c><input type="text"${ssrRenderAttr("value", unref(form).contact)}${ssrRenderAttr("placeholder", _ctx.$t("email_phone"))} data-v-90769e4c></div><div class="input-group" data-v-90769e4c><input type="text"${ssrRenderAttr("value", unref(form).title)}${ssrRenderAttr("placeholder", _ctx.$t("theme"))} data-v-90769e4c></div><div class="input-group pt-7 pb-7" data-v-90769e4c><input type="text"${ssrRenderAttr("value", unref(form).message)}${ssrRenderAttr("placeholder", _ctx.$t("text"))} data-v-90769e4c></div>`);
        _push(ssrRenderComponent(VCol, { class: "pl-0" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(VBtn, {
                type: "submit",
                class: "submit-form",
                color: "#0F9D58"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(_ctx.$t("send"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(VBtn, {
                  type: "submit",
                  class: "submit-form",
                  color: "#0F9D58"
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$t("send")), 1)
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</form></div></div>`);
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-90769e4c"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Header = __nuxt_component_0;
  const _component_Footer = __nuxt_component_1;
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Header, null, null, _parent));
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(ssrRenderComponent(_component_Footer, null, null, _parent));
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default-9c8247f3.mjs.map
