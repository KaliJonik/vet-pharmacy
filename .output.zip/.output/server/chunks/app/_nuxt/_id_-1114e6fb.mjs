import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { t as productStore, u as useRouter } from '../server.mjs';
import { ref, withAsyncContext, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createTextVNode, createCommentVNode, withDirectives, vModelText, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { FreeMode, Navigation, Thumbs } from 'swiper/modules';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import { a as VCardItem, V as VCardText } from './ssrBoot-66bca22f.mjs';
import { d as VBtn } from './VBtn-55c932b0.mjs';
import { V as VTabs, c as VTab, a as VWindow, b as VWindowItem } from './VTabs-f421e6b8.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const _imports_0 = "" + publicAssetsURL("noimage.png");
const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const store = productStore();
    const tab = ref(null);
    const thumbsSwiper = ref(null);
    const addSpacesToNumber = (number) => {
      return String(number).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    };
    const CostInput = (product) => {
      product.cost = product.price * product.quantity;
    };
    const QtyInput = (product) => {
      product.quantity = product.cost / product.price;
      if (product.quantity < 0) {
        product.quantity = 0;
      }
    };
    const setThumbsSwiper = (swiper) => {
      thumbsSwiper.value = swiper;
    };
    const addToCart = (productId) => {
      const store2 = productStore();
      const alreadyInCart = store2.cards.some((item) => item.id === productId);
      const router = useRouter();
      if (!alreadyInCart) {
        const selectedProduct = store2.one_products.find((item) => item.id === productId);
        if (selectedProduct) {
          store2.addCards(selectedProduct);
        }
      } else {
        router.push("/basket");
      }
    };
    [__temp, __restore] = withAsyncContext(() => store.FetchOneProduct()), await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: "align-items-center bg-img bg-img-fixed",
        id: "food-menu-section",
        style: { "background-image": "url(/broilers.jpg)" }
      }, _attrs))} data-v-6cd4750e><div class="container" data-v-6cd4750e><!--[-->`);
      ssrRenderList(unref(store).one_products, ({ id, content, price, old_price, sale, photos, active }) => {
        _push(`<div class="food-menu" data-v-6cd4750e><div class="card" data-v-6cd4750e><div class="card-item-left" data-v-6cd4750e><section class="slider" data-v-6cd4750e><div class="slider__flex" data-v-6cd4750e><div class="slider__col" data-v-6cd4750e><div class="slider__thumbs" data-v-6cd4750e>`);
        _push(ssrRenderComponent(unref(Swiper), {
          onSwiper: setThumbsSwiper,
          loop: true,
          spaceBetween: 24,
          slidesPerView: 4,
          freeMode: true,
          direction: "vertical",
          watchSlidesProgress: true,
          breakpoints: { 0: { direction: "horizontal", spaceBetween: 100 }, 768: { direction: "vertical" } },
          modules: [unref(FreeMode), unref(Navigation), unref(Thumbs)],
          class: "swiper-container"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (photos.length === 0) {
                _push2(ssrRenderComponent(unref(SwiperSlide), null, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="slider__image" data-v-6cd4750e${_scopeId2}><img${ssrRenderAttr("src", _imports_0)} alt="No Image" data-v-6cd4750e${_scopeId2}></div>`);
                    } else {
                      return [
                        createVNode("div", { class: "slider__image" }, [
                          createVNode("img", {
                            src: _imports_0,
                            alt: "No Image"
                          })
                        ])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<!--[-->`);
                ssrRenderList(photos, (ph) => {
                  _push2(ssrRenderComponent(unref(SwiperSlide), { key: ph }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="slider__image" data-v-6cd4750e${_scopeId2}><img${ssrRenderAttr("src", ph.image)} alt="" data-v-6cd4750e${_scopeId2}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "slider__image" }, [
                            createVNode("img", {
                              src: ph.image,
                              alt: ""
                            }, null, 8, ["src"])
                          ])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                });
                _push2(`<!--]-->`);
              }
            } else {
              return [
                photos.length === 0 ? (openBlock(), createBlock(unref(SwiperSlide), { key: 0 }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "slider__image" }, [
                      createVNode("img", {
                        src: _imports_0,
                        alt: "No Image"
                      })
                    ])
                  ]),
                  _: 1
                })) : (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(photos, (ph) => {
                  return openBlock(), createBlock(unref(SwiperSlide), { key: ph }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "slider__image" }, [
                        createVNode("img", {
                          src: ph.image,
                          alt: ""
                        }, null, 8, ["src"])
                      ])
                    ]),
                    _: 2
                  }, 1024);
                }), 128))
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div><div class="slider__images" data-v-6cd4750e>`);
        _push(ssrRenderComponent(unref(Swiper), {
          style: {
            "--swiper-navigation-color": "#fff",
            "--swiper-pagination-color": "#fff"
          },
          loop: true,
          spaceBetween: 32,
          navigation: true,
          thumbs: { swiper: thumbsSwiper.value },
          direction: "horizontal",
          modules: [unref(FreeMode), unref(Navigation), unref(Thumbs)],
          class: "swiper-container"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (photos.length === 0) {
                _push2(ssrRenderComponent(unref(SwiperSlide), null, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="slider__image" data-v-6cd4750e${_scopeId2}><img${ssrRenderAttr("src", _imports_0)} alt="No Image" data-v-6cd4750e${_scopeId2}></div>`);
                    } else {
                      return [
                        createVNode("div", { class: "slider__image" }, [
                          createVNode("img", {
                            src: _imports_0,
                            alt: "No Image"
                          })
                        ])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<!--[-->`);
                ssrRenderList(photos, (ph) => {
                  _push2(ssrRenderComponent(unref(SwiperSlide), { key: ph }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="slider__image" data-v-6cd4750e${_scopeId2}><img${ssrRenderAttr("src", ph.image)} alt="" data-v-6cd4750e${_scopeId2}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "slider__image" }, [
                            createVNode("img", {
                              src: ph.image,
                              alt: ""
                            }, null, 8, ["src"])
                          ])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                });
                _push2(`<!--]-->`);
              }
            } else {
              return [
                photos.length === 0 ? (openBlock(), createBlock(unref(SwiperSlide), { key: 0 }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "slider__image" }, [
                      createVNode("img", {
                        src: _imports_0,
                        alt: "No Image"
                      })
                    ])
                  ]),
                  _: 1
                })) : (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(photos, (ph) => {
                  return openBlock(), createBlock(unref(SwiperSlide), { key: ph }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "slider__image" }, [
                        createVNode("img", {
                          src: ph.image,
                          alt: ""
                        }, null, 8, ["src"])
                      ])
                    ]),
                    _: 2
                  }, 1024);
                }), 128))
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div></section></div><div class="card-item-right" data-v-6cd4750e>`);
        _push(ssrRenderComponent(VCardItem, { class: "mt-9" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(VCardText, { class: "text-start my-0 py-0 mb-2" }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<h2 class="my-font mb-3 font-weight-bold text-h5" data-v-6cd4750e${_scopeId2}>${ssrInterpolate(content[_ctx.$i18n.locale].title)}</h2><h3 class="my-font mb-3" data-v-6cd4750e${_scopeId2}>${ssrInterpolate(_ctx.$t("manufac"))}: ${ssrInterpolate(content[_ctx.$i18n.locale].manufacturer_title)}</h3><h2 class="my-font mb-3" data-v-6cd4750e${_scopeId2}>${ssrInterpolate(_ctx.$t("price_item"))}: </h2><div class="my-0 py-0 mb-0 pb-0" data-v-6cd4750e${_scopeId2}><h1 class="my-font text-h4 my-0" data-v-6cd4750e${_scopeId2}>${ssrInterpolate(addSpacesToNumber(price))} ${ssrInterpolate(_ctx.$t("price"))} `);
                    if (sale === true) {
                      _push3(`<s class="text-caption ml-2 text-red" data-v-6cd4750e${_scopeId2}>${ssrInterpolate(old_price)} ${ssrInterpolate(_ctx.$t("price"))}</s>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(`</h1></div>`);
                  } else {
                    return [
                      createVNode("h2", { class: "my-font mb-3 font-weight-bold text-h5" }, toDisplayString(content[_ctx.$i18n.locale].title), 1),
                      createVNode("h3", { class: "my-font mb-3" }, toDisplayString(_ctx.$t("manufac")) + ": " + toDisplayString(content[_ctx.$i18n.locale].manufacturer_title), 1),
                      createVNode("h2", { class: "my-font mb-3" }, toDisplayString(_ctx.$t("price_item")) + ": ", 1),
                      createVNode("div", { class: "my-0 py-0 mb-0 pb-0" }, [
                        createVNode("h1", { class: "my-font text-h4 my-0" }, [
                          createTextVNode(toDisplayString(addSpacesToNumber(price)) + " " + toDisplayString(_ctx.$t("price")) + " ", 1),
                          sale === true ? (openBlock(), createBlock("s", {
                            key: 0,
                            class: "text-caption ml-2 text-red"
                          }, toDisplayString(old_price) + " " + toDisplayString(_ctx.$t("price")), 1)) : createCommentVNode("", true)
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(VCardText, {
                class: "my-8",
                style: { "padding": "0!important" }
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="d-flex align-center" data-v-6cd4750e${_scopeId2}><div class="d-flex flex-column ga-2" data-v-6cd4750e${_scopeId2}><div class="wrapper my-5" data-v-6cd4750e${_scopeId2}><div data-v-6cd4750e${_scopeId2}><span class="mx-3" data-v-6cd4750e${_scopeId2}>${ssrInterpolate(_ctx.$t("volume"))}</span></div><button class="btn btn--minus" type="button" name="button" data-v-6cd4750e${_scopeId2}> - </button><!--[-->`);
                    ssrRenderList(unref(store).one_products, (product, index) => {
                      _push3(`<input class="quantity"${ssrRenderAttr("value", product.quantity)} type="text" data-v-6cd4750e${_scopeId2}>`);
                    });
                    _push3(`<!--]--><button class="btn btn--plus" type="button" name="button" data-v-6cd4750e${_scopeId2}> + </button><span class="mx-2" data-v-6cd4750e${_scopeId2}>${ssrInterpolate(content[_ctx.$i18n.locale].unit)}</span></div><div class="wrapper" data-v-6cd4750e${_scopeId2}><div data-v-6cd4750e${_scopeId2}><span class="mx-3" data-v-6cd4750e${_scopeId2}>${ssrInterpolate(_ctx.$t("cost"))}</span></div><button class="btn btn--minus" type="button" name="button" data-v-6cd4750e${_scopeId2}> - </button><!--[-->`);
                    ssrRenderList(unref(store).one_products, (product, index) => {
                      _push3(`<input class="quantity"${ssrRenderAttr("value", product.cost)} type="text" data-v-6cd4750e${_scopeId2}>`);
                    });
                    _push3(`<!--]--><button class="btn btn--plus" type="button" name="button" data-v-6cd4750e${_scopeId2}> + </button></div></div></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "d-flex align-center" }, [
                        createVNode("div", { class: "d-flex flex-column ga-2" }, [
                          createVNode("div", { class: "wrapper my-5" }, [
                            createVNode("div", null, [
                              createVNode("span", { class: "mx-3" }, toDisplayString(_ctx.$t("volume")), 1)
                            ]),
                            createVNode("button", {
                              class: "btn btn--minus",
                              onClick: ($event) => unref(store).decrementQty(id),
                              type: "button",
                              name: "button"
                            }, " - ", 8, ["onClick"]),
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(store).one_products, (product, index) => {
                              return withDirectives((openBlock(), createBlock("input", {
                                class: "quantity",
                                key: index,
                                "onUpdate:modelValue": ($event) => product.quantity = $event,
                                onInput: ($event) => CostInput(product),
                                type: "text"
                              }, null, 40, ["onUpdate:modelValue", "onInput"])), [
                                [vModelText, product.quantity]
                              ]);
                            }), 128)),
                            createVNode("button", {
                              class: "btn btn--plus",
                              onClick: ($event) => unref(store).incrementQuantity(id),
                              type: "button",
                              name: "button"
                            }, " + ", 8, ["onClick"]),
                            createVNode("span", { class: "mx-2" }, toDisplayString(content[_ctx.$i18n.locale].unit), 1)
                          ]),
                          createVNode("div", { class: "wrapper" }, [
                            createVNode("div", null, [
                              createVNode("span", { class: "mx-3" }, toDisplayString(_ctx.$t("cost")), 1)
                            ]),
                            createVNode("button", {
                              class: "btn btn--minus",
                              onClick: ($event) => unref(store).decrementCost(id),
                              type: "button",
                              name: "button"
                            }, " - ", 8, ["onClick"]),
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(store).one_products, (product, index) => {
                              return withDirectives((openBlock(), createBlock("input", {
                                class: "quantity",
                                key: index,
                                "onUpdate:modelValue": ($event) => product.cost = $event,
                                onInput: ($event) => QtyInput(product),
                                type: "text"
                              }, null, 40, ["onUpdate:modelValue", "onInput"])), [
                                [vModelText, product.cost]
                              ]);
                            }), 128)),
                            createVNode("button", {
                              class: "btn btn--plus",
                              onClick: ($event) => unref(store).incrementCost(id),
                              type: "button",
                              name: "button"
                            }, " + ", 8, ["onClick"])
                          ])
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<div class="flex" data-v-6cd4750e${_scopeId}></div>`);
              _push2(ssrRenderComponent(VBtn, {
                class: "my-btn-cart mb-0",
                disabled: !active,
                icon: "active ? 'mdi-cart' : 'mdi-close'",
                color: active ? "#0F9D58" : "#FF0000",
                width: "90%",
                onClick: ($event) => addToCart(id)
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(active ? _ctx.$t("add_cart") : _ctx.$t("add_not_cart"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(active ? _ctx.$t("add_cart") : _ctx.$t("add_not_cart")), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(VCardText, { class: "text-start my-0 py-0 mb-2" }, {
                  default: withCtx(() => [
                    createVNode("h2", { class: "my-font mb-3 font-weight-bold text-h5" }, toDisplayString(content[_ctx.$i18n.locale].title), 1),
                    createVNode("h3", { class: "my-font mb-3" }, toDisplayString(_ctx.$t("manufac")) + ": " + toDisplayString(content[_ctx.$i18n.locale].manufacturer_title), 1),
                    createVNode("h2", { class: "my-font mb-3" }, toDisplayString(_ctx.$t("price_item")) + ": ", 1),
                    createVNode("div", { class: "my-0 py-0 mb-0 pb-0" }, [
                      createVNode("h1", { class: "my-font text-h4 my-0" }, [
                        createTextVNode(toDisplayString(addSpacesToNumber(price)) + " " + toDisplayString(_ctx.$t("price")) + " ", 1),
                        sale === true ? (openBlock(), createBlock("s", {
                          key: 0,
                          class: "text-caption ml-2 text-red"
                        }, toDisplayString(old_price) + " " + toDisplayString(_ctx.$t("price")), 1)) : createCommentVNode("", true)
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024),
                createVNode(VCardText, {
                  class: "my-8",
                  style: { "padding": "0!important" }
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "d-flex align-center" }, [
                      createVNode("div", { class: "d-flex flex-column ga-2" }, [
                        createVNode("div", { class: "wrapper my-5" }, [
                          createVNode("div", null, [
                            createVNode("span", { class: "mx-3" }, toDisplayString(_ctx.$t("volume")), 1)
                          ]),
                          createVNode("button", {
                            class: "btn btn--minus",
                            onClick: ($event) => unref(store).decrementQty(id),
                            type: "button",
                            name: "button"
                          }, " - ", 8, ["onClick"]),
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(store).one_products, (product, index) => {
                            return withDirectives((openBlock(), createBlock("input", {
                              class: "quantity",
                              key: index,
                              "onUpdate:modelValue": ($event) => product.quantity = $event,
                              onInput: ($event) => CostInput(product),
                              type: "text"
                            }, null, 40, ["onUpdate:modelValue", "onInput"])), [
                              [vModelText, product.quantity]
                            ]);
                          }), 128)),
                          createVNode("button", {
                            class: "btn btn--plus",
                            onClick: ($event) => unref(store).incrementQuantity(id),
                            type: "button",
                            name: "button"
                          }, " + ", 8, ["onClick"]),
                          createVNode("span", { class: "mx-2" }, toDisplayString(content[_ctx.$i18n.locale].unit), 1)
                        ]),
                        createVNode("div", { class: "wrapper" }, [
                          createVNode("div", null, [
                            createVNode("span", { class: "mx-3" }, toDisplayString(_ctx.$t("cost")), 1)
                          ]),
                          createVNode("button", {
                            class: "btn btn--minus",
                            onClick: ($event) => unref(store).decrementCost(id),
                            type: "button",
                            name: "button"
                          }, " - ", 8, ["onClick"]),
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(store).one_products, (product, index) => {
                            return withDirectives((openBlock(), createBlock("input", {
                              class: "quantity",
                              key: index,
                              "onUpdate:modelValue": ($event) => product.cost = $event,
                              onInput: ($event) => QtyInput(product),
                              type: "text"
                            }, null, 40, ["onUpdate:modelValue", "onInput"])), [
                              [vModelText, product.cost]
                            ]);
                          }), 128)),
                          createVNode("button", {
                            class: "btn btn--plus",
                            onClick: ($event) => unref(store).incrementCost(id),
                            type: "button",
                            name: "button"
                          }, " + ", 8, ["onClick"])
                        ])
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024),
                createVNode("div", { class: "flex" }),
                createVNode(VBtn, {
                  class: "my-btn-cart mb-0",
                  disabled: !active,
                  icon: "active ? 'mdi-cart' : 'mdi-close'",
                  color: active ? "#0F9D58" : "#FF0000",
                  width: "90%",
                  onClick: ($event) => addToCart(id)
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(active ? _ctx.$t("add_cart") : _ctx.$t("add_not_cart")), 1)
                  ]),
                  _: 2
                }, 1032, ["disabled", "color", "onClick"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
        _push(ssrRenderComponent(VTabs, {
          modelValue: tab.value,
          "onUpdate:modelValue": ($event) => tab.value = $event,
          "bg-color": "#0F9D58",
          "align-tabs": "center",
          style: { "border-radius": "10px" }
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(VTab, { value: "one" }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(_ctx.$t("desc"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.$t("desc")), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(VTab, { value: "one" }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$t("desc")), 1)
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="centred-container" data-v-6cd4750e>`);
        _push(ssrRenderComponent(VCardText, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(VWindow, {
                modelValue: tab.value,
                "onUpdate:modelValue": ($event) => tab.value = $event
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(VWindowItem, { value: "one" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<div class="text-start" data-v-6cd4750e${_scopeId3}>${content[_ctx.$i18n.locale].description}</div>`);
                        } else {
                          return [
                            createVNode("div", {
                              class: "text-start",
                              ref_for: true,
                              ref: "descriptionContainer",
                              innerHTML: content[_ctx.$i18n.locale].description
                            }, null, 8, ["innerHTML"])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(VWindowItem, { value: "one" }, {
                        default: withCtx(() => [
                          createVNode("div", {
                            class: "text-start",
                            ref_for: true,
                            ref: "descriptionContainer",
                            innerHTML: content[_ctx.$i18n.locale].description
                          }, null, 8, ["innerHTML"])
                        ]),
                        _: 2
                      }, 1024)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(VWindow, {
                  modelValue: tab.value,
                  "onUpdate:modelValue": ($event) => tab.value = $event
                }, {
                  default: withCtx(() => [
                    createVNode(VWindowItem, { value: "one" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "text-start",
                          ref_for: true,
                          ref: "descriptionContainer",
                          innerHTML: content[_ctx.$i18n.locale].description
                        }, null, 8, ["innerHTML"])
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1032, ["modelValue", "onUpdate:modelValue"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/products/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-6cd4750e"]]);

export { _id_ as default };
//# sourceMappingURL=_id_-1114e6fb.mjs.map
