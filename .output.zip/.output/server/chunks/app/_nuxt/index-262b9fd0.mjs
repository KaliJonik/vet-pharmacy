import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { t as productStore, v as useAuthToken } from '../server.mjs';
import { withAsyncContext, mergeProps, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_0$1 } from './nodataimage-39aadd60.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import { d as VBtn, V as VIcon } from './VBtn-55c932b0.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const _imports_0 = "" + publicAssetsURL("order.webp");
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const store = productStore();
    const token = useAuthToken();
    if (token.value !== void 0) {
      [__temp, __restore] = withAsyncContext(() => store.getOrderHistory()), await __temp, __restore();
    }
    const addSpacesToNumber = (number) => {
      return String(number).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    };
    const truncateString = (text, maxLength) => {
      if (text && text.length > maxLength) {
        return text.substring(0, maxLength) + "...";
      }
      return text;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: "bg-img h-100 bg-img-fixed",
        id: "food-menu-section",
        style: { "background-image": "url(/chicken.jpg)" }
      }, _attrs))} data-v-a55c105c><div class="container" data-v-a55c105c><div class="food-menu" data-v-a55c105c><h1 class="text-center mb-3 history-title" data-v-a55c105c>${ssrInterpolate(_ctx.$t("order_history"))}</h1>`);
      if (unref(store).order_history.length > 0) {
        _push(`<!--[-->`);
        ssrRenderList(unref(store).order_history, (items) => {
          _push(`<div class="order-container" data-v-a55c105c><div class="orders" data-v-a55c105c><div class="order-img" data-v-a55c105c><img${ssrRenderAttr("src", _imports_0)} alt="" data-v-a55c105c></div><div class="order-title" data-v-a55c105c><h2 data-v-a55c105c>${ssrInterpolate(_ctx.$t("order_item"))} #${ssrInterpolate(items.id)}</h2><h1 class="full-name" data-v-a55c105c>${ssrInterpolate(truncateString(items.full_name, 15))}</h1><span data-v-a55c105c>${ssrInterpolate(items.phone)}</span></div>`);
          _push(ssrRenderComponent(VBtn, {
            class: ["elevation-0 status-button", { "order-status": true, "processing": items.status === "PROCESSING", "accepted": items.status === "AGREED", "disabled": items.status === "DENIED", "success": items.status === "SUCCESS" }]
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(items.status)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(items.status), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div><hr data-v-a55c105c><div class="order-info" data-v-a55c105c><!--[-->`);
          ssrRenderList(items.details, ({ id, value, cost, content }) => {
            _push(`<ul data-v-a55c105c><li data-v-a55c105c>${ssrInterpolate(content[_ctx.$i18n.locale].title)} ${ssrInterpolate(value)} <span data-v-a55c105c>${ssrInterpolate(addSpacesToNumber(cost))} ${ssrInterpolate(_ctx.$t("price"))}</span></li></ul>`);
          });
          _push(`<!--]--><ul data-v-a55c105c><li data-v-a55c105c>${ssrInterpolate(_ctx.$t("delivery_item"))} `);
          if (items.is_delivery) {
            _push(ssrRenderComponent(VIcon, { color: "success" }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`mdi-car`);
                } else {
                  return [
                    createTextVNode("mdi-car")
                  ];
                }
              }),
              _: 2
            }, _parent));
          } else {
            _push(ssrRenderComponent(VIcon, { color: "error" }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`mdi-block-helper`);
                } else {
                  return [
                    createTextVNode("mdi-block-helper")
                  ];
                }
              }),
              _: 2
            }, _parent));
          }
          _push(`</li></ul><hr data-v-a55c105c><ul class="text-h5 my-3 font-weight-bold" data-v-a55c105c><li data-v-a55c105c>${ssrInterpolate(_ctx.$t("total"))}: <span data-v-a55c105c>${ssrInterpolate(addSpacesToNumber(items.cost))} ${ssrInterpolate(_ctx.$t("price"))}</span></li></ul></div></div>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<div class="centered-container" data-v-a55c105c><img${ssrRenderAttr("src", _imports_0$1)} alt="No Products Available" class="centered-image" data-v-a55c105c></div>`);
      }
      _push(`</div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/order-history/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a55c105c"]]);

export { index as default };
//# sourceMappingURL=index-262b9fd0.mjs.map
