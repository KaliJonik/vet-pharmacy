import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-691e5b50.mjs';
import { useSSRContext, withAsyncContext, ref, unref, withCtx, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, mergeProps } from 'vue';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderAttrs, ssrRenderStyle } from 'vue/server-renderer';
import { t as productStore } from '../server.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-cc2b3d55.mjs';
import { Carousel, Slide } from 'vue3-carousel';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'is-https';

const _sfc_main$3 = {
  __name: "Home",
  __ssrInlineRender: true,
  setup(__props) {
    const store = productStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({
        id: "home",
        class: "fullheight align-items-center bg-img bg-img-fixed",
        style: { "background-image": "url(/\u0411\u0435\u043B\u0430\u044F\u041A\u0443\u0440\u043A\u0430.webp)", "color": "black" }
      }, _attrs))}><div class="container"><div class="row"><div class="col-6 col-xs-12"><div class="slogan"><h1 class="left-to-right play-on-scroll"><!--[-->`);
      ssrRenderList(unref(store).about, ({ id, logo }) => {
        _push(`<img${ssrRenderAttr("src", logo)} alt="" width="300" height="300">`);
      });
      _push(`<!--]--></h1><p class="left-to-right play-on-scroll delay-2" style="${ssrRenderStyle({ "color": "black" })}">${ssrInterpolate(_ctx.$t("welcome"))}</p><div class="left-to-right play-on-scroll delay-4">`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/products" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button${_scopeId}>${ssrInterpolate(_ctx.$t("order"))}</button>`);
          } else {
            return [
              createVNode("button", null, toDisplayString(_ctx.$t("order")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Home.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _imports_0 = "" + publicAssetsURL("Propere.webp");
const _sfc_main$2 = {
  __name: "About",
  __ssrInlineRender: true,
  setup(__props) {
    const store = productStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: "about fullheight align-items-center",
        id: "about"
      }, _attrs))} data-v-2c2ec7d5><div class="container mt-10" data-v-2c2ec7d5><div class="d-flex justify-center" data-v-2c2ec7d5><div class="image-about" data-v-2c2ec7d5><img${ssrRenderAttr("src", _imports_0)} alt="" class="fullwidth left-to-right play-on-scroll" data-v-2c2ec7d5></div><!--[-->`);
      ssrRenderList(unref(store).about, ({ id, content }) => {
        _push(`<div class="col-12 col-xs-12 align-items-center" data-v-2c2ec7d5><div class="about-slogan right-to-left play-on-scroll" data-v-2c2ec7d5><h1 class="about-title" data-v-2c2ec7d5><span class="primary-color" data-v-2c2ec7d5>${ssrInterpolate(content[_ctx.$i18n.locale].title)}</span></h1><div class="text-start" data-v-2c2ec7d5>${content[_ctx.$i18n.locale].description}</div></div></div>`);
      });
      _push(`<!--]--></div></div></section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/About.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-2c2ec7d5"]]);
const _sfc_main$1 = {
  __name: "Delivery",
  __ssrInlineRender: true,
  setup(__props) {
    const store = productStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: "delivery align-items-center",
        id: "delivery"
      }, _attrs))} data-v-ceaeb7b9><!--[-->`);
      ssrRenderList(unref(store).about, ({ id, content }) => {
        _push(`<div data-v-ceaeb7b9><h1 class="mt-10" data-v-ceaeb7b9>${ssrInterpolate(content[_ctx.$i18n.locale].title_d)}</h1><br data-v-ceaeb7b9><div class="delivery-desc text-start" data-v-ceaeb7b9>${content[_ctx.$i18n.locale].description_d}</div><span class="scroll-icon" data-v-ceaeb7b9><span class="scroll-icon__dot" data-v-ceaeb7b9></span></span></div>`);
      });
      _push(`<!--]--></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Delivery.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-ceaeb7b9"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const store = productStore();
    [__temp, __restore] = withAsyncContext(() => store.getSwiperManufact()), await __temp, __restore();
    const settings = ref({
      itemsToShow: 1,
      snapAlign: "center"
    });
    const breakpoints = ref({
      700: {
        itemsToShow: 2,
        snapAlign: "start"
      },
      800: {
        itemsToShow: 2,
        snapAlign: "start"
      },
      900: {
        itemsToShow: 2,
        snapAlign: "start"
      },
      1024: {
        itemsToShow: 3,
        snapAlign: "start"
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Home = __nuxt_component_0;
      const _component_About = __nuxt_component_1;
      const _component_Delivery = __nuxt_component_2;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Home, null, null, _parent));
      _push(ssrRenderComponent(_component_About, null, null, _parent));
      _push(ssrRenderComponent(_component_Delivery, null, null, _parent));
      _push(`<section id="manufacture" data-v-2eae6e36><div class="container" data-v-2eae6e36><h2 class="text-center title-caruosel" data-v-2eae6e36>${ssrInterpolate(_ctx.$t("swiper1"))}</h2>`);
      _push(ssrRenderComponent(unref(Carousel), {
        settings: settings.value,
        breakpoints: breakpoints.value,
        "wrap-around": true,
        autoplay: 3e3,
        class: "myCarousel"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(unref(store).manufact.distribute, ({ id, image, content }) => {
              _push2(ssrRenderComponent(unref(Slide), { key: id }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="carousel__item" data-v-2eae6e36${_scopeId2}><div class="carousel__image" data-v-2eae6e36${_scopeId2}><img${ssrRenderAttr("src", image)} alt="" data-v-2eae6e36${_scopeId2}></div><div class="carousel__info" data-v-2eae6e36${_scopeId2}><h3 data-v-2eae6e36${_scopeId2}>${ssrInterpolate(content[_ctx.$i18n.locale].title)}</h3><p data-v-2eae6e36${_scopeId2}>${ssrInterpolate(content[_ctx.$i18n.locale].description)}</p></div></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "carousel__item" }, [
                        createVNode("div", { class: "carousel__image" }, [
                          createVNode("img", {
                            src: image,
                            alt: ""
                          }, null, 8, ["src"])
                        ]),
                        createVNode("div", { class: "carousel__info" }, [
                          createVNode("h3", null, toDisplayString(content[_ctx.$i18n.locale].title), 1),
                          createVNode("p", null, toDisplayString(content[_ctx.$i18n.locale].description), 1)
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufact.distribute, ({ id, image, content }) => {
                return openBlock(), createBlock(unref(Slide), { key: id }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "carousel__item" }, [
                      createVNode("div", { class: "carousel__image" }, [
                        createVNode("img", {
                          src: image,
                          alt: ""
                        }, null, 8, ["src"])
                      ]),
                      createVNode("div", { class: "carousel__info" }, [
                        createVNode("h3", null, toDisplayString(content[_ctx.$i18n.locale].title), 1),
                        createVNode("p", null, toDisplayString(content[_ctx.$i18n.locale].description), 1)
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<h2 class="text-center title-caruosel" data-v-2eae6e36>${ssrInterpolate(_ctx.$t("swiper2"))}</h2>`);
      _push(ssrRenderComponent(unref(Carousel), {
        settings: settings.value,
        breakpoints: breakpoints.value,
        "wrap-around": true,
        autoplay: 3e3,
        class: "myCarousel2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(unref(store).manufact.own, ({ id, image, content }) => {
              _push2(ssrRenderComponent(unref(Slide), { key: id }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="carousel__item" data-v-2eae6e36${_scopeId2}><div class="carousel__image" data-v-2eae6e36${_scopeId2}><img${ssrRenderAttr("src", image)} alt="" data-v-2eae6e36${_scopeId2}></div><div class="carousel__info" data-v-2eae6e36${_scopeId2}><h3 data-v-2eae6e36${_scopeId2}>${ssrInterpolate(content[_ctx.$i18n.locale].title)}</h3><p data-v-2eae6e36${_scopeId2}>${ssrInterpolate(content[_ctx.$i18n.locale].description)}</p></div></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "carousel__item" }, [
                        createVNode("div", { class: "carousel__image" }, [
                          createVNode("img", {
                            src: image,
                            alt: ""
                          }, null, 8, ["src"])
                        ]),
                        createVNode("div", { class: "carousel__info" }, [
                          createVNode("h3", null, toDisplayString(content[_ctx.$i18n.locale].title), 1),
                          createVNode("p", null, toDisplayString(content[_ctx.$i18n.locale].description), 1)
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(unref(store).manufact.own, ({ id, image, content }) => {
                return openBlock(), createBlock(unref(Slide), { key: id }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "carousel__item" }, [
                      createVNode("div", { class: "carousel__image" }, [
                        createVNode("img", {
                          src: image,
                          alt: ""
                        }, null, 8, ["src"])
                      ]),
                      createVNode("div", { class: "carousel__info" }, [
                        createVNode("h3", null, toDisplayString(content[_ctx.$i18n.locale].title), 1),
                        createVNode("p", null, toDisplayString(content[_ctx.$i18n.locale].description), 1)
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></section><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-2eae6e36"]]);

export { index as default };
//# sourceMappingURL=index-5206d7a8.mjs.map
