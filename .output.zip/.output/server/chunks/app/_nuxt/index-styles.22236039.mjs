import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import 'vue/server-renderer';
import '@unhead/ssr';
import 'vue';
import 'unhead';
import '@unhead/shared';

const About_vue_vue_type_style_index_0_scoped_2c2ec7d5_lang = ".about-title[data-v-2c2ec7d5]{font-size:24px;margin-bottom:0}.image-about[data-v-2c2ec7d5]{height:300px;width:300px}";

const Delivery_vue_vue_type_style_index_0_scoped_ceaeb7b9_lang = "#delivery[data-v-ceaeb7b9]{background-image:url(" + publicAssetsURL("Jasur.webp") + ');background-position:50%;background-repeat:no-repeat;background-size:cover;color:#fff;height:100dvh;position:relative;z-index:1}.delivery h1[data-v-ceaeb7b9]{color:var(--primary-color);font-size:24px!important}.delivery[data-v-ceaeb7b9]:before{background:-webkit-linear-gradient(0deg,rgba(5,5,5,.856),rgba(39,39,39,.856));content:"";height:100dvh;left:0;opacity:1;position:absolute;top:0;width:100%;z-index:-1}.delivery-desc[data-v-ceaeb7b9]{-ms-overflow-style:none;height:400px;overflow-y:scroll;padding:0 300px;scrollbar-width:none}.delivery-desc[data-v-ceaeb7b9]::-webkit-scrollbar{display:none}@media(max-width:600px){.delivery-desc[data-v-ceaeb7b9]{padding:0}}@keyframes scroll_2-ceaeb7b9{0%{opacity:1;transform:translateY(0)}25%{opacity:1}75%{opacity:0;transform:translateY(.75em)}to{opacity:0;transform:translateY(0)}}.scroll-icon__dot[data-v-ceaeb7b9]{animation:scroll_2-ceaeb7b9 2s ease-out infinite;backface-visibility:hidden;background:#fff;border-radius:50%;display:block;height:.5em;left:50%;margin-left:-.25em;position:absolute;top:.6em;transform-origin:top center;width:.5em}.scroll-icon[data-v-ceaeb7b9]{border:.25em solid #fff;border-radius:1em;display:block;height:3em;margin:10px auto;position:relative;width:1.5em}';

const index_vue_vue_type_style_index_0_scoped_2eae6e36_lang = "#about[data-v-2eae6e36],#testimonial[data-v-2eae6e36]{color:#000}.title-caruosel[data-v-2eae6e36]{color:#098d4d;font-size:18px;font-weight:500}.carousel__item[data-v-2eae6e36]{background-color:#f0f3f7;border:1px solid rgba(66,66,66,.897);border-radius:1rem;color:#000;display:flex;font-size:20px;height:200px;min-height:200px;width:100%}.carousel__image[data-v-2eae6e36]{align-items:center;display:flex;flex:0 0 50%;justify-content:center}.carousel__image img[data-v-2eae6e36]{border-radius:100%;box-shadow:inset 0 0 17px 0 rgba(0,0,0,.3);height:8em;-o-object-fit:cover;object-fit:cover;padding:1em;width:8em}.carousel__info[data-v-2eae6e36]{align-self:center;flex:0 0 50%;font-size:16px;padding:20px;text-align:left}.carousel__info h3[data-v-2eae6e36]{margin-bottom:10px}.carousel__slide[data-v-2eae6e36]{padding:10px}.myCarousel[data-v-2eae6e36]{padding:2rem 0}.myCarousel2[data-v-2eae6e36]{padding:2rem 0 0}@media(max-width:600px){.title-caruosel[data-v-2eae6e36]{font-size:14px}.carousel__image img[data-v-2eae6e36]{height:10em;-o-object-fit:cover;object-fit:cover;width:10em}}";

const indexStyles_22236039 = [About_vue_vue_type_style_index_0_scoped_2c2ec7d5_lang, Delivery_vue_vue_type_style_index_0_scoped_ceaeb7b9_lang, index_vue_vue_type_style_index_0_scoped_2eae6e36_lang, index_vue_vue_type_style_index_0_scoped_2eae6e36_lang];

export { indexStyles_22236039 as default };
//# sourceMappingURL=index-styles.22236039.mjs.map
