const client_manifest = {
  "VBtn.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VBtn.23a3aab6.css",
    "src": "VBtn.css"
  },
  "VDialog.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VDialog.f0a29abf.css",
    "src": "VDialog.css"
  },
  "VMenu.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VMenu.679eba1e.css",
    "src": "VMenu.css"
  },
  "VSheet.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VSheet.c84d55f0.css",
    "src": "VSheet.css"
  },
  "VTabs.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VTabs.50ea321e.css",
    "src": "VTabs.css"
  },
  "VTextField.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VTextField.5dd72247.css",
    "src": "VTextField.css"
  },
  "_VBtn.02fd9961.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VBtn.23a3aab6.css"
    ],
    "file": "VBtn.02fd9961.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.7c37a15b.js"
    ]
  },
  "VBtn.23a3aab6.css": {
    "file": "VBtn.23a3aab6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VDialog.5ba6f54c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VDialog.f0a29abf.css"
    ],
    "file": "VDialog.5ba6f54c.js",
    "imports": [
      "_VSheet.9cfcfbd5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_VBtn.02fd9961.js",
      "_swiper-vue.7c37a15b.js"
    ]
  },
  "VDialog.f0a29abf.css": {
    "file": "VDialog.f0a29abf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VMenu.65f8a960.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VMenu.679eba1e.css"
    ],
    "file": "VMenu.65f8a960.js",
    "imports": [
      "_swiper-vue.7c37a15b.js",
      "_ssrBoot.f8d3dda7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_VBtn.02fd9961.js",
      "_VSheet.9cfcfbd5.js"
    ]
  },
  "VMenu.679eba1e.css": {
    "file": "VMenu.679eba1e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VSheet.9cfcfbd5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VSheet.c84d55f0.css"
    ],
    "file": "VSheet.9cfcfbd5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.7c37a15b.js",
      "_ssrBoot.f8d3dda7.js",
      "_VBtn.02fd9961.js"
    ]
  },
  "VSheet.c84d55f0.css": {
    "file": "VSheet.c84d55f0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VTabs.1a105c60.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VTabs.50ea321e.css"
    ],
    "file": "VTabs.1a105c60.js",
    "imports": [
      "_swiper-vue.7c37a15b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_VBtn.02fd9961.js",
      "_ssrBoot.f8d3dda7.js"
    ]
  },
  "VTabs.50ea321e.css": {
    "file": "VTabs.50ea321e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VTextField.3c483e27.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VTextField.5dd72247.css"
    ],
    "file": "VTextField.3c483e27.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_VSheet.9cfcfbd5.js",
      "_swiper-vue.7c37a15b.js",
      "_VBtn.02fd9961.js",
      "_ssrBoot.f8d3dda7.js",
      "_VTabs.1a105c60.js"
    ]
  },
  "VTextField.5dd72247.css": {
    "file": "VTextField.5dd72247.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_nodataimage.404a9368.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nodataimage.404a9368.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.41fa6f7a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.41fa6f7a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.7c37a15b.js"
    ]
  },
  "_on_scroll_animation.03468e76.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "on_scroll_animation.03468e76.js"
  },
  "_ssrBoot.f8d3dda7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "ssrBoot.a7e7c988.css"
    ],
    "file": "ssrBoot.f8d3dda7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_VBtn.02fd9961.js",
      "_swiper-vue.7c37a15b.js"
    ]
  },
  "ssrBoot.a7e7c988.css": {
    "file": "ssrBoot.a7e7c988.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_swiper-vue.7c37a15b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.25ac1039.css"
    ],
    "file": "swiper-vue.7c37a15b.js"
  },
  "swiper-vue.25ac1039.css": {
    "file": "swiper-vue.25ac1039.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_vue.f36acd1f.b3e0c627.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.b3e0c627.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.7c37a15b.js"
    ]
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.7cff4094.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.4f5076e1.js",
    "imports": [
      "_nuxt-link.41fa6f7a.js",
      "_swiper-vue.7c37a15b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_VBtn.02fd9961.js",
      "_VMenu.65f8a960.js",
      "_ssrBoot.f8d3dda7.js",
      "_VTextField.3c483e27.js",
      "_VSheet.9cfcfbd5.js",
      "_VTabs.1a105c60.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.7cff4094.css": {
    "file": "default.7cff4094.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "materialdesignicons-webfont.5159a347.eot",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "materialdesignicons-webfont.be825c12.ttf",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "materialdesignicons-webfont.28c8f97f.woff",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "materialdesignicons-webfont.31010194.woff2",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.cb27a21a.js",
    "imports": [
      "_nuxt-link.41fa6f7a.js",
      "_vue.f36acd1f.b3e0c627.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_swiper-vue.7c37a15b.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.79f72c1d.js",
    "imports": [
      "_vue.f36acd1f.b3e0c627.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_swiper-vue.7c37a15b.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.69bf0ab9.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "materialdesignicons-webfont.5159a347.eot",
      "materialdesignicons-webfont.31010194.woff2",
      "materialdesignicons-webfont.28c8f97f.woff",
      "materialdesignicons-webfont.be825c12.ttf"
    ],
    "css": [
      "entry.69bf0ab9.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.0bca5a5e.js",
    "imports": [
      "_swiper-vue.7c37a15b.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.69bf0ab9.css": {
    "file": "entry.69bf0ab9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "materialdesignicons-webfont.5159a347.eot": {
    "file": "materialdesignicons-webfont.5159a347.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "materialdesignicons-webfont.31010194.woff2": {
    "file": "materialdesignicons-webfont.31010194.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "materialdesignicons-webfont.28c8f97f.woff": {
    "file": "materialdesignicons-webfont.28c8f97f.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "materialdesignicons-webfont.be825c12.ttf": {
    "file": "materialdesignicons-webfont.be825c12.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "pages/basket/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.604caf4c.css",
    "src": "pages/basket/index.css"
  },
  "pages/basket/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.310aed48.js",
    "imports": [
      "_nuxt-link.41fa6f7a.js",
      "_swiper-vue.7c37a15b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nodataimage.404a9368.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_VTextField.3c483e27.js",
      "_VBtn.02fd9961.js",
      "_VDialog.5ba6f54c.js",
      "_VSheet.9cfcfbd5.js",
      "_VTabs.1a105c60.js",
      "_ssrBoot.f8d3dda7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/basket/index.vue"
  },
  "index.604caf4c.css": {
    "file": "index.604caf4c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.ad665ff8.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.01a035ca.js",
    "imports": [
      "_nuxt-link.41fa6f7a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.7c37a15b.js",
      "_on_scroll_animation.03468e76.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.ad665ff8.css": {
    "file": "index.ad665ff8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/order-history/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.716adec3.css",
    "src": "pages/order-history/index.css"
  },
  "pages/order-history/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.a86824f5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nodataimage.404a9368.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_swiper-vue.7c37a15b.js",
      "_VBtn.02fd9961.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/order-history/index.vue"
  },
  "index.716adec3.css": {
    "file": "index.716adec3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/products/[id].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_id_.886cc9c7.css",
    "src": "pages/products/[id].css"
  },
  "pages/products/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_id_.f0dd0e72.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.7c37a15b.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_ssrBoot.f8d3dda7.js",
      "_VBtn.02fd9961.js",
      "_VTabs.1a105c60.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/products/[id].vue"
  },
  "_id_.886cc9c7.css": {
    "file": "_id_.886cc9c7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/products/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.0aec59f1.css",
    "src": "pages/products/index.css"
  },
  "pages/products/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.a247ddce.js",
    "imports": [
      "_nuxt-link.41fa6f7a.js",
      "_swiper-vue.7c37a15b.js",
      "_vue.f36acd1f.b3e0c627.js",
      "_nodataimage.404a9368.js",
      "_on_scroll_animation.03468e76.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js",
      "_VMenu.65f8a960.js",
      "_VSheet.9cfcfbd5.js",
      "_VDialog.5ba6f54c.js",
      "_VBtn.02fd9961.js",
      "_ssrBoot.f8d3dda7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/products/index.vue"
  },
  "index.0aec59f1.css": {
    "file": "index.0aec59f1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "ssrBoot.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "ssrBoot.a7e7c988.css",
    "src": "ssrBoot.css"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.25ac1039.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
