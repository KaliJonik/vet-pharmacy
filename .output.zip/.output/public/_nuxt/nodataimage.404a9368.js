import"./entry.0bca5a5e.js";const o=""+globalThis.__publicAssetsURL("nodataimage.jpg");export{o as _};
